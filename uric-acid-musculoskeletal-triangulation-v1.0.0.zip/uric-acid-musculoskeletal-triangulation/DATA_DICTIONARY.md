# Data dictionary

## `data/analytic_clean.csv` — analysis dataset (n = 60,730; 92 columns)

Adults aged >=20 years from 12 NHANES cycles (1999–2000 to 2021–2023), after the
eligibility criteria in `code/clean_dataset.py`. One row per participant.

### Identifiers and design variables

| Column | Description |
|--------|-------------|
| `SEQN` | NHANES respondent sequence number |
| `cycle` | NHANES cycle label (e.g. `2017-2020`) |
| `year` | cycle start year |
| `strata` | masked variance pseudo-stratum |
| `psu` | masked variance unit (primary sampling unit) |
| `wt2` | 2-year MEC examination weight (WTMEC2YR) |
| `wt4` | 4-year MEC weight (WTMEC4YR), 1999–2002 only |
| `wtprp` | pre-pandemic weight (WTMECPRP), 2017–March 2020 only |
| `wt` | cycle-specific weight selected for the cycle |
| `wt_comb` | pooled, cycle-adjusted weight used in all analyses |

### Exposure and outcome

| Column | Description |
|--------|-------------|
| `ua` | serum uric acid, mg/dL (LBXSUA) |
| `ua_q` | survey-weighted uric acid quartile (1–4); cut-points 4.4 / 5.3 / 6.3 mg/dL |
| `hyperuricemia` | 1 if >7.0 mg/dL (men) or >6.0 mg/dL (women) |
| `hyperuricemia_sat` | 1 if >6.8 mg/dL (saturation threshold) |
| `log_ua` | natural logarithm of serum uric acid |
| `arthritis` | self-reported doctor-diagnosed arthritis, raw MCQ160A code |
| `arthritis_bin` | 1 = self-reported doctor-diagnosed arthritis |
| `arthritis_type` | arthritis type code, as harmonised across cycles |
| `oa_subtype` | osteoarthritis subtype flag, as harmonised across cycles |
| `osteoporosis` | 1 = self-reported osteoporosis |
| `osq_fracture` | 1 = self-reported fracture |
| `hip_fracture` | 1 = self-reported hip fracture |
| `gout_a`, `gout_b`, `gout_n`, `gout_m` | self-reported gout flags as collected in different cycles (used for the gout-exclusion sensitivity analysis) |

### Bone densitometry (DXA cycles only, n = 21,132)

| Column | Description |
|--------|-------------|
| `fn_bmd` | femoral-neck bone mineral density, g/cm² (DXXNKBMD) |
| `totfemur_bmd` | total femur BMD, g/cm² |
| `troch_bmd` | trochanter BMD, g/cm² |
| `totbody_bmd` | total body BMD, g/cm² |

### Anthropometry and demographics

| Column | Description |
|--------|-------------|
| `age` | age in years |
| `age_grp` | age group (20–39 / 40–59 / 60+) |
| `sex` | 1 = male, 2 = female |
| `race` | NHANES race/ethnicity code |
| `race5` | 5-level race/ethnicity category |
| `edu` | education code |
| `edu3` | 3-level education category |
| `pir` | family poverty income ratio |
| `preg` | pregnancy status (women 20–44) |
| `bmi` | body mass index, kg/m² |
| `bmi_cat` | BMI category (<25 / 25–29.9 / 30–34.9 / >=35) |
| `waist` | waist circumference, cm |
| `height` | standing height, cm |
| `weight` | body weight, kg |
| `menopause`, `postmeno` | menopausal status (women) |

### Laboratory values

| Column | Description |
|--------|-------------|
| `albumin` | serum albumin, g/dL |
| `alp` | alkaline phosphatase, U/L |
| `calcium` | serum calcium, mg/dL |
| `phosphorus` | serum phosphorus, mg/dL |
| `creatinine` | serum creatinine, mg/dL |
| `egfr` | estimated glomerular filtration rate, mL/min/1.73 m² (CKD-EPI 2021) |
| `glucose` | plasma glucose, mg/dL |
| `trigly` | triglycerides, mg/dL |
| `chol` | total cholesterol, mg/dL |
| `totprot` | total protein, g/dL |
| `bun` | blood urea nitrogen, mg/dL |
| `crp` | high-sensitivity C-reactive protein, mg/dL |
| `wbc` | white blood cell count, 1000 cells/µL |
| `neut_no`, `lymph_no` | neutrophil and lymphocyte count, 1000 cells/µL |
| `neut_pct`, `lymph_pct` | neutrophil and lymphocyte percentage |
| `plt` | platelet count, 1000 cells/µL |
| `hgb` | haemoglobin, g/dL |
| `nlr` | neutrophil-to-lymphocyte ratio |
| `plr` | platelet-to-lymphocyte ratio |
| `sii` | systemic immune-inflammation index (platelets x neutrophils / lymphocytes) |

### Lifestyle and comorbidity

| Column | Description |
|--------|-------------|
| `smoke100` | smoked >=100 cigarettes in life (raw) |
| `smoke_now` | currently smokes (raw) |
| `smoke` | 3-level smoking status (never / former / current) |
| `alc_ever`, `alc_freq`, `alc_drinks` | alcohol use, raw codes |
| `alcohol` | alcohol use category |
| `diabetes` | 1 = self-reported diabetes |
| `hypertension` | 1 = self-reported hypertension |
| `hbp_med` | 1 = on antihypertensive medication |
| `energy` | total energy intake, kcal/day |
| `diet_ca` | dietary calcium, mg/day |
| `diet_prot` | dietary protein, g/day |
| `mvpa_vig`, `mvpa_mod` | vigorous / moderate leisure-time activity, raw codes |
| `mvpa_vig_min`, `mvpa_mod_min` | minutes per week, vigorous / moderate |
| `mvpa_min` | total moderate-to-vigorous physical activity, minutes/week |
| `mvpa_active` | 1 = meets the MVPA guideline |
| `sedentary` | sedentary time, as harmonised across cycles |
| `sleep` | usual sleep duration, hours |

## `data/analytic.csv` — pre-cleaning harmonised dataset (64 columns, not shipped)

Output of `code/build_dataset.py`: all adult NHANES records pooled across the 12
cycles with harmonised variable names, before the eligibility filters and derived
variables of `clean_dataset.py`. This intermediate is not included in the deposit;
regenerate it with `python code/build_dataset.py` (requires the raw NHANES files). Column names are as above, without the derived
variables (`ua_q`, `hyperuricemia`, `egfr`, `nlr`, `sii`, `plr`, the categorical
recodes and the pooled weight `wt_comb`).

## `data/manifest.json`

Records, for every survey component and cycle, the exact file name retrieved from
the NCHS server and its size — the provenance of the pooled dataset.

## `data/diag.json`

Per-cycle record counts and the survey weight columns used for each cycle.

## `results/`

One file (or set of files) per analysis step; see `PIPELINE.md` for the mapping
between scripts, outputs and manuscript elements. Run logs are stored as
`*_log.txt` alongside the results.
