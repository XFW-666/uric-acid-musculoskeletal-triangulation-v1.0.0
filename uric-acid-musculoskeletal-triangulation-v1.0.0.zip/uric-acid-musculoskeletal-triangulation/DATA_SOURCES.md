# Data sources, accessions and terms of use

All source data are de-identified and publicly available. Access dates: October 2026.

| Source | Version / accession | Retrieved by | Redistributed here |
|--------|--------------------|--------------|--------------------|
| National Health and Nutrition Examination Survey (NHANES) | 12 cycles, 1999–2000 to 2021–2023 (incl. 2017–March 2020 pre-pandemic) | `code/download_nhanes.py` | No — raw `.xpt` fetched from CDC |
| National Health Interview Survey (NHIS) | Sample Adult, 2019–2024 | `code/download_nhis.py` | No — archives fetched from CDC |
| GWAS Catalog | harmonised association release, uric-acid measurement trait (EFO_0004761) | `code/analysis_mr_instrument.py` | Filtered subset only (`data/gwas/uric_acid_associations.csv`) |
| FinnGen | R10 summary statistics (M13_GOUT, M13_ARTHROSIS, M13_ARTHROSIS_KNEE, M13_ARTHTROSIS_COX, M13_OSTEOPOROSIS) | `code/analysis_mr_primary.py` (HTTP range requests) | No — queried remotely, never stored |
| Open Targets Platform | target–disease association and genetic-association scores | `code/analysis_opentargets_evidence.py` | Scores included in `results/` |
| openFDA — FDA Adverse Event Reporting System (FAERS) | 20,692,687 reports at time of access | `code/analysis_faers_core.py`, `code/analysis_faers_extended.py` | Aggregate counts and odds ratios only |
| Gene Expression Omnibus | GSE114007 (human knee articular cartilage, 22 osteoarthritis and 20 normal samples) | `code/analysis_geo_transcriptome.py` | Yes — processed counts (`data/geo/`) |

## URLs

* NHANES: <https://wwwn.cdc.gov/nchs/nhanes/> — file pattern
  `https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/<year>/DataFiles/<file>`
* NHIS: <https://www.cdc.gov/nchs/nhis/> — file pattern
  `https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/<year>/adult<yy>csv.zip`
* GWAS Catalog: <https://www.ebi.ac.uk/gwas/>
  (release archive `gwas-catalog-associations_ontology-annotated-full.zip`)
* FinnGen R10: <https://r10.finngen.fi/> — manifest
  `https://storage.googleapis.com/finngen-public-data-r10/summary_stats/R10_manifest.tsv`
* Open Targets Platform: <https://platform.opentargets.org/> (GraphQL API v4)
* openFDA: <https://open.fda.gov/apis/drug/event/>
* GEO: <https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE114007>

## Terms of use

* **NHANES and NHIS** are US federal public-use datasets produced by the National
  Center for Health Statistics; they contain no personal identifiers. Users are
  asked to acknowledge NCHS as the source.
* **GWAS Catalog** data are distributed by EMBL-EBI; see the terms of use at
  <https://www.ebi.ac.uk/gwas/docs/about>.
* **FinnGen** summary statistics are made publicly available by the FinnGen
  consortium for research use; see <https://www.finngen.fi/en/access_results>.
  They are not redistributed in this deposit.
* **Open Targets Platform** data are released under CC0 1.0.
* **openFDA** data are in the public domain; the API is provided by the US Food
  and Drug Administration.
* **GEO** data are freely available for research use; GSE114007 should be cited
  as Fisch KM et al., *Osteoarthritis and Cartilage* 2018;26(11):1531–1538.

## Key references for the source data

* Zipf G, et al. NHANES: plan and operations, 1999–2010. *Vital and Health
  Statistics*, Series 1. 2013;(56):1–37.
* Kurki MI, et al. FinnGen provides genetic insights from a well-phenotyped
  isolated population. *Nature*. 2023;613(7944):508–518.
* Sollis E, et al. The NHGRI-EBI GWAS Catalog. *Nucleic Acids Research*.
  2023;51(D1):D977–D985.
* Ochoa D, et al. The next-generation Open Targets Platform. *Nucleic Acids
  Research*. 2023;51(D1):D1353–D1359.
* Fisch KM, et al. Identification of transcription factors responsible for
  dysregulated networks in human osteoarthritis cartilage. *Osteoarthritis and
  Cartilage*. 2018;26(11):1531–1538.
* Clough E, et al. NCBI GEO: archive for gene expression and epigenomics data
  sets: 23-year update. *Nucleic Acids Research*. 2024;52(D1):D138–D144.
