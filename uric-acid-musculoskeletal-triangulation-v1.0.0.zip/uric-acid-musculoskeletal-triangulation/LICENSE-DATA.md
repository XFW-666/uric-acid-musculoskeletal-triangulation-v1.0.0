# Licence for the derived datasets

The derived datasets produced in this study — `data/analytic.csv`,
`data/analytic_clean.csv`, `data/variable_inventory.json`,
`data/gwas/uric_acid_associations.csv` and the analysis outputs in `results/` —
are released under the **Creative Commons Attribution 4.0 International
licence (CC BY 4.0)**: <https://creativecommons.org/licenses/by/4.0/>.

You are free to share and adapt these data for any purpose, provided that
appropriate credit is given, a link to the licence is provided, and any changes
are indicated. Please cite the article and the deposit DOI.

Third-party source data redistributed here (the GEO GSE114007 processed counts in
`data/geo/`) remain subject to the terms of the original provider; see
`DATA_SOURCES.md`. Raw NHANES, NHIS, GWAS Catalog and FinnGen files are not
redistributed in this deposit and must be obtained from their providers.
