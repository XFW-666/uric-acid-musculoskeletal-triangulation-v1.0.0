# Pipeline

All scripts are run from the repository root and write into `data/`, `results/`
and `figures/`. Steps marked **[remote]** require internet access.

Shipped with the deposit: the analysis dataset `data/analytic_clean.csv` and all
files in `results/` and `figures/`, so steps 3-6 can be run immediately. Steps
1-2 and the two model intermediates named below are regenerated on demand and are
not included (`data/analytic.csv`, `results/X_imputed.csv`,
`results/oof_preds.npy`).

## 1. Source data

| Step | Script | Input | Output |
|------|--------|-------|--------|
| 1.1 **[remote]** | `code/download_nhanes.py` | `data/manifest.json` | `data/<cycle>/*.xpt` (12 cycles, 303 files) |
| 1.2 **[remote]** | `code/download_nhis.py` | — | `data/nhis/adult*csv.zip` (2019–2024) |
| 1.3 | `code/inventory_nhanes_variables.py` | `data/<cycle>/*.xpt` | `data/variable_inventory.json` |

## 2. Dataset assembly

| Step | Script | Input | Output |
|------|--------|-------|--------|
| 2.1 | `code/build_dataset.py` | `data/<cycle>/*.xpt` | `data/analytic.csv`, `data/diag.json` |
| 2.2 | `code/clean_dataset.py` | `data/analytic.csv` | `data/analytic_clean.csv` (n = 60,730) |

## 3. NHANES analyses

| Step | Script | Manuscript element |
|------|--------|--------------------|
| 3.1 | `code/analysis_epi_table1_trends.py` | Table 1; crude and age-standardised trends |
| 3.2 | `code/analysis_arthritis_models.py` | Table 2A; Figure 3a–c |
| 3.3 | `code/analysis_extra_terms.py` | continuous and hyperuricaemia rows of Table 2A |
| 3.4 | `code/analysis_bone_models.py` | Table 2B; sensitivity analyses |
| 3.5 | `code/analysis_mediation_subgroups.py` | Table 2C; Figure 3g–h |
| 3.6 | `code/analysis_fracture_who_pathway.py` | Table 2B2; fracture and pathway results |
| 3.7 | `code/analysis_age_standardised_trends.py` | Figure 2f |
| 3.8 | `code/analysis_spline_stratified.py` | stratified dose–response curves |
| 3.9 | `code/analysis_spline_joint_tests.py` | joint Wald tests of non-linearity |
| 3.10 | `code/analysis_fracture_who_panels.py` | Figure 3d–f |

## 4. Prediction and interpretability

| Step | Script | Manuscript element |
|------|--------|--------------------|
| 4.1 | `code/analysis_ml_prediction.py` | Table 2D; Figure 4a–e, g–h |
| 4.2 | `code/analysis_ml_ebm_shapes.py` | Figure 4f |
| 4.3 | `code/analysis_partial_dependence.py` | Figure 4i |

## 5. Independent sources

| Step | Script | Manuscript element |
|------|--------|--------------------|
| 5.1 | `code/analysis_nhis_trend.py` **[remote]** | Table 3 (NHIS); Figure 2f |
| 5.2 **[remote]** | `code/analysis_mr_instrument.py` | 287 instruments; Figure 5c |
| 5.3 **[remote]** | `code/analysis_mr_primary.py` | Table 3; Figure 5a |
| 5.4 | `code/analysis_mr_sensitivity.py` | sensitivity suite; Figure 5b, d |
| 5.5 **[remote]** | `code/analysis_opentargets_evidence.py` | Figure 5e |
| 5.6 **[remote]** | `code/analysis_faers_core.py` | Figure 5f |
| 5.7 **[remote]** | `code/analysis_faers_extended.py` | Figure 5g |
| 5.8 **[remote]** | `code/analysis_geo_transcriptome.py` | Figure 6a–c |
| 5.9 **[remote]** | `code/analysis_geo_enrichment.py` | enrichment results |

## 6. Figures

| Script | Output |
|--------|--------|
| `code/figure2_3_cohort_and_associations.py` | `figures/Figure2_cohort_trends.png`, `figures/Figure3_associations.png` |
| `code/figure4_prediction_interpretability.py` | `figures/Figure4_prediction.png` |
| `code/figure5_6_cross_database.py` | `figures/Figure5_cross_database.png`, `figures/Figure6_geo.png` |
| `code/figstyle.py` | shared styling module (imported by the three figure scripts) |
| `code/check_label_overlaps.py` | QA: overlapping or out-of-bounds text in the figures |

Figure 1 is a schematic; the editable vector source is
`figures/Figure1_framework.svg`.

## 7. Manuscript

| Script | Output |
|--------|--------|
| `code/build_manuscript_docx.py` | `manuscript/*.docx` (assembles the markdown source, tables and figures) |
| `code/docx_to_pdf.py` | `manuscript/*.pdf` (requires Microsoft Word) |
| `code/count_manuscript_words.py` | word counts |
| `code/check_reference_integrity.py` | citation/reference consistency check |

## Notes on reproducibility

* Survey weights are cycle-appropriate (WTMEC4YR/2 for 1999–2002, WTMECPRP for
  2017–March 2020, WTMEC2YR otherwise), divided by 12 when pooling.
* Random seeds are fixed in the prediction, bootstrap and figure scripts.
* `analysis_mr_primary.py` reads FinnGen R10 summary statistics over HTTP range
  requests using `code/tabix_http.py`; no FinnGen file is stored locally.
* Run logs for each analysis are kept in `results/`.
