# Serum uric acid and musculoskeletal health — multi-database triangulation

Data, analysis code, results and figures for the study:

> **Serum uric acid and musculoskeletal health: multi-database triangulation of
> observational, genetic, pharmacovigilance and transcriptomic evidence in
> 60,730 US adults**

Six independent public data sources were analysed to separate the causal from the
confounded component of the uric acid–musculoskeletal relationship:

| # | Source | Role in the study |
|---|--------|-------------------|
| 1 | **NHANES 1999–2023** (12 cycles, n = 60,730) | association, dose–response, mediation, prediction |
| 2 | **NHIS 2019–2024** | independent temporal corroboration |
| 3 | **FinnGen R10 + GWAS Catalog** | two-sample Mendelian randomisation |
| 4 | **Open Targets Platform** | target–disease genetic evidence |
| 5 | **openFDA FAERS** (20.7 M reports) | pharmacovigilance, indication-matched |
| 6 | **GEO GSE114007** | knee-cartilage transcriptome |

Principal findings: the crude positive uric acid–arthritis association (quartile 4
vs 1, OR 1.24) is abolished by adjustment for adiposity (OR 0.89), with BMI
mediating 103% of it, and Mendelian randomisation gives a null causal estimate for
osteoarthritis (OR 1.00); uric acid tracks favourably with femoral-neck bone
mineral density (+0.014 g/cm³, 95% CI 0.005–0.023) and genetically predicted uric
acid is protective for osteoporosis (OR 0.63); the crude drug-safety signals for
urate-lowering therapy are explained by the gout indication.

---

## Contents

```
code/          analysis and figure-generation code (see PIPELINE.md for run order)
data/          derived analysis dataset (analytic_clean.csv) and provenance files;
               raw third-party files are fetched by code/
results/       all analysis outputs (CSV / JSON) and run logs
figures/       final figures (PNG; Figure 1 also as editable SVG)
manuscript/    manuscript source (markdown)
```

## Quick start

```bash
python -m venv .venv && . .venv/bin/activate      # Python 3.12
pip install -r requirements.txt
```

The analysis dataset is included, so the analyses and figures run directly:

```bash
python code/analysis_arthritis_models.py          # Table 2A, Figure 3a-c
python code/figure2_3_cohort_and_associations.py  # Figures 2 and 3
```

Full end-to-end reproduction from the raw source data (optional, ~765 MB of
downloads; steps 2.1-2.2 rebuild the analysis dataset):

```bash
python code/download_nhanes.py                    # 12 cycles, 303 files
python code/download_nhis.py                      # 2019-2024
python code/build_dataset.py                      # data/analytic.csv
python code/clean_dataset.py                      # data/analytic_clean.csv
```

Then run the analyses and figures in the order given in
[`PIPELINE.md`](PIPELINE.md). Every script is standalone and is run from the
repository root:

```bash
python code/analysis_arthritis_models.py
python code/figure2_3_cohort_and_associations.py
```

## What is included and what is not

**Included:** all analysis code; the derived NHANES analysis dataset
(`analytic_clean.csv`, n = 60,730); the filtered GWAS Catalog uric-acid
association subset; the GEO processed counts; every analysis output (tables, model
results, sensitivity analyses) and run log; all figures; and the manuscript source.

**Regenerated rather than shipped** (kept out to respect the deposit size limit):
`data/analytic.csv` (step 2.1), the model intermediates `results/X_imputed.csv`
and `results/oof_preds.npy` (step 4.1), and the manuscript DOCX/PDF
(`code/build_manuscript_docx.py`, `code/docx_to_pdf.py`).

**Not included (retrieved on demand from the original providers):** the raw NHANES
`.xpt` files, the NHIS public-use archives, the full GWAS Catalog release and the
FinnGen R10 summary statistics. Exact URLs, versions and accessions are listed in
[`DATA_SOURCES.md`](DATA_SOURCES.md); the downloaders fetch the survey files, and
the GWAS Catalog release is downloaded automatically by
`code/analysis_mr_instrument.py` on first run. FinnGen summary statistics are
queried over HTTP range requests and are never stored locally.

## Software environment

Python 3.12.10 with the pinned versions in [`requirements.txt`](requirements.txt).
Survey variance estimation uses `svy` (Taylor series linearisation with strata and
primary sampling units). Prediction and interpretation use scikit-learn,
LightGBM, XGBoost, CatBoost and InterpretML.

## Licences and citation

Code: MIT ([`LICENSE`](LICENSE)). Derived datasets produced in this study:
CC BY 4.0 ([`LICENSE-DATA.md`](LICENSE-DATA.md)). Third-party source data remain
under the terms of their original providers ([`DATA_SOURCES.md`](DATA_SOURCES.md)).

Citation metadata is provided in [`CITATION.cff`](CITATION.cff). If you use this
deposit, please cite the article and the deposit DOI.

## Contact

Fangwei Xue, School of Clinical and Basic Medical Sciences, Shandong First
Medical University, Jinan, China. E-mail: 4124640088@email.sdfmu.edu.cn
