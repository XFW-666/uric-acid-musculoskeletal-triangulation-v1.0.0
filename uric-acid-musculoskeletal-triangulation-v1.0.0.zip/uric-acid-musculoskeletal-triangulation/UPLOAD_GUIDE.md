# Upload guide (GitHub + Zenodo)

## 0. Fill in the two placeholders first

The manuscript's *Availability of data and materials* statement contains two
placeholders:

* `[REPOSITORY URL]` — the GitHub repository URL
* `[DOI]` — the Zenodo DOI

Replace them (in `manuscript/manuscript.md`), then rebuild the DOCX and PDF:

```bash
python code/build_manuscript_docx.py
python code/docx_to_pdf.py
```

## 1. GitHub

```bash
cd package/uric-acid-musculoskeletal-triangulation
git init -b main
git add .
git commit -m "Data, analysis code, results and figures for the uric acid / musculoskeletal triangulation study"
git remote add origin https://github.com/<USER>/uric-acid-musculoskeletal-triangulation.git
git push -u origin main
```

Notes:

* `data/analytic.csv` (29 MB) and `data/analytic_clean.csv` (27 MB) are the two
  largest tracked files and are well below GitHub's 100 MB per-file limit. If you
  prefer a lean repository, add them to `.gitignore` and keep them only in the
  Zenodo deposit (the figures can then not be regenerated from a fresh clone).
* Raw survey files, the GWAS Catalog release and the NHIS archives are already
  excluded by `.gitignore` and are fetched by the downloader scripts.
* Add the repository URL to the manuscript once the push succeeds.

## 2. Zenodo

Two equivalent routes.

**Route A — automatic (recommended, gives a versioned DOI per release)**

1. Sign in to <https://zenodo.org> with GitHub.
2. *Settings → GitHub* → toggle the repository on.
3. On GitHub, create a release: *Releases → Draft a new release*, tag `v1.0.0`,
   publish it.
4. Zenodo archives the release and mints a DOI (shown as a badge on the
   repository page). The *concept DOI* always resolves to the latest version.

**Route B — manual upload**

1. *New upload* on Zenodo.
2. Upload `zenodo/uric-acid-musculoskeletal-triangulation-v1.0.0.zip`.
3. Zenodo reads `CITATION.cff` and pre-fills the metadata; check the title,
   authors, licence (CC BY 4.0 for the derived data; MIT for the code) and add
   the article title under *Related works*.
4. Publish to mint the DOI.

## 3. Finish the data availability statement

Paste the DOI and the repository URL into the manuscript, rebuild the DOCX/PDF as
in step 0, and keep the same two values in the submission system's data
availability field.

## 4. Note on declarations

This deposit documents the data, code, results and figures of the study. Journal
policies on declaring the use of writing or analysis tools in the *manuscript*
are a separate matter and are handled in the manuscript's own declarations —
check the target journal's current policy and state whatever it requires before
submitting.
