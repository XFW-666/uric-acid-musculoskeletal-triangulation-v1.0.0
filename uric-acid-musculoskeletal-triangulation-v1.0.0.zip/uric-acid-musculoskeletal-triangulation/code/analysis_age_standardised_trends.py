"""Direct age standardisation of NHANES arthritis prevalence by cycle.

Standardises the survey-weighted prevalence of each cycle to the 2000 US adult
population across seven age strata, for comparison with the crude estimates and
with the independent NHIS series.

Input:  data/analytic_clean.csv
Output: results/trends_agestd.csv
"""
import pandas as pd, numpy as np, json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)

# 2000 US standard population, ages 20+ (10-year groups), normalised
STD = {"20-29": 13096, "30-39": 15185, "40-49": 15371, "50-59": 11115,
       "60-69": 6941, "70-79": 4976, "80+": 2918}
tot = sum(STD.values())
STDW = {k: v / tot for k, v in STD.items()}
print("standard weights:", {k: round(v, 4) for k, v in STDW.items()})

bins = [20, 30, 40, 50, 60, 70, 80, 200]
labels = ["20-29", "30-39", "40-49", "50-59", "60-69", "70-79", "80+"]
df["agegrp10"] = pd.cut(df["age"], bins, labels=labels, right=False)


def wprev(d, y="arthritis_bin", w="wt_comb"):
    d = d.dropna(subset=[y, w])
    if len(d) == 0 or d[w].sum() == 0:
        return np.nan
    return float(np.average(d[y], weights=d[w]))


rows = []
for cyc, g in df.groupby("cycle"):
    crude = wprev(g)
    num = 0.0; den = 0.0
    for lab, sw in STDW.items():
        sub = g[g["agegrp10"] == lab]
        p = wprev(sub)
        if np.isfinite(p):
            num += sw * p; den += sw
    std = num / den if den > 0 else np.nan
    rows.append({"cycle": cyc, "year": int(g["year"].iloc[0]), "n": len(g),
                 "crude": crude * 100, "agestd": std * 100,
                 "mean_age": float(np.average(g["age"], weights=g["wt_comb"]))})
out = pd.DataFrame(rows).sort_values("year")
out.to_csv(os.path.join(RES, "trends_agestd.csv"), index=False)
print("\n=== NHANES arthritis prevalence: crude vs age-standardised ===")
print(out.round(2).to_string(index=False))
print("\ncrude:     %.1f -> %.1f (change %+.1f pp)" % (out["crude"].iloc[0], out["crude"].iloc[-1],
                                                      out["crude"].iloc[-1] - out["crude"].iloc[0]))
print("agestd:    %.1f -> %.1f (change %+.1f pp)" % (out["agestd"].iloc[0], out["agestd"].iloc[-1],
                                                      out["agestd"].iloc[-1] - out["agestd"].iloc[0]))
print("mean age:  %.1f -> %.1f" % (out["mean_age"].iloc[0], out["mean_age"].iloc[-1]))
