"""Primary arthritis analyses: adjustment ladder, splines and dose-response.

Fits the survey-weighted logistic models for serum uric acid (continuous,
hyperuricaemia and quartiles) across the crude, demographic and fully adjusted
specifications, and the restricted cubic spline for the continuous exposure.

Input:  data/analytic_clean.csv
Output: results/main_results.json, results/rcs_arthritis_curve.csv,
        results/main_log.txt
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings, statsmodels.api as sm
warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
os.makedirs(RES, exist_ok=True)
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)

CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes",
        "hypertension", "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")

FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]
M2 = ["age", "sex", "race5"]
R = {}
LOG = []
def log(*a):
    s = " ".join(str(x) for x in a); print(s); LOG.append(s)

def to_pl(d, cols):
    x = pl.from_pandas(d[cols].copy())
    for c in cols:
        if c in CATS:
            x = x.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    return x

def samp(d, cols):
    return svy.Sample(to_pl(d, cols), svy.Design(stratum="strata", psu="psu",
                      wgt="wt_comb", singleton="center"))

def feats(xs):
    out = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(","); nm = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            out.append(svy.Cat(nm, ref=ref) if ref else svy.Cat(nm))
        else:
            out.append(x)
    return out

def fit(d, y, xs, family="binomial"):
    cols = set([y, "strata", "psu", "wt_comb"])
    for x in xs:
        cols.add(x[4:-1].split(",")[0].strip() if isinstance(x, str) and x.startswith("Cat(") else x)
    cols = [c for c in cols if c in d.columns]
    m = samp(d, cols).glm.fit(y=y, x=feats(xs), family=family)
    t = m.to_polars().to_pandas()
    return m, t

def show(t, label):
    log(f"\n--- {label}")
    for _, r in t.iterrows():
        log(f"    {r['term']:22s} est={r['estimate']:+.4f} se={r['std_err']:.4f} "
            f"OR={np.exp(r['estimate']):.3f} ({np.exp(r['conf_low']):.3f}-{np.exp(r['conf_high']):.3f}) p={r['p_value']:.4g}")

# ==================== C. Main models ====================
log("=" * 70); log("C. SURVEY-WEIGHTED LOGISTIC REGRESSION: ARTHRITIS"); log("=" * 70)
UAQ = ["Cat(ua_q,ref=1)"]
models = {}
for nm, cov in [("M1_crude", []), ("M2_age_sex_race", M2), ("M3_full", FULL)]:
    m, t = fit(df, "arthritis_bin", UAQ + cov)
    show(t, f"UA quartiles - {nm}")
    models[nm] = t.to_dict("records")

# continuous + hyperuricemia (full model)
m, t = fit(df, "arthritis_bin", ["ua"] + FULL); show(t, "UA per 1 mg/dL (full)")
models["continuous_full"] = t.to_dict("records")
m, t = fit(df, "arthritis_bin", ["hyperuricemia"] + FULL); show(t, "Hyperuricemia (full)")
models["hyperuricemia_full"] = t.to_dict("records")
m, t = fit(df, "arthritis_bin", ["log_ua"] + FULL); models["logua_full"] = t.to_dict("records")
R["main_models"] = models

# ==================== D. Restricted cubic splines ====================
log("\n" + "=" * 70); log("D. RESTRICTED CUBIC SPLINES (NONLINEARITY)"); log("=" * 70)
def rcs(x, knots):
    k = np.asarray(knots, float); x = np.asarray(x, float)
    n = len(k); basis = [x]
    for j in range(n - 2):
        t1 = np.maximum(x - k[j], 0) ** 3
        t2 = np.maximum(x - k[n - 2], 0) ** 3 * (k[n - 1] - k[j]) / (k[n - 1] - k[n - 2])
        t3 = np.maximum(x - k[n - 1], 0) ** 3 * (k[n - 2] - k[j]) / (k[n - 1] - k[n - 2])
        basis.append(t1 - t2 + t3)
    return np.column_stack(basis)

def wq(x, w, qs):
    x = np.asarray(x, float); w = np.asarray(w, float)
    m = ~np.isnan(x) & ~np.isnan(w); x, w = x[m], w[m]
    o = np.argsort(x); x, w = x[o], w[o]
    return np.interp(qs, np.cumsum(w) / w.sum(), x)

d = df.dropna(subset=["ua", "arthritis_bin"] + FULL).copy()
knots = wq(d["ua"], d["wt_comb"], [0.05, 0.35, 0.65, 0.95])
log("knots:", np.round(knots, 3))
B = rcs(d["ua"].to_numpy(), knots)
for j in range(1, B.shape[1]):
    d[f"rcs{j}"] = B[:, j]
rcs_terms = [f"rcs{j}" for j in range(1, B.shape[1])]
m, t = fit(d, "arthritis_bin", ["ua"] + rcs_terms + FULL)
show(t, "RCS arthritis")
nonlin = t[t["term"].isin(rcs_terms)]
# joint Wald test for nonlinear terms
try:
    tt = m.term_test(svy.Cat("ua_q", ref="1"))  # placeholder
except Exception:
    tt = None
R["rcs_arthritis"] = {"knots": list(np.round(knots, 3)), "coefs": t.to_dict("records")}
log(f"  nonlinear terms p-values: {nonlin['p_value'].tolist()}")

# curve: OR relative to median, over grid, with CI from predict()
grid = np.linspace(max(2.0, d["ua"].quantile(0.005)), d["ua"].quantile(0.995), 60)
ref_ua = float(np.median(d["ua"]))
def curve(d, y, fam, xname="ua", g=None, extra=None):
    g = grid if g is None else g
    dd = d.copy()
    Bg = rcs(g, knots)
    rows = []
    for i, v in enumerate(g):
        row = {c: d[c].median() for c in FULL}
        for c in ["sex", "race5", "edu3", "smoke", "alcohol", "diabetes", "hypertension"]:
            row[c] = d[c].mode()[0]
        row["ua"] = v
        for j in range(1, Bg.shape[1]):
            row[f"rcs{j}"] = Bg[i, j]
        rows.append(row)
    new = pl.DataFrame({k: [r[k] for r in rows] for k in rows[0]})
    for c in CATS:
        if c in new.columns:
            new = new.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    pred = model.predict(new).to_polars().to_pandas()
    return pred

# refit RCS model to reuse for prediction
cols = list(set(["arthritis_bin", "ua", "strata", "psu", "wt_comb"] + rcs_terms + FULL))
model = samp(d, cols).glm.fit(y="arthritis_bin", x=feats(["ua"] + rcs_terms + FULL), family="binomial")
pred = curve(d, "arthritis_bin", "binomial")
# OR relative to reference: need linear predictor difference; use logit from yhat
lg = np.log(pred["yhat"] / (1 - pred["yhat"]))
lg_ref = np.interp(ref_ua, grid, lg)
# reference CI band from same curve at ref
lo = np.log(pred["lci"] / (1 - pred["lci"])); hi = np.log(pred["uci"] / (1 - pred["uci"]))
lg_lo = np.interp(ref_ua, grid, lo); lg_hi = np.interp(ref_ua, grid, hi)
out = pd.DataFrame({"ua": grid, "or": np.exp(lg - lg_ref),
                    "lo": np.exp(lo - lg_hi), "hi": np.exp(hi - lg_lo)})
out.to_csv(os.path.join(RES, "rcs_arthritis_curve.csv"), index=False)
log("RCS curve head:\n" + out.head(8).round(3).to_string(index=False))
R["rcs_arthritis_curve"] = out.round(4).to_dict("records")

json.dump(R, open(os.path.join(RES, "main_results.json"), "w"), indent=1, default=str)
open(os.path.join(RES, "main_log.txt"), "w").write("\n".join(LOG))
print("\nStages C-D done.")
