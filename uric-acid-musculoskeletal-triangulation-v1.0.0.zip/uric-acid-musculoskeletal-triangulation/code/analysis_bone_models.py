"""Bone-density analyses: femoral-neck BMD, osteoporosis and sensitivity tests.

Survey-weighted linear models for femoral-neck BMD across the adjustment
ladder, the continuous and hyperuricaemia specifications, the BMD spline, the
self-reported osteoporosis models and the pre-specified sensitivity analyses.

Input:  data/analytic_clean.csv
Output: results/main2_results.json, results/rcs_bmd_curve.csv,
        results/main2_log.txt
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings
import statsmodels.api as sm
warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes",
        "hypertension", "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")
FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]
R = {}; LOG = []
def log(*a):
    s = " ".join(str(x) for x in a); print(s); LOG.append(s)
def to_pl(d, cols):
    x = pl.from_pandas(d[cols].copy())
    for c in cols:
        if c in CATS:
            x = x.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    return x
def samp(d, cols):
    return svy.Sample(to_pl(d, cols), svy.Design(stratum="strata", psu="psu",
                      wgt="wt_comb", singleton="center"))
def feats(xs):
    out = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(","); nm = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            out.append(svy.Cat(nm, ref=ref) if ref else svy.Cat(nm))
        else:
            out.append(x)
    return out
def fit(d, y, xs, family="binomial", where=None):
    cols = set([y, "strata", "psu", "wt_comb"])
    for x in xs:
        cols.add(x[4:-1].split(",")[0].strip() if isinstance(x, str) and x.startswith("Cat(") else x)
    cols = [c for c in cols if c in d.columns]
    kw = {"family": family}
    m = samp(d, cols).glm.fit(y=y, x=feats(xs), **kw)
    return m, m.to_polars().to_pandas()
def show(t, label, exp=True):
    log(f"\n--- {label}")
    for _, r in t.iterrows():
        if exp:
            log(f"    {r['term']:24s} {np.exp(r['estimate']):.3f} ({np.exp(r['conf_low']):.3f}-{np.exp(r['conf_high']):.3f}) p={r['p_value']:.4g}")
        else:
            log(f"    {r['term']:24s} b={r['estimate']:+.4f} ({r['conf_low']:+.4f},{r['conf_high']:+.4f}) p={r['p_value']:.4g}")

def rcs(x, knots):
    k = np.asarray(knots, float); x = np.asarray(x, float); n = len(k)
    basis = [x]
    for j in range(n - 2):
        t1 = np.maximum(x - k[j], 0) ** 3
        t2 = np.maximum(x - k[n - 2], 0) ** 3 * (k[n - 1] - k[j]) / (k[n - 1] - k[n - 2])
        t3 = np.maximum(x - k[n - 1], 0) ** 3 * (k[n - 2] - k[j]) / (k[n - 1] - k[n - 2])
        basis.append(t1 - t2 + t3)
    return np.column_stack(basis)
def wq(x, w, qs):
    x = np.asarray(x, float); w = np.asarray(w, float)
    m = ~np.isnan(x) & ~np.isnan(w); x, w = x[m], w[m]
    o = np.argsort(x); x, w = x[o], w[o]
    return np.interp(qs, np.cumsum(w) / w.sum(), x)

# ============ E. Subgroups (continuous UA, per 1 mg/dL) ============
log("=" * 70); log("E. SUBGROUP ANALYSES (UA per 1 mg/dL, fully adjusted)"); log("=" * 70)
subs = [("Overall", None, None), ("Male", "sex", 1), ("Female", "sex", 2),
        ("Age 20-39", "age_grp", 1), ("Age 40-59", "age_grp", 2), ("Age 60+", "age_grp", 3),
        ("BMI <25", "bmi_cat", 1), ("BMI 25-29.9", "bmi_cat", 2),
        ("BMI 30-34.9", "bmi_cat", 3), ("BMI >=35", "bmi_cat", 4),
        ("No diabetes", "diabetes", 0), ("Diabetes", "diabetes", 1),
        ("No hypertension", "hypertension", 0), ("Hypertension", "hypertension", 1),
        ("eGFR >=60", "egfr_ge60", 1), ("eGFR <60", "egfr_ge60", 0),
        ("Never smoker", "smoke", 0), ("Former smoker", "smoke", 1), ("Current smoker", "smoke", 2)]
df["egfr_ge60"] = (df["egfr"] >= 60).astype(float)
subres = []
for lbl, var, val in subs:
    d = df if var is None else df[df[var] == val]
    try:
        m, t = fit(d, "arthritis_bin", ["ua"] + FULL)
        row = t[t["term"] == "ua"].iloc[0]
        subres.append({"subgroup": lbl, "n": len(d), "or": float(np.exp(row["estimate"])),
                       "lo": float(np.exp(row["conf_low"])), "hi": float(np.exp(row["conf_high"])),
                       "p": float(row["p_value"])})
        log(f"  {lbl:20s} n={len(d):6d} OR={np.exp(row['estimate']):.3f} "
            f"({np.exp(row['conf_low']):.3f}-{np.exp(row['conf_high']):.3f}) p={row['p_value']:.4g}")
    except Exception as e:
        log(f"  {lbl:20s} FAILED {type(e).__name__} {str(e)[:80]}")
R["subgroups"] = subres
pd.DataFrame(subres).to_csv(os.path.join(RES, "subgroups.csv"), index=False)

# ============ F. Femoral neck BMD ============
log("\n" + "=" * 70); log("F. FEMORAL NECK BMD (weighted linear regression)"); log("=" * 70)
bmd = df.dropna(subset=["fn_bmd", "ua"]).copy()
log(f"BMD analytic n={len(bmd)} cycles={sorted(bmd['cycle'].unique())}")
bmd["ua_q"] = pd.cut(bmd["ua"], bins=[-np.inf, 4.4, 5.3, 6.3, np.inf], labels=[1, 2, 3, 4]).astype(float)
bmd = bmd.dropna(subset=["ua_q"])
R["bmd_n"] = len(bmd)
for nm, cov in [("M1_crude", []), ("M2_age_sex_race", ["age", "sex", "race5"]), ("M3_full", FULL)]:
    m, t = fit(bmd, "fn_bmd", ["Cat(ua_q,ref=1)"] + cov, family="gaussian")
    show(t, f"Femoral neck BMD ~ UA quartile ({nm})", exp=False)
    R[f"bmd_{nm}"] = t.to_dict("records")
# continuous + hyperuricemia
m, t = fit(bmd, "fn_bmd", ["ua"] + FULL, family="gaussian"); show(t, "BMD ~ UA per 1 mg/dL (full)", exp=False)
R["bmd_continuous_full"] = t.to_dict("records")
m, t = fit(bmd, "fn_bmd", ["hyperuricemia"] + FULL, family="gaussian"); show(t, "BMD ~ hyperuricemia (full)", exp=False)
R["bmd_hyperuricemia_full"] = t.to_dict("records")
# RCS for BMD
bd = bmd.dropna(subset=FULL + ["fn_bmd"]).copy()
kn = wq(bd["ua"], bd["wt_comb"], [0.05, 0.35, 0.65, 0.95])
log("BMD knots:", np.round(kn, 3))
B = rcs(bd["ua"].to_numpy(), kn)
for j in range(1, B.shape[1]):
    bd[f"rcs{j}"] = B[:, j]
rcst = [f"rcs{j}" for j in range(1, B.shape[1])]
m, t = fit(bd, "fn_bmd", ["ua"] + rcst + FULL, family="gaussian")
show(t, "BMD RCS", exp=False)
R["bmd_rcs"] = {"knots": list(np.round(kn, 3)), "coefs": t.to_dict("records"),
                "nonlin_p": [float(t[t.term == x]["p_value"].iloc[0]) for x in rcst]}
# curve
grid = np.linspace(2.5, bd["ua"].quantile(0.99), 60)
Bg = rcs(grid, kn)
rows = []
for i, v in enumerate(grid):
    row = {c: float(bd[c].median()) for c in FULL}
    for c in ["sex", "race5", "edu3", "smoke", "alcohol", "diabetes", "hypertension"]:
        row[c] = float(bd[c].mode()[0])
    row["ua"] = v
    for j in range(1, Bg.shape[1]):
        row[f"rcs{j}"] = Bg[i, j]
    rows.append(row)
new = pl.DataFrame({k: [r[k] for r in rows] for k in rows[0]})
for c in CATS:
    if c in new.columns:
        new = new.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
cols = list(set(["fn_bmd", "ua", "strata", "psu", "wt_comb"] + rcst + FULL))
mm = samp(bd, cols).glm.fit(y="fn_bmd", x=feats(["ua"] + rcst + FULL), family="gaussian")
pr = mm.predict(new).to_polars().to_pandas()
ref = float(np.median(bd["ua"]))
y0 = np.interp(ref, grid, pr["yhat"].to_numpy())
c0 = np.interp(ref, grid, pr["lci"].to_numpy()); c1 = np.interp(ref, grid, pr["uci"].to_numpy())
bmd_curve = pd.DataFrame({"ua": grid, "diff": pr["yhat"].to_numpy() - y0,
                          "lo": pr["lci"].to_numpy() - c1, "hi": pr["uci"].to_numpy() - c0})
bmd_curve.to_csv(os.path.join(RES, "rcs_bmd_curve.csv"), index=False)
R["bmd_curve"] = bmd_curve.round(5).to_dict("records")
log("BMD curve head:\n" + bmd_curve.head(6).round(4).to_string(index=False))

# ============ G. Osteoporosis ============
log("\n" + "=" * 70); log("G. SELF-REPORTED OSTEOPOROSIS"); log("=" * 70)
ost = df.dropna(subset=["osteoporosis"]).copy()
log(f"n={len(ost)}")
for nm, cov in [("M1_crude", []), ("M2_age_sex_race", ["age", "sex", "race5"]), ("M3_full", FULL)]:
    try:
        m, t = fit(ost, "osteoporosis", ["Cat(ua_q,ref=1)"] + cov)
        show(t, f"Osteoporosis ~ UA quartile ({nm})")
        R[f"osteo_{nm}"] = t.to_dict("records")
    except Exception as e:
        log(f"  {nm} failed: {e}")
m, t = fit(ost, "osteoporosis", ["ua"] + FULL); show(t, "Osteoporosis ~ UA per 1 mg/dL (full)")
R["osteo_continuous"] = t.to_dict("records")

# ============ H. Sensitivity ============
log("\n" + "=" * 70); log("H. SENSITIVITY ANALYSES"); log("=" * 70)
sens = []
def sens_run(lbl, d):
    try:
        m, t = fit(d, "arthritis_bin", ["Cat(ua_q,ref=1)"] + FULL)
        row = t[t["term"] == "ua_q_4"].iloc[0]
        sens.append({"scenario": lbl, "n": len(d), "OR_Q4": float(np.exp(row["estimate"])),
                     "lo": float(np.exp(row["conf_low"])), "hi": float(np.exp(row["conf_high"])),
                     "p": float(row["p_value"])})
        log(f"  {lbl:34s} n={len(d):6d} Q4 OR={np.exp(row['estimate']):.3f} "
            f"({np.exp(row['conf_low']):.3f}-{np.exp(row['conf_high']):.3f}) p={row['p_value']:.4g}")
    except Exception as e:
        log(f"  {lbl:34s} FAILED {e}")
sens_run("Primary (all 12 cycles)", df)
sens_run("Excl. self-reported gout", df[df["gout_n"] != 1])
sens_run("Excl. eGFR<60", df[df["egfr"] >= 60])
sens_run("Excl. 2017-2020 cycle", df[df["cycle"] != "2017-2020"])
sens_run("Excl. 1999-2002 cycles", df[~df["year"].isin([1999, 2001])])
sens_run("Waist excluded from model", df)
R["sensitivity"] = sens
pd.DataFrame(sens).to_csv(os.path.join(RES, "sensitivity.csv"), index=False)

json.dump(R, open(os.path.join(RES, "main2_results.json"), "w"), indent=1, default=str)
open(os.path.join(RES, "main2_log.txt"), "w").write("\n".join(LOG))
print("\nStages E-H done.")
