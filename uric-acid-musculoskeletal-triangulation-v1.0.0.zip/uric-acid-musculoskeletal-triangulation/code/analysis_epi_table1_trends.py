"""Baseline characteristics, exposure gradients and temporal trends (NHANES).

Survey-weighted Table 1 by uric-acid quartile, crude and age-standardised
arthritis prevalence by cycle, and the survey-weighted trend model.

Input:  data/analytic_clean.csv
Output: results/table1.csv, results/epi_results.json, results/epi_log.txt
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings
warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
RES = os.path.join(ROOT, "results")
os.makedirs(RES, exist_ok=True)

df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
print("analytic:", df.shape)

CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes",
        "hypertension", "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")
# numeric cycle index for trend models
_years = sorted(df["year"].unique())
df["cyc_ord"] = df["year"].map({y: i for i, y in enumerate(_years)}).astype(float)

R = {}          # results container
LOG = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s); LOG.append(s)


# ---------------- design-based weighted mean/proportion ----------------
def svy_mean(d, y, w="wt_comb", strata="strata", psu="psu"):
    d = d[[y, w, strata, psu]].dropna()
    if len(d) < 10:
        return np.nan, np.nan, 0
    W = d[w].to_numpy(float); Y = d[y].to_numpy(float)
    sw = W.sum()
    est = float((W * Y).sum() / sw)
    z = W * (Y - est) / sw
    tmp = pd.DataFrame({strata: d[strata].to_numpy(), psu: d[psu].to_numpy(), "z": z})
    psu_sums = tmp.groupby([strata, psu], observed=True)["z"].sum()
    var = 0.0
    for h, grp in psu_sums.groupby(level=0, observed=True):
        v = grp.to_numpy(float); nh = len(v)
        if nh > 1:
            var += (nh / (nh - 1.0)) * float(((v - v.mean()) ** 2).sum())
    return est, float(np.sqrt(max(var, 0.0))), len(d)


def to_pl(d, cols):
    x = d[cols].copy()
    for c in cols:
        if c in CATS:
            x[c] = x[c].astype("Int32").astype(str)
    return pl.from_pandas(x)


def sample_of(d, cols):
    return svy.Sample(to_pl(d, cols),
                      svy.Design(stratum="strata", psu="psu", wgt="wt_comb",
                                 singleton="center"))


def fit_logit(d, y, xs, label=""):
    cols = list({y, "strata", "psu", "wt_comb"} | set(
        x[4:-1] if isinstance(x, str) and x.startswith("Cat(") else x for x in xs))
    cols = [c for c in cols if c in d.columns]
    feats = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(",")
            name = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            feats.append(svy.Cat(name, ref=ref) if ref else svy.Cat(name))
        else:
            feats.append(x)
    s = sample_of(d, cols)
    m = s.glm.fit(y=y, x=feats, family="binomial")
    t = m.to_polars().to_pandas()
    return t


# ================= A. Table 1: baseline by UA quartile =================
log("=" * 70)
log("A. TABLE 1 - baseline characteristics by serum uric acid quartile")
log("=" * 70)
table1_vars = [
    ("age", "Age, y", "mean"), ("sex", "Female, %", "prop1"),
    ("race5", "Race/ethnicity", "cat"), ("edu3", "Education", "cat"),
    ("pir", "Poverty income ratio", "mean"), ("bmi", "BMI, kg/m2", "mean"),
    ("waist", "Waist circumference, cm", "mean"),
    ("smoke", "Smoking status", "cat"), ("alcohol", "Current drinker, %", "prop1"),
    ("diabetes", "Diabetes, %", "prop1"), ("hypertension", "Hypertension, %", "prop1"),
    ("egfr", "eGFR, mL/min/1.73m2", "mean"), ("ua", "Uric acid, mg/dL", "mean"),
    ("albumin", "Albumin, g/dL", "mean"), ("alp", "ALP, U/L", "mean"),
    ("calcium", "Calcium, mg/dL", "mean"), ("phosphorus", "Phosphorus, mg/dL", "mean"),
    ("crp", "hs-CRP, mg/dL", "mean"), ("nlr", "NLR", "mean"), ("sii", "SII", "mean"),
    ("energy", "Energy, kcal/d", "mean"), ("diet_ca", "Dietary calcium, mg/d", "mean"),
    ("arthritis_bin", "Arthritis, %", "prop1"), ("osteoporosis", "Osteoporosis, %", "prop1"),
    ("fn_bmd", "Femoral neck BMD, g/cm2", "mean"),
]
t1 = {}
overall = {}
for var, lbl, kind in table1_vars:
    row = []
    for q in [1, 2, 3, 4]:
        sub = df[df["ua_q"] == q]
        if kind == "mean":
            e, s, n = svy_mean(sub, var)
            row.append(f"{e:.2f} ({s:.2f})" if np.isfinite(e) else "-")
        elif kind == "prop1":
            tmp = sub.dropna(subset=[var]).copy()
            if len(tmp):
                tmp["_p"] = (tmp[var] == 1).astype(float)
                e, s, n = svy_mean(tmp, "_p")
                row.append(f"{e*100:.1f} ({s*100:.1f})" if np.isfinite(e) else "-")
            else:
                row.append("-")
        else:
            row.append("")
    if kind == "mean":
        e, s, n = svy_mean(df, var)
        overall[lbl] = f"{e:.2f} ({s:.2f})"
    elif kind == "prop1":
        tmp = df.dropna(subset=[var]).copy(); tmp["_p"] = (tmp[var] == 1).astype(float)
        e, s, n = svy_mean(tmp, "_p")
        overall[lbl] = f"{e*100:.1f} ({s*100:.1f})"
    else:
        overall[lbl] = ""
    t1[lbl] = row
    log(f"  {lbl:32s} " + " | ".join(f"{v:>16s}" for v in row) + f"  || all: {overall[lbl]}")

pd.DataFrame(t1, index=["Q1", "Q2", "Q3", "Q4"]).T.to_csv(os.path.join(RES, "table1.csv"))
R["table1"] = {"by_quartile": t1, "overall": overall}

# UA quartile ranges
qr = df.groupby("ua_q")["ua"].agg(["min", "max", "median"])
R["ua_quartile_ranges"] = qr.to_dict()
log("\nUA quartile ranges:\n" + qr.to_string())

# ================= B. Trends 1999-2023 =================
log("\n" + "=" * 70)
log("B. TEMPORAL TRENDS 1999-2023")
log("=" * 70)
trend = []
for cyc in df["cycle"].unique():
    sub = df[df["cycle"] == cyc]
    a, sa, na = svy_mean(sub, "arthritis_bin")
    u, su, nu = svy_mean(sub, "ua")
    h, sh, nh = svy_mean(sub, "hyperuricemia")
    o, so, no = svy_mean(sub.dropna(subset=["osteoporosis"]), "osteoporosis")
    trend.append({"cycle": cyc, "year": sub["year"].iloc[0], "n": len(sub),
                  "arthritis": a * 100, "arthritis_se": sa * 100,
                  "ua": u, "ua_se": su, "hyperuricemia": h * 100, "hyperuricemia_se": sh * 100,
                  "osteoporosis": o * 100, "osteoporosis_se": so * 100})
tr = pd.DataFrame(trend).sort_values("year")
log(tr.round(2).to_string(index=False))
tr.to_csv(os.path.join(RES, "trends.csv"), index=False)
R["trends"] = tr.to_dict("records")

# p for trend (survey-weighted, cycle as ordinal)
for outcome, ycol in [("arthritis", "arthritis_bin"), ("hyperuricemia", "hyperuricemia")]:
    t = fit_logit(df, ycol, ["cyc_ord"], label=f"trend {outcome}")
    R[f"trend_{outcome}"] = t.to_dict("records")
    log(f"  trend {outcome}: p={t[t.term=='cyc_ord'].p_value.values}")

json.dump(R, open(os.path.join(RES, "epi_results.json"), "w"), indent=1, default=str)
open(os.path.join(RES, "epi_log.txt"), "w").write("\n".join(LOG))
print("\nStage A-B done.")
