"""Append the continuous and hyperuricaemia terms to the adjustment ladder.

The main arthritis script stores the quartile contrast at each adjustment step;
this step adds the continuous (per 1 mg/dL) and hyperuricaemia contrasts for the
crude and demographic models to the same result file.

Input:  data/analytic_clean.csv, results/main_results.json
Output: results/main_results.json (updated)
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings
warnings.filterwarnings("ignore")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes", "hypertension",
        "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")
FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]
M2 = ["age", "sex", "race5"]

def to_pl(d, cols):
    x = pl.from_pandas(d[cols].copy())
    for c in cols:
        if c in CATS:
            x = x.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    return x

def feats(xs):
    out = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(","); nm = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            out.append(svy.Cat(nm, ref=ref) if ref else svy.Cat(nm))
        else:
            out.append(x)
    return out

def fit(d, y, xs):
    cols = set([y, "strata", "psu", "wt_comb"])
    for x in xs:
        cols.add(x[4:-1].split(",")[0].strip() if isinstance(x, str) and x.startswith("Cat(") else x)
    cols = [c for c in cols if c in d.columns]
    s = svy.Sample(to_pl(d, cols), svy.Design(stratum="strata", psu="psu", wgt="wt_comb",
                                              singleton="center"))
    return s.glm.fit(y=y, x=feats(xs), family="binomial").to_polars().to_pandas().to_dict("records")

main = json.load(open(os.path.join(RES, "main_results.json")))
for mname, cov in [("M1_crude", []), ("M2_age_sex_race", M2)]:
    recs = fit(df, "arthritis_bin", ["ua"] + cov)
    recs += fit(df, "arthritis_bin", ["hyperuricemia"] + cov)
    main["main_models"][mname] = main["main_models"][mname] + [r for r in recs
                                                               if r["term"] in ("ua", "hyperuricemia")]
    print(mname, [ (r["term"], round(float(r["estimate"]), 4)) for r in recs
                   if r["term"] in ("ua", "hyperuricemia")])
json.dump(main, open(os.path.join(RES, "main_results.json"), "w"), indent=1, default=str)
print("updated main_results.json")
