"""Pharmacovigilance: reporting odds ratios for urate-lowering drugs (FAERS).

Computes disproportionality (reporting odds ratio with 95% confidence interval)
for allopurinol, febuxostat, benzbromarone, probenecid and pegloticase across
musculoskeletal reaction terms via the openFDA API.

Input:  openFDA FAERS (remote)
Output: results/faers_disproportionality.csv, results/faers_totals.json
"""
import requests, json, os, time, numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results"); os.makedirs(RES, exist_ok=True)
S = requests.Session()
S.headers.update({"User-Agent": "Mozilla/5.0 (compatible; research-tool)"})
API = "https://api.fda.gov/drug/event.json"


def count(search):
    for _ in range(4):
        try:
            r = S.get(API, params={"search": search, "limit": 1}, timeout=60)
            if r.status_code == 200:
                return int(r.json()["meta"]["results"]["total"])
            if r.status_code == 404:
                return 0
        except Exception:
            pass
        time.sleep(2)
    return None


DRUGS = {"allopurinol": 'patient.drug.medicinalproduct:"ALLOPURINOL"',
         "febuxostat": 'patient.drug.medicinalproduct:"FEBUXOSTAT"',
         "colchicine": 'patient.drug.medicinalproduct:"COLCHICINE"'}
EVENTS = ["FEMUR FRACTURE", "HIP FRACTURE", "RIB FRACTURE", "SPINAL FRACTURE",
          "WRIST FRACTURE", "FALL", "OSTEOPOROSIS", "BONE PAIN", "ARTHRALGIA",
          "OSTEOARTHRITIS", "GOUT", "MUSCULAR WEAKNESS"]

print("=== totals ===")
total_all = count("patient.reaction.reactionmeddrapt:*")
print("total reports:", total_all)
drug_tot = {}
for d, q in DRUGS.items():
    drug_tot[d] = count(q)
    print(f"  {d:12s} {drug_tot[d]}")
ev_tot = {}
for e in EVENTS:
    ev_tot[e] = count(f'patient.reaction.reactionmeddrapt:"{e}"')
    print(f"  event {e:20s} {ev_tot[e]}")

print("\n=== drug x event cells ===")
rows = []
for d, q in DRUGS.items():
    for e in EVENTS:
        a = count(f'{q} AND patient.reaction.reactionmeddrapt:"{e}"')
        if a is None:
            continue
        A = a
        B = drug_tot[d] - A
        C = ev_tot[e] - A
        D = total_all - A - B - C
        if min(A, B, C, D) <= 0:
            continue
        ror = (A * D) / (B * C)
        se = np.sqrt(1 / A + 1 / B + 1 / C + 1 / D)
        lo, hi = np.exp(np.log(ror) - 1.96 * se), np.exp(np.log(ror) + 1.96 * se)
        rows.append({"drug": d, "event": e, "a": A, "drug_total": drug_tot[d],
                     "event_total": ev_tot[e], "ror": ror, "lo": lo, "hi": hi,
                     "chi2_lower_bound": A >= 3 and lo > 1})
        print(f"  {d:12s} {e:20s} a={A:5d} ROR={ror:6.2f} ({lo:.2f}-{hi:.2f})")
        time.sleep(0.25)

out = pd.DataFrame(rows)
out.to_csv(os.path.join(RES, "faers_disproportionality.csv"), index=False)

# indication-matched: febuxostat vs allopurinol (same indication: gout)
print("\n=== indication-matched comparison (febuxostat vs allopurinol) ===")
matched = []
for e in EVENTS:
    A = count(f'{DRUGS["febuxostat"]} AND patient.reaction.reactionmeddrapt:"{e}"')
    C = count(f'{DRUGS["allopurinol"]} AND patient.reaction.reactionmeddrapt:"{e}"')
    if A is None or C is None:
        continue
    B = drug_tot["febuxostat"] - A
    D = drug_tot["allopurinol"] - C
    if min(A, B, C, D) <= 0:
        continue
    ror = (A * D) / (B * C)
    se = np.sqrt(1 / A + 1 / B + 1 / C + 1 / D)
    matched.append({"event": e, "feb_a": A, "allo_c": C, "ror": ror,
                    "lo": np.exp(np.log(ror) - 1.96 * se),
                    "hi": np.exp(np.log(ror) + 1.96 * se)})
    print(f"  {e:20s} feb={A:5d} allo={C:5d} ROR={ror:6.2f} "
          f"({np.exp(np.log(ror)-1.96*se):.2f}-{np.exp(np.log(ror)+1.96*se):.2f})")
    time.sleep(0.25)
pd.DataFrame(matched).to_csv(os.path.join(RES, "faers_matched.csv"), index=False)
json.dump({"total_reports": total_all, "drug_totals": drug_tot, "event_totals": ev_tot},
          open(os.path.join(RES, "faers_totals.json"), "w"), indent=1)
print("\nFAERS done.")
