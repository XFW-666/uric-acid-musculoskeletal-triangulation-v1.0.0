"""Extended pharmacovigilance analyses: indication matching and restriction.

Adds colchicine as an indication comparator, the febuxostat-versus-allopurinol
matched comparison, and the analysis restricted to reports whose recorded
indication is gout.

Input:  openFDA FAERS (remote)
Output: results/faers_extended.csv, results/faers_matched.csv,
        results/faers_indication_restricted.csv,
        results/faers_extended_totals.json
"""
import requests, json, os, time, numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
S = requests.Session(); S.headers.update({"User-Agent": "Mozilla/5.0 research-tool"})
API = "https://api.fda.gov/drug/event.json"


def count(search):
    for _ in range(4):
        try:
            r = S.get(API, params={"search": search, "limit": 1}, timeout=60)
            if r.status_code == 200:
                return int(r.json()["meta"]["results"]["total"])
            if r.status_code == 404:
                return 0
        except Exception:
            pass
        time.sleep(2)
    return None


DRUGS = {
    "allopurinol": 'patient.drug.medicinalproduct:"ALLOPURINOL"',
    "febuxostat": 'patient.drug.medicinalproduct:"FEBUXOSTAT"',
    "benzbromarone": 'patient.drug.medicinalproduct:"BENZBROMARONE"',
    "probenecid": 'patient.drug.medicinalproduct:"PROBENECID"',
    "pegloticase": 'patient.drug.medicinalproduct:"PEGLOTICASE"',
    "colchicine": 'patient.drug.medicinalproduct:"COLCHICINE"',
}
EVENTS = ["FEMUR FRACTURE", "HIP FRACTURE", "RIB FRACTURE", "SPINAL FRACTURE",
          "FALL", "OSTEOPOROSIS", "BONE PAIN", "ARTHRALGIA", "OSTEOARTHRITIS",
          "GOUT", "MUSCULAR WEAKNESS", "BACK PAIN"]

total_all = count("patient.reaction.reactionmeddrapt:*")
print("total reports:", total_all)
rows = []
drug_tot = {}
for d, q in DRUGS.items():
    t = count(q)
    drug_tot[d] = t
    print(f"  {d:16s} {t}")
ev_tot = {}
for e in EVENTS:
    ev_tot[e] = count(f'patient.reaction.reactionmeddrapt:"{e}"')
print("  events done")

print("\n=== drug x event (all reports) ===")
for d, q in DRUGS.items():
    for e in EVENTS:
        a = count(f'{q} AND patient.reaction.reactionmeddrapt:"{e}"')
        if a is None or a == 0:
            continue
        A, B, C, D = a, drug_tot[d] - a, ev_tot[e] - a, total_all - a - (drug_tot[d] - a) - (ev_tot[e] - a)
        if min(A, B, C, D) <= 0:
            continue
        ror = (A * D) / (B * C)
        se = np.sqrt(1 / A + 1 / B + 1 / C + 1 / D)
        rows.append({"analysis": "all", "drug": d, "event": e, "a": A, "ror": ror,
                     "lo": np.exp(np.log(ror) - 1.96 * se), "hi": np.exp(np.log(ror) + 1.96 * se)})
        time.sleep(0.2)
allr = pd.DataFrame(rows)
allr.to_csv(os.path.join(RES, "faers_extended.csv"), index=False)

# indication-restricted: denominator = reports for that drug whose indication mentions gout
print("\n=== indication-restricted (gout-indicated reports only) ===")
ind = []
for d, q in DRUGS.items():
    base = count(f'{q} AND patient.drug.drugindication:"GOUT"')
    if not base:
        continue
    for e in EVENTS:
        a = count(f'{q} AND patient.drug.drugindication:"GOUT" AND patient.reaction.reactionmeddrapt:"{e}"')
        if a is None or a < 3:
            continue
        ind.append({"drug": d, "event": e, "a": a, "denom_gout_indicated": base,
                    "prop": a / base})
        time.sleep(0.2)
    print(f"  {d:16s} gout-indicated reports = {base}")
indf = pd.DataFrame(ind)
indf.to_csv(os.path.join(RES, "faers_indication_restricted.csv"), index=False)
if len(indf):
    print("\n  within gout-indicated reports, proportion reporting each event:")
    piv = indf.pivot_table(index="event", columns="drug", values="prop")
    print((piv * 100).round(2).to_string())

json.dump({"total": total_all, "drug_totals": drug_tot, "event_totals": ev_tot},
          open(os.path.join(RES, "faers_extended_totals.json"), "w"), indent=1)
print("\nExtended FAERS done")
