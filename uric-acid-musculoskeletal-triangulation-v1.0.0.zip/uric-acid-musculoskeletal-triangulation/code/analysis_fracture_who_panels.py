"""Curve and category data for the fracture, T-score and mediation panels.

Fits the fracture spline curve and tabulates WHO T-score category prevalence
and odds ratios by uric-acid quartile.

Input:  data/analytic_clean.csv
Output: results/rcs_fracture_curve.csv, results/who_by_quartile.csv,
        results/who_ors.json
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings
warnings.filterwarnings("ignore")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes", "hypertension",
        "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")
FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]

def to_pl(d, cols):
    x = pl.from_pandas(d[cols].copy())
    for c in cols:
        if c in CATS:
            x = x.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    return x
def feats(xs):
    out = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(","); nm = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            out.append(svy.Cat(nm, ref=ref) if ref else svy.Cat(nm))
        else:
            out.append(x)
    return out
def fit(d, y, xs, family="binomial"):
    cols = set([y, "strata", "psu", "wt_comb"])
    for x in xs:
        cols.add(x[4:-1].split(",")[0].strip() if isinstance(x, str) and x.startswith("Cat(") else x)
    cols = [c for c in cols if c in d.columns]
    s = svy.Sample(to_pl(d, cols), svy.Design(stratum="strata", psu="psu",
                   wgt="wt_comb", singleton="center"))
    return s, s.glm.fit(y=y, x=feats(xs), family=family)
def wq(x, w, qs):
    x = np.asarray(x, float); w = np.asarray(w, float)
    m = ~np.isnan(x) & ~np.isnan(w); x, w = x[m], w[m]
    o = np.argsort(x); x, w = x[o], w[o]
    return np.interp(qs, np.cumsum(w) / w.sum(), x)
def rcs(x, knots):
    k = np.asarray(knots, float); x = np.asarray(x, float); n = len(k)
    b = [x]
    for j in range(n - 2):
        t1 = np.maximum(x - k[j], 0) ** 3
        t2 = np.maximum(x - k[n - 2], 0) ** 3 * (k[n - 1] - k[j]) / (k[n - 1] - k[n - 2])
        t3 = np.maximum(x - k[n - 1], 0) ** 3 * (k[n - 2] - k[j]) / (k[n - 1] - k[n - 2])
        b.append(t1 - t2 + t3)
    return np.column_stack(b)

# ---------- fracture RCS curve ----------
fx = df.dropna(subset=["osq_fracture", "ua"] + FULL).copy()
kn = wq(fx["ua"], fx["wt_comb"], [0.05, 0.35, 0.65, 0.95])
B = rcs(fx["ua"].to_numpy(), kn)
for j in range(1, B.shape[1]):
    fx[f"rcs{j}"] = B[:, j]
rt = [f"rcs{j}" for j in range(1, B.shape[1])]
s, m = fit(fx, "osq_fracture", ["ua"] + rt + FULL)
grid = np.linspace(2.5, 9.5, 55)
Bg = rcs(grid, kn)
rows = []
for i, v in enumerate(grid):
    row = {c: float(fx[c].median()) for c in FULL}
    for c in ["sex", "race5", "edu3", "smoke", "alcohol", "diabetes", "hypertension"]:
        row[c] = float(fx[c].mode()[0])
    row["ua"] = v
    for j in range(1, Bg.shape[1]):
        row[f"rcs{j}"] = Bg[i, j]
    rows.append(row)
new = pl.DataFrame({k: [r[k] for r in rows] for k in rows[0]})
for c in CATS:
    if c in new.columns:
        new = new.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
pr = m.predict(new).to_polars().to_pandas()
lg = np.log(pr["yhat"] / (1 - pr["yhat"]))
lo = np.log(pr["lci"] / (1 - pr["lci"])); hi = np.log(pr["uci"] / (1 - pr["uci"]))
ref = float(np.median(fx["ua"]))
r0 = np.interp(ref, grid, lg); rl = np.interp(ref, grid, lo); rh = np.interp(ref, grid, hi)
out = pd.DataFrame({"ua": grid, "or": np.exp(lg - r0), "lo": np.exp(lo - rh), "hi": np.exp(hi - rl)})
out.to_csv(os.path.join(RES, "rcs_fracture_curve.csv"), index=False)
print("fracture RCS curve saved; OR range", round(out["or"].min(), 3), "-", round(out["or"].max(), 3))

# ---------- WHO T-score by quartile ----------
b = df.dropna(subset=["fn_bmd"]).copy()
refv = b[b["age"].between(20, 29)].groupby("sex")["fn_bmd"].agg(["mean", "std"])
b["tscore"] = [(r["fn_bmd"] - refv.loc[r["sex"], "mean"]) / refv.loc[r["sex"], "std"]
               if r["sex"] in refv.index else np.nan for _, r in b.iterrows()]
b["osteopenia"] = ((b["tscore"] > -2.5) & (b["tscore"] <= -1.0)).astype(float)
b["osteoporosis"] = (b["tscore"] <= -2.5).astype(float)
rows = []
for q in [1, 2, 3, 4]:
    sub = b[b["ua_q"] == q]
    rows.append({"ua_q": int(q), "n": len(sub),
                 "osteopenia": float(np.average(sub["osteopenia"], weights=sub["wt_comb"]) * 100),
                 "osteoporosis": float(np.average(sub["osteoporosis"], weights=sub["wt_comb"]) * 100)})
wqdf = pd.DataFrame(rows)
wqdf.to_csv(os.path.join(RES, "who_by_quartile.csv"), index=False)
print("\nWHO T-score categories by UA quartile (%):")
print(wqdf.round(2).to_string(index=False))

# ORs for the panel
ors = {}
for lab in ["osteopenia", "osteoporosis"]:
    s2, m2 = fit(b, lab, ["Cat(ua_q,ref=1)"] + FULL)
    t = m2.to_polars().to_pandas()
    tt = t[t["term"].str.startswith("ua_q")].copy()
    tt["or"] = np.exp(tt["estimate"]); tt["lo"] = np.exp(tt["conf_low"]); tt["hi"] = np.exp(tt["conf_high"])
    ors[lab] = tt[["term", "or", "lo", "hi", "p_value"]].to_dict("records")
    print(f"\n{lab} fully adjusted ORs:")
    for r in ors[lab]:
        print(f"   {r['term']}: {r['or']:.3f} ({r['lo']:.3f}-{r['hi']:.3f}) p={r['p_value']:.4g}")
json.dump(ors, open(os.path.join(RES, "who_ors.json"), "w"), indent=1, default=str)
print("\npanel data ready")
