"""Hard clinical endpoints: fracture, WHO T-score categories and the BMD pathway.

Self-reported fracture across the adjustment ladder, femoral-neck T-scores
referenced to NHANES adults aged 20-29 (osteopenia, osteoporosis), and the
three-node mediation pathway uric acid -> femoral-neck BMD -> fracture.

Input:  data/analytic_clean.csv
Output: results/fracture_results.json, results/fracture_log.txt
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings
warnings.filterwarnings("ignore")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes", "hypertension",
        "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")
FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]
M2 = ["age", "sex", "race5"]
R = {}; LOG = []
def log(*a):
    s = " ".join(str(x) for x in a); print(s); LOG.append(s)

def to_pl(d, cols):
    x = pl.from_pandas(d[cols].copy())
    for c in cols:
        if c in CATS:
            x = x.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    return x
def feats(xs):
    out = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(","); nm = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            out.append(svy.Cat(nm, ref=ref) if ref else svy.Cat(nm))
        else:
            out.append(x)
    return out
def fit(d, y, xs, family="binomial"):
    cols = set([y, "strata", "psu", "wt_comb"])
    for x in xs:
        cols.add(x[4:-1].split(",")[0].strip() if isinstance(x, str) and x.startswith("Cat(") else x)
    cols = [c for c in cols if c in d.columns]
    m = svy.Sample(to_pl(d, cols), svy.Design(stratum="strata", psu="psu",
                   wgt="wt_comb", singleton="center")).glm.fit(y=y, x=feats(xs), family=family)
    return m, m.to_polars().to_pandas()
def show(t, label, exp=True):
    log(f"\n--- {label}")
    for _, r in t.iterrows():
        if exp:
            log(f"    {r['term']:22s} OR={np.exp(r['estimate']):.3f} "
                f"({np.exp(r['conf_low']):.3f}-{np.exp(r['conf_high']):.3f}) p={r['p_value']:.4g}")
        else:
            log(f"    {r['term']:22s} b={r['estimate']:+.4f} ({r['conf_low']:+.4f},{r['conf_high']:+.4f}) "
                f"p={r['p_value']:.4g}")
def wq(x, w, qs):
    x = np.asarray(x, float); w = np.asarray(w, float)
    m = ~np.isnan(x) & ~np.isnan(w); x, w = x[m], w[m]
    o = np.argsort(x); x, w = x[o], w[o]
    return np.interp(qs, np.cumsum(w) / w.sum(), x)
def rcs(x, knots):
    k = np.asarray(knots, float); x = np.asarray(x, float); n = len(k)
    b = [x]
    for j in range(n - 2):
        t1 = np.maximum(x - k[j], 0) ** 3
        t2 = np.maximum(x - k[n - 2], 0) ** 3 * (k[n - 1] - k[j]) / (k[n - 1] - k[n - 2])
        t3 = np.maximum(x - k[n - 1], 0) ** 3 * (k[n - 2] - k[j]) / (k[n - 1] - k[n - 2])
        b.append(t1 - t2 + t3)
    return np.column_stack(b)

# ================= (a) uric acid -> fracture =================
log("=" * 70); log("(a) URIC ACID AND SELF-REPORTED FRACTURE"); log("=" * 70)
fx = df.dropna(subset=["osq_fracture"]).copy()
log(f"n={len(fx)}  cycles={sorted(fx['cycle'].unique())}")
prev = np.average(fx["osq_fracture"], weights=fx["wt_comb"]) * 100
log(f"weighted fracture prevalence = {prev:.2f}%")
R["fracture_n"] = len(fx); R["fracture_prevalence"] = float(prev)
for nm, cov in [("M1_crude", []), ("M2_age_sex_race", M2), ("M3_full", FULL)]:
    m, t = fit(fx, "osq_fracture", ["Cat(ua_q,ref=1)"] + cov)
    show(t, f"Fracture ~ UA quartile ({nm})")
    R[f"fx_q_{nm}"] = t.to_dict("records")
m, t = fit(fx, "osq_fracture", ["ua"] + FULL); show(t, "Fracture ~ UA per 1 mg/dL (full)")
R["fx_cont"] = t.to_dict("records")
m, t = fit(fx, "osq_fracture", ["hyperuricemia"] + FULL); show(t, "Fracture ~ hyperuricaemia (full)")
R["fx_hyper"] = t.to_dict("records")
# spline
d = fx.dropna(subset=["ua"] + FULL).copy()
kn = wq(d["ua"], d["wt_comb"], [0.05, 0.35, 0.65, 0.95])
B = rcs(d["ua"].to_numpy(), kn)
for j in range(1, B.shape[1]):
    d[f"rcs{j}"] = B[:, j]
rt = [f"rcs{j}" for j in range(1, B.shape[1])]
m, t = fit(d, "osq_fracture", ["ua"] + rt + FULL)
R["fx_rcs"] = {"knots": list(np.round(kn, 3)), "coefs": t.to_dict("records"),
               "nonlin_p": [float(t[t.term == x]["p_value"].iloc[0]) for x in rt]}
log(f"  fracture spline non-linearity p = {R['fx_rcs']['nonlin_p']}")

# ================= (b) WHO T-score categories =================
log("\n" + "=" * 70); log("(b) WHO T-SCORE CATEGORIES (femoral neck, NHANES 20-29 reference)")
log("=" * 70)
b = df.dropna(subset=["fn_bmd"]).copy()
ref = b[b["age"].between(20, 29)].groupby("sex")["fn_bmd"].agg(["mean", "std"])
log("reference (age 20-29):\n" + ref.round(4).to_string())
b["tscore"] = b.apply(lambda r: (r["fn_bmd"] - ref.loc[r["sex"], "mean"]) / ref.loc[r["sex"], "std"]
                      if r["sex"] in ref.index else np.nan, axis=1)
b["who"] = pd.cut(b["tscore"], [-np.inf, -2.5, -1.0, np.inf], labels=["osteoporosis", "osteopenia", "normal"])
R["who_reference"] = ref.round(4).to_dict()
for lab in ["osteopenia", "osteoporosis"]:
    b[f"who_{lab}"] = (b["who"] == lab).astype(float)
    p = np.average(b[f"who_{lab}"], weights=b["wt_comb"]) * 100
    log(f"  weighted prevalence of {lab}: {p:.2f}%")
    R[f"who_prev_{lab}"] = float(p)
for lab in ["osteopenia", "osteoporosis"]:
    for nm, cov in [("M2_age_sex_race", M2), ("M3_full", FULL)]:
        try:
            m, t = fit(b, f"who_{lab}", ["Cat(ua_q,ref=1)"] + cov)
            show(t, f"{lab} ~ UA quartile ({nm})")
            R[f"who_{lab}_{nm}"] = t.to_dict("records")
        except Exception as e:
            log(f"  {lab} {nm} failed: {str(e)[:60]}")
    m, t = fit(b, f"who_{lab}", ["ua"] + FULL)
    log(f"  {lab} ~ UA per 1 mg/dL (full): OR={np.exp(t[t.term=='ua']['estimate'].iloc[0]):.3f} "
        f"p={t[t.term=='ua']['p_value'].iloc[0]:.4g}")
    R[f"who_{lab}_cont"] = t.to_dict("records")

# ================= (c) three-node pathway: UA -> BMD -> fracture =================
log("\n" + "=" * 70); log("(c) PATHWAY: URIC ACID -> FEMORAL-NECK BMD -> FRACTURE")
log("=" * 70)
ov = df.dropna(subset=["fn_bmd", "osq_fracture", "ua"]).copy()
log(f"overlapping cycles with both BMD and fracture: n={len(ov)}  {sorted(ov['cycle'].unique())}")
cov = [c for c in FULL if c != "bmi"] + ["bmi"]
try:
    m, t = fit(ov, "fn_bmd", ["ua"] + cov, family="gaussian")
    a = float(t[t.term == "ua"]["estimate"].iloc[0]); ase = float(t[t.term == "ua"]["std_err"].iloc[0])
    log(f"  a path  UA -> BMD      b={a:+.5f} (se {ase:.5f}) p={t[t.term=='ua']['p_value'].iloc[0]:.3g}")
    m, t = fit(ov, "osq_fracture", ["ua", "fn_bmd"] + cov)
    bcoef = float(t[t.term == "fn_bmd"]["estimate"].iloc[0]); bse = float(t[t.term == "fn_bmd"]["std_err"].iloc[0])
    cp = float(t[t.term == "ua"]["estimate"].iloc[0])
    log(f"  b path  BMD -> fracture b={bcoef:+.4f} (se {bse:.4f}) p={t[t.term=='fn_bmd']['p_value'].iloc[0]:.3g}"
        f"  OR={np.exp(bcoef):.3f}")
    m, t = fit(ov, "osq_fracture", ["ua"] + cov)
    ct = float(t[t.term == "ua"]["estimate"].iloc[0])
    log(f"  c  total UA -> fracture  b={ct:+.5f} p={t[t.term=='ua']['p_value'].iloc[0]:.3g}")
    ind = a * bcoef
    prop = ind / ct if ct != 0 else np.nan
    log(f"  indirect a*b = {ind:+.6f}   proportion mediated = {prop*100:.1f}%")
    R["pathway_bmd_fracture"] = {"n": len(ov), "a": a, "a_se": ase, "b": bcoef, "b_se": bse,
                                 "c_total": ct, "c_direct": cp, "indirect": ind,
                                 "prop_mediated": float(prop)}
except Exception as e:
    log("  pathway failed:", str(e)[:120])

json.dump(R, open(os.path.join(RES, "fracture_results.json"), "w"), indent=1, default=str)
open(os.path.join(RES, "fracture_log.txt"), "w").write("\n".join(LOG))
print("\nfracture / T-score / pathway done")
