"""Pathway enrichment of the osteoarthritis cartilage transcriptome.

Over-representation analysis (Enrichr) of the up- and down-regulated gene sets
against MSigDB Hallmark, GO and KEGG libraries.

Input:  results/geo_de_full.csv
Output: results/geo_enrichment.csv, results/geo_enrichment_meta.json
"""
import requests, pandas as pd, numpy as np, os, json, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
S = requests.Session(); S.headers.update({"User-Agent": "Mozilla/5.0 research-tool"})
ENR = "https://maayanlab.cloud/Enrichr"
LIBS = ["KEGG_2021_Human", "GO_Biological_Process_2023", "Reactome_2022",
        "MSigDB_Hallmark_2020", "GO_Molecular_Function_2023"]

de = pd.read_csv(os.path.join(RES, "geo_de_full.csv"))
de = de.dropna(subset=["log2FC", "fdr"])
up = de[(de["fdr"] < 0.05) & (de["log2FC"] > 0.5)]["gene"].tolist()
dn = de[(de["fdr"] < 0.05) & (de["log2FC"] < -0.5)]["gene"].tolist()
print(f"up-regulated genes: {len(up)} | down-regulated: {len(dn)}")


def add_list(genes, desc):
    last = None
    for attempt in range(8):
        try:
            r = S.post(f"{ENR}/addList",
                       files={"list": (None, "\n".join(genes)), "description": (None, desc)},
                       timeout=90)
            if r.status_code == 200:
                return r.json()["userListId"]
            last = "HTTP " + str(r.status_code)
        except Exception as e:
            last = type(e).__name__
        time.sleep(min(8 * (attempt + 1), 60))
    raise RuntimeError("addList failed: " + str(last))


def enrich(uid, lib):
    for attempt in range(6):
        try:
            r = S.get(f"{ENR}/enrich", params={"userListId": uid, "backgroundType": lib},
                      timeout=120)
            if r.status_code == 200:
                return r.json().get(lib, [])
        except Exception:
            pass
        time.sleep(min(6 * (attempt + 1), 45))
    return []


rows = []
for genes, tag in [(up, "up"), (dn, "down")]:
    if len(genes) < 5:
        continue
    uid = add_list(genes, f"OA_cartilage_{tag}")
    for lib in LIBS:
        res = enrich(uid, lib)
        for rec in res:
            # [rank, term, p, z, combined, genes, adj_p, old_p, old_adj_p]
            try:
                rows.append({"direction": tag, "library": lib, "term": rec[1],
                             "p": float(rec[2]), "combined_score": float(rec[4]),
                             "adj_p": float(rec[6]), "n_genes": len(rec[5]),
                             "genes": ";".join(rec[5][:12])})
            except Exception:
                continue
        time.sleep(0.4)
    print(f"  {tag}: {sum(1 for r in rows if r['direction']==tag)} enriched terms")

en = pd.DataFrame(rows)
if len(en):
    en = en.sort_values(["direction", "adj_p"])
    en.to_csv(os.path.join(RES, "geo_enrichment.csv"), index=False)
    for tag in ["up", "down"]:
        sub = en[(en["direction"] == tag) & (en["adj_p"] < 0.05)].head(12)
        print(f"\n=== top enriched terms ({tag}-regulated, FDR<0.05) ===")
        for _, r in sub.iterrows():
            print(f"  [{r['library'][:22]:22s}] {r['term'][:58]:60s} FDR={r['adj_p']:.2g} "
                  f"n={r['n_genes']}")
json.dump({"n_up": len(up), "n_down": len(dn)},
          open(os.path.join(RES, "geo_enrichment_meta.json"), "w"), indent=1)
print("\nEnrichment done")
