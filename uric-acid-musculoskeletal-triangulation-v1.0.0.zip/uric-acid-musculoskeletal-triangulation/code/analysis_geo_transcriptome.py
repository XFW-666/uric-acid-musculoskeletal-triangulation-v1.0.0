"""Cartilage transcriptome: osteoarthritis versus normal (GEO GSE114007).

Downloads the processed counts, compares osteoarthritis with normal cartilage
by Welch's t-test with Benjamini-Hochberg control, and summarises a
pre-specified gene panel and composite signature scores.

Input:  GEO GSE114007 processed counts (downloaded on first run)
Output: results/geo_de_full.csv, results/geo_panel.csv,
        results/geo_signatures.csv
"""
import requests, gzip, io, os, numpy as np, pandas as pd
from scipy import stats
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEO = os.path.join(ROOT, "data", "geo"); RES = os.path.join(ROOT, "results")
os.makedirs(GEO, exist_ok=True); os.makedirs(RES, exist_ok=True)
S = requests.Session()
S.headers.update({"User-Agent": "Mozilla/5.0 (compatible; research-tool)"})
BASE = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE114nnn/GSE114007/suppl/"


def fetch(fn):
    p = os.path.join(GEO, fn)
    if not os.path.exists(p):
        r = S.get(BASE + fn, timeout=600)
        r.raise_for_status()
        open(p, "wb").write(r.content)
        print("downloaded", fn, len(r.content) / 1e6, "MB")
    return p


oa = pd.read_csv(fetch("GSE114007_OA_normalized.counts.txt.gz"), sep="\t", index_col=0)
nm = pd.read_csv(fetch("GSE114007_normal_normalized.counts.txt.gz"), sep="\t", index_col=0)
print("OA matrix:", oa.shape, " Normal matrix:", nm.shape)

# gene symbol may be a column or the index
def to_symbol_index(d):
    if "Symbol" in d.columns:
        d = d.set_index("Symbol")
    return d

oa = to_symbol_index(oa); nm = to_symbol_index(nm)
common = oa.index.intersection(nm.index)
print("common genes:", len(common))
oa = oa.loc[common]; nm = nm.loc[common]

# drop duplicate symbols by variance
def dedup(d):
    d = d[~d.index.duplicated(keep="first")]
    return d
oa = dedup(oa); nm = dedup(nm)
common = oa.index.intersection(nm.index)
oa = oa.loc[common].astype(float); nm = nm.loc[common].astype(float)

# DE: Welch t-test on log2(CPM+1)
lo = np.log2(oa + 1); ln = np.log2(nm + 1)
res = []
for g in common:
    a = lo.loc[g].to_numpy(); b = ln.loc[g].to_numpy()
    if a.std() == 0 and b.std() == 0:
        continue
    t, p = stats.ttest_ind(a, b, equal_var=False)
    res.append({"gene": g, "log2FC": a.mean() - b.mean(), "p": p,
                "mean_OA": a.mean(), "mean_normal": b.mean()})
de = pd.DataFrame(res)
de["fdr"] = stats.false_discovery_control(de["p"].fillna(1)) if hasattr(stats, "false_discovery_control") \
    else np.nan
de = de.dropna(subset=["log2FC"]).sort_values("log2FC", ascending=False)
de.to_csv(os.path.join(RES, "geo_de_full.csv"), index=False)
print(f"\nDEGs computed: {len(de)} genes; FDR<0.05 & |log2FC|>1: "
      f"{((de['fdr'] < 0.05) & (de['log2FC'].abs() > 1)).sum()}")

PANEL = {
    "Urate pathway": ["SLC22A12", "SLC2A9", "ABCG2", "XDH", "SLC17A1", "SLC16A9", "PDZK1", "GCKR"],
    "Inflammasome / IL-1": ["NLRP3", "IL1B", "CASP1", "PYCARD", "IL18", "TLR4", "MYD88", "NFKB1"],
    "Cartilage matrix": ["MMP13", "ADAMTS5", "COL2A1", "ACAN", "COL1A1", "COL10A1", "MMP3", "SOX9"],
    "Bone remodelling": ["TNFSF11", "TNFRSF11B", "SPP1", "RUNX2", "BGLAP", "ALPL", "CTSK", "ACP5"],
    "Oxidative stress": ["SOD1", "SOD2", "CAT", "GPX1", "NQO1", "HMOX1", "NFE2L2", "NOX4"],
}
rows = []
for cat, genes in PANEL.items():
    for g in genes:
        if g in de["gene"].values:
            r = de[de["gene"] == g].iloc[0]
            rows.append({"category": cat, "gene": g, "log2FC": r["log2FC"],
                         "p": r["p"], "fdr": r["fdr"]})
panel = pd.DataFrame(rows)
panel.to_csv(os.path.join(RES, "geo_panel.csv"), index=False)
print("\n=== curated gene panel: OA vs normal cartilage ===")
for cat in PANEL:
    sub = panel[panel["category"] == cat]
    print(f"\n{cat}:")
    for _, r in sub.iterrows():
        star = "***" if r["fdr"] < 0.001 else ("**" if r["fdr"] < 0.01 else ("*" if r["fdr"] < 0.05 else ""))
        print(f"   {r['gene']:10s} log2FC={r['log2FC']:+.2f}  FDR={r['fdr']:.2g} {star}")

# signature scores
def score(d, genes):
    gs = [g for g in genes if g in d.index]
    return d.loc[gs].mean(axis=0)
sig = pd.DataFrame({
    "Urate pathway": score(lo, PANEL["Urate pathway"]),
    "Inflammasome": score(lo, PANEL["Inflammasome / IL-1"]),
    "Matrix degradation": score(lo, PANEL["Cartilage matrix"]),
})
sig_n = pd.DataFrame({
    "Urate pathway": score(ln, PANEL["Urate pathway"]),
    "Inflammasome": score(ln, PANEL["Inflammasome / IL-1"]),
    "Matrix degradation": score(ln, PANEL["Cartilage matrix"]),
})
summary = []
for c in sig.columns:
    a, b = sig[c].dropna(), sig_n[c].dropna()
    t, p = stats.ttest_ind(a, b, equal_var=False)
    summary.append({"signature": c, "OA": a.mean(), "Normal": b.mean(),
                    "diff": a.mean() - b.mean(), "p": p})
summ = pd.DataFrame(summary)
summ.to_csv(os.path.join(RES, "geo_signatures.csv"), index=False)
print("\n=== signature scores (mean log2 expression) ===")
print(summ.round(3).to_string(index=False))
print("\nGEO done.")
