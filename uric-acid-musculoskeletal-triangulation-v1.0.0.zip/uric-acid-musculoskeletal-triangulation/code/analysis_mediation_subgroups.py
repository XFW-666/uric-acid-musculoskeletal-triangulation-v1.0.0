"""Subgroup analyses, interaction tests and causal mediation.

Design-based Wald interaction tests across pre-specified strata, and the
mediation decomposition of the uric acid-arthritis association through BMI,
waist circumference, hs-CRP, SII, NLR, albumin and eGFR (cluster bootstrap
over primary sampling units within strata).

Input:  data/analytic_clean.csv
Output: results/main3_results.json, results/subgroups.csv,
        results/mediation.csv, results/main3_log.txt
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings
import statsmodels.api as sm
warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
os.makedirs(RES, exist_ok=True)
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes",
        "hypertension", "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")
df["egfr_ge60"] = (df["egfr"] >= 60).astype(float)
FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]
BASE = ["age", "sex", "race5", "edu3", "pir", "smoke", "alcohol", "energy", "diet_ca"]
R = {}; LOG = []
def log(*a):
    s = " ".join(str(x) for x in a); print(s); LOG.append(s)

def to_pl(d, cols):
    x = pl.from_pandas(d[cols].copy())
    for c in cols:
        if c in CATS:
            x = x.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    return x
def samp(d, cols):
    return svy.Sample(to_pl(d, cols), svy.Design(stratum="strata", psu="psu",
                      wgt="wt_comb", singleton="center"))
def feats(xs):
    out = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(","); nm = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            out.append(svy.Cat(nm, ref=ref) if ref else svy.Cat(nm))
        else:
            out.append(x)
    return out
def fit(d, y, xs, family="binomial"):
    cols = set([y, "strata", "psu", "wt_comb"])
    for x in xs:
        cols.add(x[4:-1].split(",")[0].strip() if isinstance(x, str) and x.startswith("Cat(") else x)
    cols = [c for c in cols if c in d.columns]
    m = samp(d, cols).glm.fit(y=y, x=feats(xs), family=family)
    return m, m.to_polars().to_pandas()

# ============ E. Subgroups (design-based) ============
log("=" * 70); log("E. SUBGROUP ANALYSES (UA per 1 mg/dL, design-based, fully adjusted)"); log("=" * 70)
subs = [("Overall", None, None, None), ("Male", "sex", 1, "sex"), ("Female", "sex", 2, "sex"),
        ("Age 20-39", "age_grp", 1, "age"), ("Age 40-59", "age_grp", 2, "age"),
        ("Age 60+", "age_grp", 3, "age"),
        ("BMI <25", "bmi_cat", 1, "bmi"), ("BMI 25-29.9", "bmi_cat", 2, "bmi"),
        ("BMI 30-34.9", "bmi_cat", 3, "bmi"), ("BMI >=35", "bmi_cat", 4, "bmi"),
        ("No diabetes", "diabetes", 0, "diabetes"), ("Diabetes", "diabetes", 1, "diabetes"),
        ("No hypertension", "hypertension", 0, "hypertension"),
        ("Hypertension", "hypertension", 1, "hypertension"),
        ("eGFR >=60", "egfr_ge60", 1, None), ("eGFR <60", "egfr_ge60", 0, None),
        ("Never smoker", "smoke", 0, "smoke"), ("Former smoker", "smoke", 1, "smoke"),
        ("Current smoker", "smoke", 2, "smoke")]
subres = []
for lbl, var, val, drop in subs:
    d = df if var is None else df[df[var] == val]
    cov = [c for c in FULL if c != drop]
    try:
        m, t = fit(d, "arthritis_bin", ["ua"] + cov)
        row = t[t["term"] == "ua"].iloc[0]
        subres.append({"subgroup": lbl, "n": len(d), "or": float(np.exp(row["estimate"])),
                       "lo": float(np.exp(row["conf_low"])), "hi": float(np.exp(row["conf_high"])),
                       "p": float(row["p_value"])})
        log(f"  {lbl:20s} n={len(d):6d} OR={np.exp(row['estimate']):.3f} "
            f"({np.exp(row['conf_low']):.3f}-{np.exp(row['conf_high']):.3f}) p={row['p_value']:.4g}")
    except Exception as e:
        log(f"  {lbl:20s} FAILED {type(e).__name__} {str(e)[:70]}")
R["subgroups"] = subres
pd.DataFrame(subres).to_csv(os.path.join(RES, "subgroups.csv"), index=False)

# interaction p-values (design-based Wald on product term)
log("\n-- interaction tests --")
inter = []
for lbl, var in [("sex", "sex"), ("age group", "age_grp"), ("BMI category", "bmi_cat"),
                 ("diabetes", "diabetes"), ("hypertension", "hypertension"),
                 ("smoking", "smoke")]:
    d = df.dropna(subset=["ua", var, "arthritis_bin"]).copy()
    d["ua_x"] = d["ua"] * d[var]
    try:
        m, t = fit(d, "arthritis_bin", ["ua", f"Cat({var})", "ua_x"] + [c for c in BASE if c != var])
        p = float(t[t["term"] == "ua_x"]["p_value"].iloc[0])
        inter.append({"variable": lbl, "p_interaction": p})
        log(f"  {lbl:16s} p_interaction={p:.4g}")
    except Exception as e:
        log(f"  {lbl:16s} FAILED {str(e)[:60]}")
R["interactions"] = inter

# ============ I. Mediation (consistent total effect) ============
log("\n" + "=" * 70); log("I. MEDIATION: UA -> mediator -> arthritis (total effect adj. BASE)"); log("=" * 70)
d = df.dropna(subset=["arthritis_bin", "ua"] + BASE).copy()
log(f"mediation base n={len(d)}")

def wglm(dd, y, xs, family=sm.families.Binomial()):
    dd = dd[[y] + xs + ["wt_comb"]].dropna()
    X = sm.add_constant(dd[xs].astype(float), has_constant="add")
    m = sm.GLM(dd[y].astype(float), X, family=family, freq_weights=dd["wt_comb"]).fit()
    return m

def paths(dd, med):
    c = wglm(dd, "arthritis_bin", ["ua"] + BASE).params["ua"]
    a = wglm(dd, med, ["ua"] + BASE, sm.families.Gaussian()).params["ua"]
    mb = wglm(dd, "arthritis_bin", ["ua", med] + BASE)
    b = mb.params[med]; cp = mb.params["ua"]
    ind = a * b
    return a, b, c, cp, ind, (ind / c if c != 0 else np.nan)

def cluster_boot(dd, med, nboot=300, seed=7):
    rng = np.random.RandomState(seed)
    st = dd["strata"].to_numpy(); ps = dd["psu"].to_numpy()
    idx = {}
    for i, (h, p) in enumerate(zip(st, ps)):
        idx.setdefault((h, p), []).append(i)
    gps = {}
    for h in np.unique(st):
        gps[h] = np.unique(ps[st == h])
    out = []
    for _ in range(nboot):
        picks = []
        for h, plist in gps.items():
            for p in rng.choice(plist, size=len(plist), replace=True):
                picks.extend(idx[(h, p)])
        try:
            out.append(paths(dd.iloc[picks], med))
        except Exception:
            continue
    return np.array(out)

meds = [("BMI", "bmi"), ("Waist circumference", "waist"), ("hs-CRP", "crp"),
        ("SII", "sii"), ("NLR", "nlr"), ("eGFR", "egfr"), ("Albumin", "albumin")]
med_res = []
for lbl, med in meds:
    dd = d.dropna(subset=[med]).copy()
    try:
        a, b, c, cp, ind, prop = paths(dd, med)
        bt = cluster_boot(dd, med, nboot=200)
        ici = np.nanpercentile(bt[:, 4], [2.5, 97.5])
        pci = np.nanpercentile(bt[:, 5], [2.5, 97.5])
        row = {"mediator": lbl, "n": len(dd), "a": a, "b": b, "total_c": c, "direct_cp": cp,
               "indirect": ind, "indirect_lo": ici[0], "indirect_hi": ici[1],
               "prop_mediated": prop, "prop_lo": pci[0], "prop_hi": pci[1]}
        med_res.append(row)
        log(f"  {lbl:22s} n={len(dd):6d} a={a:+.4f} b={b:+.4f} c={c:+.4f} c'={cp:+.4f} "
            f"ind={ind:+.5f}({ici[0]:+.5f},{ici[1]:+.5f}) prop={prop*100:.1f}%({pci[0]*100:.1f},{pci[1]*100:.1f})")
    except Exception as e:
        log(f"  {lbl:22s} FAILED {type(e).__name__} {str(e)[:70]}")
R["mediation"] = med_res
pd.DataFrame(med_res).to_csv(os.path.join(RES, "mediation.csv"), index=False)

json.dump(R, open(os.path.join(RES, "main3_results.json"), "w"), indent=1, default=str)
open(os.path.join(RES, "main3_log.txt"), "w").write("\n".join(LOG))
print("\nDone.")
