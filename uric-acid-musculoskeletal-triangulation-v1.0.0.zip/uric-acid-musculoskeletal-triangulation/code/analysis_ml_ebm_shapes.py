"""Extract the per-feature shape functions of the Explainable Boosting Machine.

Writes the bin edges and centred log-odds scores for each model term so the
intrinsic shape functions can be plotted.

Input:  data/analytic_clean.csv
Output: results/ebm_shape_<feature>.csv
"""
import pandas as pd, numpy as np, os, json, warnings
from sklearn.impute import SimpleImputer
from interpret.glassbox import ExplainableBoostingClassifier
warnings.filterwarnings("ignore")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
FEATS = ["ua", "age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
         "diabetes", "hypertension", "egfr", "albumin", "alp", "calcium", "phosphorus",
         "crp", "nlr", "sii", "energy", "diet_ca", "sleep", "mvpa_min"]
d = df[FEATS + ["arthritis_bin"]].dropna(subset=["arthritis_bin"])
X = d[FEATS].astype(float); y = d["arthritis_bin"].astype(int)
imp = SimpleImputer(strategy="median")
Ximp = pd.DataFrame(imp.fit_transform(X), columns=FEATS)
ebm = ExplainableBoostingClassifier(random_state=42, max_rounds=300, interactions=10)
ebm.fit(Ximp, y)
g = ebm.explain_global()
saved = []
for i, feat in enumerate(ebm.term_names_):
    if feat not in FEATS:
        continue
    dd = g.data(i)
    nm = np.asarray(dd["names"], dtype=float)
    sc = np.asarray(dd["scores"], dtype=float)
    if len(nm) == len(sc) + 1:
        nm = (nm[:-1] + nm[1:]) / 2.0
    elif len(nm) != len(sc):
        n = min(len(nm), len(sc)); nm, sc = nm[:n], sc[:n]
    pd.DataFrame({"x": nm, "score": sc}).to_csv(os.path.join(RES, f"ebm_shape_{feat}.csv"), index=False)
    saved.append(feat)
print("saved EBM shapes for", len(saved), "features:", saved)
print("UA shape head:")
print(pd.read_csv(os.path.join(RES, "ebm_shape_ua.csv")).head(8).round(4).to_string(index=False))
