"""Prediction models for arthritis and their interpretation.

Trains logistic regression, LightGBM, XGBoost, CatBoost and an Explainable
Boosting Machine under stratified five-fold cross-validation on 24 features, and
computes permutation importance with confidence intervals, accumulated local
effects, individual conditional expectation curves and EBM shape functions.

Input:  data/analytic_clean.csv
Output: results/ml_results.json, results/oof_preds.csv, results/roc_*.csv,
        results/calibration.csv, results/dca.csv, results/perm_importance.csv,
        results/ale_*.csv, results/ebm_importance.csv, results/ice_ua*.csv,
        results/pr.csv, results/ml_log.txt
"""
import pandas as pd, numpy as np, os, json, warnings
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (roc_auc_score, average_precision_score, accuracy_score,
                             confusion_matrix, brier_score_loss, roc_curve, precision_recall_curve)
from sklearn.inspection import permutation_importance
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
from interpret.glassbox import ExplainableBoostingClassifier
warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
os.makedirs(RES, exist_ok=True)
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)

FEATS = ["ua", "age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
         "diabetes", "hypertension", "egfr", "albumin", "alp", "calcium", "phosphorus",
         "crp", "nlr", "sii", "energy", "diet_ca", "sleep", "mvpa_min"]
LABELS = {"ua": "Serum uric acid", "age": "Age", "sex": "Sex", "race5": "Race/ethnicity",
          "edu3": "Education", "pir": "Poverty income ratio", "bmi": "BMI",
          "waist": "Waist circumference", "smoke": "Smoking status", "alcohol": "Alcohol use",
          "diabetes": "Diabetes", "hypertension": "Hypertension", "egfr": "eGFR",
          "albumin": "Albumin", "alp": "Alkaline phosphatase", "calcium": "Calcium",
          "phosphorus": "Phosphorus", "crp": "hs-CRP", "nlr": "NLR", "sii": "SII",
          "energy": "Energy intake", "diet_ca": "Dietary calcium", "sleep": "Sleep duration",
          "mvpa_min": "MVPA"}

d = df[FEATS + ["arthritis_bin"]].dropna(subset=["arthritis_bin"])
X = d[FEATS].astype(float); y = d["arthritis_bin"].astype(int)
print("ML sample:", X.shape, "prevalence:", round(y.mean(), 4))
R = {}; LOG = []
def log(*a):
    s = " ".join(str(x) for x in a); print(s); LOG.append(s)

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

def make_models():
    return {
        "Logistic regression": Pipeline([("imp", SimpleImputer(strategy="median")),
                                         ("sc", StandardScaler()),
                                         ("clf", LogisticRegression(max_iter=2000))]),
        "LightGBM": Pipeline([("imp", SimpleImputer(strategy="median")),
                              ("clf", lgb.LGBMClassifier(n_estimators=500, learning_rate=0.05,
                                    num_leaves=31, subsample=0.8, colsample_bytree=0.8,
                                    random_state=42, verbose=-1))]),
        "XGBoost": Pipeline([("imp", SimpleImputer(strategy="median")),
                             ("clf", xgb.XGBClassifier(n_estimators=500, learning_rate=0.05,
                                   max_depth=5, subsample=0.8, colsample_bytree=0.8,
                                   random_state=42, eval_metric="logloss", verbosity=0))]),
        "CatBoost": Pipeline([("imp", SimpleImputer(strategy="median")),
                              ("clf", CatBoostClassifier(iterations=500, learning_rate=0.05,
                                    depth=6, random_seed=42, verbose=0))]),
        "EBM": Pipeline([("imp", SimpleImputer(strategy="median")),
                         ("clf", ExplainableBoostingClassifier(random_state=42,
                               max_rounds=200, interactions=10))]),
    }

results = {}; oof = {}
for name, mdl in make_models().items():
    aucs, aps, briers, accs, senss, specss, f1s = [], [], [], [], [], [], []
    p_oof = np.zeros(len(y))
    for tr, te in skf.split(X, y):
        mdl.fit(X.iloc[tr], y.iloc[tr])
        p = mdl.predict_proba(X.iloc[te])[:, 1]
        p_oof[te] = p
        aucs.append(roc_auc_score(y.iloc[te], p)); aps.append(average_precision_score(y.iloc[te], p))
        briers.append(brier_score_loss(y.iloc[te], p))
        pred = (p >= 0.5).astype(int)
        accs.append(accuracy_score(y.iloc[te], pred))
        tn, fp, fn, tp = confusion_matrix(y.iloc[te], pred, labels=[0, 1]).ravel()
        senss.append(tp / (tp + fn)); specss.append(tn / (tn + fp))
        f1s.append(2 * tp / (2 * tp + fp + fn))
    oof[name] = p_oof
    results[name] = {"auc": float(np.mean(aucs)), "auc_sd": float(np.std(aucs)),
                     "pr_auc": float(np.mean(aps)), "brier": float(np.mean(briers)),
                     "accuracy": float(np.mean(accs)), "sensitivity": float(np.mean(senss)),
                     "specificity": float(np.mean(specss)), "f1": float(np.mean(f1s))}
    log(f"{name:22s} AUC={np.mean(aucs):.4f}+-{np.std(aucs):.4f} PR-AUC={np.mean(aps):.4f} "
        f"Brier={np.mean(briers):.4f} Acc={np.mean(accs):.4f} Sens={np.mean(senss):.4f} "
        f"Spec={np.mean(specss):.4f} F1={np.mean(f1s):.4f}")

R["model_performance"] = results
pd.DataFrame({"y": y, **{k: v for k, v in oof.items()}}).to_csv(
    os.path.join(RES, "oof_preds.csv"), index=False)

# UA-only benchmark
ua_auc = []
for tr, te in skf.split(X[["ua"]], y):
    m = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler()),
                  ("clf", LogisticRegression(max_iter=1000))])
    m.fit(X[["ua"]].iloc[tr], y.iloc[tr])
    ua_auc.append(roc_auc_score(y.iloc[te], m.predict_proba(X[["ua"]].iloc[te])[:, 1]))
R["ua_only_auc"] = float(np.mean(ua_auc))
log(f"UA-only AUC = {np.mean(ua_auc):.4f}")

# ---------- EBM: inherently interpretable model + shape functions ----------
log("\nFitting EBM for interpretability...")
imp = SimpleImputer(strategy="median")
Ximp = pd.DataFrame(imp.fit_transform(X), columns=FEATS)
ebm = ExplainableBoostingClassifier(random_state=42, max_rounds=300, interactions=10)
ebm.fit(Ximp, y)
log(f"EBM train AUC = {roc_auc_score(y, ebm.predict_proba(Ximp)[:, 1]):.4f}")
R["ebm_train_auc"] = float(roc_auc_score(y, ebm.predict_proba(Ximp)[:, 1]))

ebm_imp = pd.DataFrame({"feature": ebm.term_names_,
                        "importance": ebm.term_importances()})
ebm_imp = ebm_imp[ebm_imp["feature"].isin(FEATS)].copy()
ebm_imp["label"] = ebm_imp["feature"].map(LABELS)
ebm_imp = ebm_imp.sort_values("importance", ascending=False)
ebm_imp.to_csv(os.path.join(RES, "ebm_importance.csv"), index=False)
log("\nEBM term importances (top 12):\n" + ebm_imp.head(12).to_string(index=False))
R["ebm_importance"] = ebm_imp.to_dict("records")
R["ua_ebm_rank"] = int(list(ebm_imp["feature"]).index("ua") + 1)

# per-feature shape functions via EBM's native global explanation
shapes = {}
try:
    g = ebm.explain_global()
    for i, feat in enumerate(ebm.term_names_):
        if feat in FEATS:
            d = g.data(i)
            nm = np.asarray(d["names"], dtype=float) if np.issubdtype(
                np.asarray(d["names"]).dtype, np.number) else None
            if nm is None:
                continue
            shapes[feat] = pd.DataFrame({"x": nm, "score": np.asarray(d["scores"], dtype=float)})
    for feat in ["ua", "age", "bmi", "waist", "crp", "egfr", "albumin", "nlr"]:
        if feat in shapes:
            shapes[feat].to_csv(os.path.join(RES, f"ebm_shape_{feat}.csv"), index=False)
except Exception as e:
    log("EBM shape extraction failed:", type(e).__name__, str(e)[:140])
log("saved EBM shape functions for:", list(shapes.keys()))

# ---------- permutation importance with CI ----------
log("\nComputing permutation importance (LightGBM, 10 repeats)...")
lgbm_full = lgb.LGBMClassifier(n_estimators=500, learning_rate=0.05, num_leaves=31,
                               subsample=0.8, colsample_bytree=0.8, random_state=42, verbose=-1)
lgbm_full.fit(Ximp, y)
pi = permutation_importance(lgbm_full, Ximp, y, scoring="roc_auc", n_repeats=10,
                            random_state=42, n_jobs=-1)
pim = pd.DataFrame({"feature": FEATS, "importance": pi.importances_mean,
                    "sd": pi.importances_std})
pim["lo"] = pim["importance"] - 1.96 * pim["sd"]
pim["hi"] = pim["importance"] + 1.96 * pim["sd"]
pim["label"] = pim["feature"].map(LABELS)
pim = pim.sort_values("importance", ascending=False)
pim.to_csv(os.path.join(RES, "perm_importance.csv"), index=False)
log(pim.head(12).to_string(index=False))
R["perm_importance"] = pim.to_dict("records")
R["ua_perm_rank"] = int(list(pim["feature"]).index("ua") + 1)

# ---------- ALE (accumulated local effects) ----------
def ale_1d(model, Xd, feat, bins=30):
    x = Xd[feat].to_numpy(float)
    qs = np.unique(np.nanpercentile(x, np.linspace(0, 100, bins + 1)))
    if len(qs) < 3:
        return None
    eff, mids, counts = [], [], []
    for i in range(len(qs) - 1):
        lo, hi = qs[i], qs[i + 1]
        m = (x >= lo) & (x <= hi)
        counts.append(int(m.sum()))
        mids.append((lo + hi) / 2)
        if m.sum() < 20:
            eff.append(0.0); continue
        Xl = Xd[m].copy(); Xh = Xd[m].copy()
        Xl[feat] = lo; Xh[feat] = hi
        pl = model.predict_proba(Xl)[:, 1]; ph = model.predict_proba(Xh)[:, 1]
        eff.append(float(np.mean(ph - pl)))
    eff = np.array(eff)
    cum = np.cumsum(eff)
    counts = np.array(counts, float)
    if counts.sum() > 0:
        cum = cum - np.average(cum, weights=counts)
    return pd.DataFrame({"x": mids, "ale": cum})

ale_out = {}
for feat in ["ua", "bmi", "waist", "age", "crp", "egfr", "albumin", "nlr"]:
    a = ale_1d(lgbm_full, Ximp, feat)
    if a is not None:
        a.to_csv(os.path.join(RES, f"ale_{feat}.csv"), index=False)
        ale_out[feat] = a
log("saved ALE curves for:", list(ale_out.keys()))

# ---------- ICE for uric acid ----------
grid = np.percentile(Ximp["ua"], np.linspace(2, 98, 40))
samp = Ximp.sample(min(300, len(Ximp)), random_state=1)
ice = np.zeros((len(samp), len(grid)))
for j, v in enumerate(grid):
    Xs = samp.copy(); Xs["ua"] = v
    ice[:, j] = lgbm_full.predict_proba(Xs)[:, 1]
ice_df = pd.DataFrame(ice, columns=[f"ua_{v:.3f}" for v in grid])
ice_df.to_csv(os.path.join(RES, "ice_ua.csv"), index=False)
pd.DataFrame({"ua": grid}).to_csv(os.path.join(RES, "ice_ua_grid.csv"), index=False)
log("saved ICE for uric acid:", ice.shape)

# calibration + DCA for the best model
best = max(results, key=lambda k: results[k]["auc"])
log(f"\nBest model: {best}")
pb = oof[best]
bins = np.quantile(pb, np.linspace(0, 1, 11)); bins[0], bins[-1] = -np.inf, np.inf
cal = []
for i in range(10):
    m = (pb > bins[i]) & (pb <= bins[i + 1])
    if m.sum() > 0:
        cal.append({"pred": float(pb[m].mean()), "obs": float(y[m].mean()), "n": int(m.sum())})
pd.DataFrame(cal).to_csv(os.path.join(RES, "calibration.csv"), index=False)

def dca(yv, p, th):
    n = len(yv); out = []
    for t in th:
        pred = p >= t
        tp = np.sum(pred & (yv == 1)); fp = np.sum(pred & (yv == 0))
        out.append({"threshold": float(t), "model": float(tp / n - fp / n * (t / (1 - t))),
                    "treat_all": float(yv.mean() - (1 - yv.mean()) * (t / (1 - t))),
                    "treat_none": 0.0})
    return out
pd.DataFrame(dca(y.to_numpy(), pb, np.arange(0.05, 0.61, 0.01))).to_csv(
    os.path.join(RES, "dca.csv"), index=False)

for name, p in oof.items():
    f, t, _ = roc_curve(y, p)
    pd.DataFrame({"fpr": f, "tpr": t}).to_csv(
        os.path.join(RES, f"roc_{name.replace(' ', '_')}.csv"), index=False)
pr, rc, _ = precision_recall_curve(y, oof[best])
pd.DataFrame({"precision": pr, "recall": rc}).to_csv(os.path.join(RES, "pr.csv"), index=False)

R["best_model"] = best; R["n"] = int(len(y))
json.dump(R, open(os.path.join(RES, "ml_results.json"), "w"), indent=1, default=str)
open(os.path.join(RES, "ml_log.txt"), "w").write("\n".join(LOG))
print("\nML + interpretability done.")
