"""Build the serum-uric-acid genetic instrument from the GWAS Catalog.

Downloads the current GWAS Catalog association release, retains the
uric-acid measurement trait (EFO_0004761), restricts to variants with reported
effect sizes and allele frequencies, and clumps to one variant per 1 Mb.

Input:  GWAS Catalog association release (downloaded on first run)
Output: data/gwas/uric_acid_associations.csv, results/mr_instrument.csv
"""
import requests, zipfile, io, os, re, numpy as np, pandas as pd, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.makedirs(os.path.join(ROOT, "data", "gwas"), exist_ok=True)
dest = os.path.join(ROOT, "data", "gwas", "gwas-catalog-associations.zip")
URL = ("https://ftp.ebi.ac.uk/pub/databases/gwas/releases/latest/"
       "gwas-catalog-associations_ontology-annotated-full.zip")
if not os.path.exists(dest):
    r = requests.get(URL, timeout=900)
    r.raise_for_status()
    open(dest, "wb").write(r.content)
    print("downloaded", len(r.content) / 1e6, "MB")
zf = zipfile.ZipFile(dest)
name = [n for n in zf.namelist() if n.endswith(".tsv")][0]
print("reading", name)
df = pd.read_csv(zf.open(name), sep="\t", low_memory=False, dtype=str)
print("shape:", df.shape)
print("cols:", list(df.columns))

# uric acid measurement = EFO_0004761
ua = df[df["MAPPED_TRAIT_URI"].fillna("").str.contains("EFO_0004761", na=False)].copy()
print(f"\nuric-acid association rows: {len(ua)}")
print("traits:", ua["DISEASE/TRAIT"].value_counts().head(6).to_dict())

def parse_beta(s):
    if not isinstance(s, str):
        return np.nan, np.nan
    m = re.search(r"(-?\d+\.?\d*(?:[eE][-+]?\d+)?)", s)
    if not m:
        return np.nan, np.nan
    val = float(m.group(1))
    if "decrease" in s.lower():
        val = -abs(val)
    return val, 1.0

for c in ["P-VALUE", "OR or BETA", "BETA", "RISK ALLELE FREQUENCY",
          "95% CI (TEXT)", "CI_LOWER", "CI_UPPER", "CHR_ID", "CHR_POS"]:
    if c in ua.columns:
        pass
print("\nfirst rows (key cols):")
keyc = [c for c in ["STRONGEST SNP-RISK ALLELE", "SNPS", "CHR_ID", "CHR_POS",
                    "P-VALUE", "OR or BETA", "95% CI (TEXT)", "RISK ALLELE FREQUENCY",
                    "CONTEXT", "DISEASE/TRAIT"] if c in ua.columns]
print(ua[keyc].head(8).to_string(index=False)[:2200])
ua.to_csv(os.path.join(ROOT, "data", "gwas", "uric_acid_associations.csv"), index=False)
print("\nsaved uric_acid_associations.csv")
