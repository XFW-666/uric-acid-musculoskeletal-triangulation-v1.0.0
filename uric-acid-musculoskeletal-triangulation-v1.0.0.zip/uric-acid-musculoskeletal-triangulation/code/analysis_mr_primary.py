"""Two-sample Mendelian randomisation: uric acid and musculoskeletal outcomes.

Retrieves the outcome association statistics for each instrument from the
FinnGen R10 summary statistics over HTTP range requests (BGZF + tabix), then
estimates causal effects by inverse-variance weighting for gout, osteoarthritis,
knee osteoarthritis, hip osteoarthritis and osteoporosis.

Input:  results/mr_instrument.csv, FinnGen R10 summary statistics (remote)
Output: results/mr_results.csv, results/mr_snp_level.csv
"""
import sys, os, re, json, numpy as np, pandas as pd, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tabix_http import TabixHTTP
from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
ua = pd.read_csv(os.path.join(DATA, "gwas", "uric_acid_associations.csv"), low_memory=False)
print("raw uric-acid rows:", len(ua))

# ---- build instrument ----
def parse_beta_ci(beta_s, ci_s):
    """GWAS Catalog beta text is like '10.62' with CI '[8.18-13.06] umol/L decrease'."""
    b = np.nan
    if isinstance(beta_s, str):
        m = re.search(r"(-?\d+\.?\d*(?:[eE][-+]?\d+)?)", beta_s)
        if m:
            b = float(m.group(1))
    lo = hi = np.nan
    direction = ""
    if isinstance(ci_s, str):
        m = re.search(r"\[\s*(-?\d+\.?\d*)\s*-\s*(-?\d+\.?\d*)\s*\]", ci_s)
        if m:
            lo, hi = float(m.group(1)), float(m.group(2))
        low = ci_s.lower()
        if "decrease" in low:
            direction = "decrease"
        elif "increase" in low:
            direction = "increase"
    if not np.isfinite(b) and np.isfinite(lo) and np.isfinite(hi):
        b = (lo + hi) / 2.0
    if direction == "decrease":
        b = -abs(b)
    elif direction == "increase":
        b = abs(b)
    se = (hi - lo) / (2 * 1.96) if (np.isfinite(lo) and np.isfinite(hi) and hi > lo) else np.nan
    return b, se, direction

# keep a homogeneous exposure definition
TRAITS = ["Serum uric acid levels", "Uric acid levels"]
inst = []
for _, r in ua.iterrows():
    if str(r.get("DISEASE/TRAIT")) not in TRAITS:
        continue
    try:
        p = float(r["P-VALUE"])
    except Exception:
        continue
    if not (p < 5e-8):
        continue
    sa = str(r.get("STRONGEST SNP-RISK ALLELE", ""))
    m = re.match(r"(rs\d+)-(.+)$", sa)
    if not m:
        continue
    rsid, ea = m.group(1), m.group(2)
    if ea in ("?", ""):
        continue
    beta, se, direction = parse_beta_ci(r.get("OR or BETA"), r.get("95% CI (TEXT)"))
    if not np.isfinite(beta) or not np.isfinite(se) or se <= 0:
        continue
    try:
        chrm = str(int(float(r["CHR_ID"]))); pos = int(float(r["CHR_POS"]))
    except Exception:
        continue
    try:
        eaf = float(r["RISK ALLELE FREQUENCY"])
    except Exception:
        eaf = np.nan
    inst.append({"rsid": rsid, "chr": chrm, "pos": pos, "ea": ea.upper(), "beta": beta,
                 "se": se, "p": p, "eaf": eaf, "trait": r["DISEASE/TRAIT"]})
iv = pd.DataFrame(inst)
print("genome-wide significant with effect sizes:", len(iv))

# strongest per locus (+-1 Mb), and remove palindromic/ambiguous where needed later
iv["locus"] = iv["chr"].astype(str) + "_" + (iv["pos"] // 1_000_000).astype(str)
iv = iv.sort_values("p").drop_duplicates("locus", keep="first")
# simple distance-based clumping: keep top SNP per 1 Mb window
iv = iv.sort_values("p").reset_index(drop=True)
keep = []
for i, r in iv.iterrows():
    ok = True
    for k in keep:
        if r["chr"] == k["chr"] and abs(r["pos"] - k["pos"]) < 1_000_000:
            ok = False; break
    if ok:
        keep.append(r)
iv = pd.DataFrame(keep).reset_index(drop=True)
print("after clumping:", len(iv))
iv.to_csv(os.path.join(RES, "mr_instrument.csv"), index=False)
print(iv[["rsid", "chr", "pos", "ea", "beta", "se", "p"]].head(20).to_string(index=False))

# ---- fetch outcome effects from FinnGen ----
BASE = "https://storage.googleapis.com/finngen-public-data-r10/summary_stats/"
OUTCOMES = {"gout": "M13_GOUT", "osteoarthritis": "M13_ARTHROSIS",
            "knee_OA": "M13_ARTHROSIS_KNEE", "hip_OA": "M13_ARTHTROSIS_COX",
            "osteoporosis": "M13_OSTEOPOROSIS"}
rows = []
for name, ph in OUTCOMES.items():
    print(f"\n--- {name} ({ph}) ---")
    try:
        tb = TabixHTTP(f"{BASE}finngen_R10_{ph}.gz")
    except Exception as e:
        print("   tabix init failed:", type(e).__name__, str(e)[:80]); continue
    for _, s in iv.iterrows():
        try:
            lines = tb.fetch(s["chr"], s["pos"], s["pos"])
        except Exception:
            continue
        for ln in lines:
            f = ln.split("\t")
            if len(f) < 10:
                continue
            ref, alt = f[2].upper(), f[3].upper()
            try:
                beta_o = float(f[8]); se_o = float(f[9])
            except Exception:
                continue
            # FinnGen beta is for ALT
            if alt == s["ea"]:
                b, direction = beta_o, "alt"
            elif ref == s["ea"]:
                b, direction = -beta_o, "ref"
            else:
                continue  # allele mismatch / not comparable
            rows.append({"outcome": name, "rsid": s["rsid"], "chr": s["chr"], "pos": s["pos"],
                         "ea_exposure": s["ea"], "ref": ref, "alt": alt, "direction": direction,
                         "beta_exp": s["beta"], "se_exp": s["se"],
                         "beta_out": b, "se_out": se_o})
            break
    print(f"   matched {sum(1 for r in rows if r['outcome'] == name)} SNPs")
    time.sleep(0.3)

mr = pd.DataFrame(rows)
mr.to_csv(os.path.join(RES, "mr_snp_level.csv"), index=False)
print("\ntotal harmonised SNP-outcome pairs:", len(mr))

# ---- MR estimates ----
def mr_ivw(bx, by, sx, sy):
    w = 1.0 / (sy ** 2 / bx ** 2 + (by ** 2) * (sx ** 2) / (bx ** 4))
    b = np.sum(w * by / bx) / np.sum(w)
    se = np.sqrt(1.0 / np.sum(w))
    return b, se

def mr_egger(bx, by, sx, sy):
    w = 1.0 / sy ** 2
    X = np.column_stack([np.ones_like(bx), bx])
    W = np.diag(w)
    beta = np.linalg.pinv(X.T @ W @ X) @ (X.T @ W @ by)
    resid = by - X @ beta
    dof = len(bx) - 2
    if dof <= 0:
        return None
    sigma2 = (resid @ W @ resid) / dof
    cov = np.linalg.pinv(X.T @ W @ X) * sigma2
    return beta[0], np.sqrt(cov[0, 0]), beta[1], np.sqrt(cov[1, 1])

def mr_wmedian(bx, by, sx, sy, nboot=2000, seed=1):
    rng = np.random.RandomState(seed)
    ratio = by / bx
    w = 1.0 / (sy ** 2 / bx ** 2)
    order = np.argsort(ratio)
    ratio, w = ratio[order], w[order]
    cw = np.cumsum(w) / w.sum()
    est = np.interp(0.5, cw, ratio)
    boots = []
    for _ in range(nboot):
        idx = rng.choice(len(ratio), len(ratio), replace=True)
        r2, w2 = ratio[idx], w[idx]
        o = np.argsort(r2); r2, w2 = r2[o], w2[o]
        boots.append(np.interp(0.5, np.cumsum(w2) / w2.sum(), r2))
    return est, np.percentile(boots, 2.5), np.percentile(boots, 97.5)

summary = []
for name in OUTCOMES:
    d = mr[mr["outcome"] == name].copy()
    d = d[np.isfinite(d["beta_exp"]) & (d["beta_exp"].abs() > 1e-9)]
    if len(d) < 2:
        print(f"\n{name}: too few SNPs ({len(d)})"); continue
    bx, by = d["beta_exp"].to_numpy(), d["beta_out"].to_numpy()
    sx, sy = d["se_exp"].to_numpy(), d["se_out"].to_numpy()
    b, se = mr_ivw(bx, by, sx, sy)
    # SE with delta method on ratio
    se_delta = np.sqrt(np.sum((by ** 2) * (sx ** 2) / (bx ** 4) + (sy ** 2) / (bx ** 2)) / len(d) ** 2)
    z = b / max(se, 1e-12)
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    # heterogeneity
    ratio = by / bx
    w = 1.0 / (sy ** 2 / bx ** 2)
    q = float(np.sum(w * (ratio - b) ** 2)); qdof = len(d) - 1
    qp = 1 - stats.chi2.cdf(q, qdof) if qdof > 0 else np.nan
    eg = mr_egger(bx, by, sx, sy)
    wm = mr_wmedian(bx, by, sx, sy)
    row = {"outcome": name, "n_snp": len(d), "ivw_beta": b, "ivw_se": se,
           "ivw_or": np.exp(b), "ivw_lo": np.exp(b - 1.96 * se), "ivw_hi": np.exp(b + 1.96 * se),
           "ivw_p": p, "Q": q, "Q_p": qp,
           "wm_beta": wm[0], "wm_lo": np.exp(wm[1]), "wm_hi": np.exp(wm[2]),
           "egger_intercept": eg[0] if eg else np.nan,
           "egger_int_p": (2 * (1 - stats.norm.cdf(abs(eg[0] / eg[1])))) if eg else np.nan}
    summary.append(row)
    print(f"\n{name}: n={len(d)}  IVW OR={row['ivw_or']:.3f} ({row['ivw_lo']:.3f}-{row['ivw_hi']:.3f}) "
          f"p={p:.3g}  Q_p={qp:.3f}  egger_int_p={row['egger_int_p']:.3f}  "
          f"WM OR={np.exp(wm[0]):.3f}")

sm = pd.DataFrame(summary)
sm.to_csv(os.path.join(RES, "mr_results.csv"), index=False)
print("\nMR done.")
