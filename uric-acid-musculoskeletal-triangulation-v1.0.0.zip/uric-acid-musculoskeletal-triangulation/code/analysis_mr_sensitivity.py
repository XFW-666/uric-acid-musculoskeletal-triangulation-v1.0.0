"""Sensitivity analyses for the Mendelian randomisation estimates.

Weighted median and weighted mode estimators, MR-Egger regression with the
directional-pleiotropy intercept, Cochran's Q heterogeneity with outlier
detection, leave-one-out analysis, instrument strength (mean F) and Steiger
directionality.

Input:  results/mr_instrument.csv, results/mr_snp_level.csv
Output: results/mr_sensitivity.csv, results/mr_sensitivity.json,
        results/mr_loo_*.csv, results/mr_sensitivity_log.txt
"""
import pandas as pd, numpy as np, os, json
from scipy import stats
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
mr = pd.read_csv(os.path.join(RES, "mr_snp_level.csv"))
inst = pd.read_csv(os.path.join(RES, "mr_instrument.csv"))
print("SNP-outcome rows:", len(mr), "| instruments:", len(inst))

eaf = inst.set_index("rsid")["eaf"].to_dict()
R = {}; LOG = []
def log(*a):
    s = " ".join(str(x) for x in a); print(s); LOG.append(s)


def ivw(bx, by, sx, sy):
    w = 1.0 / (sy ** 2 / bx ** 2)
    b = np.sum(w * by / bx) / np.sum(w)
    se = np.sqrt(1.0 / np.sum(w))
    return b, se


def wmode(bx, by, sx, sy, bw=0.6, nboot=2000, seed=7):
    rng = np.random.RandomState(seed)
    ratio = by / bx
    w = 1.0 / (sy ** 2 / bx ** 2)
    sd = np.sqrt(np.median(np.abs(ratio - np.median(ratio))) ** 2) or np.std(ratio)
    def est(r, ww):
        o = np.argsort(r); r, ww = r[o], ww[o]
        best, bv = None, -1
        for i in range(len(r)):
            k = np.abs(r - r[i]) < bw * sd
            s = ww[k].sum()
            if s > bv:
                bv, best = s, r[i]
        return best
    b = est(ratio, w)
    boots = []
    for _ in range(nboot):
        idx = rng.choice(len(ratio), len(ratio), replace=True)
        boots.append(est(ratio[idx], w[idx]))
    boots = np.array(boots, dtype=float)
    return b, np.nanpercentile(boots, 2.5), np.nanpercentile(boots, 97.5)


rows = []
for name in mr["outcome"].unique():
    d = mr[mr["outcome"] == name].copy()
    d = d[np.isfinite(d["beta_exp"]) & (d["beta_exp"].abs() > 1e-9)]
    if len(d) < 3:
        continue
    bx, by = d["beta_exp"].to_numpy(), d["beta_out"].to_numpy()
    sx, sy = d["se_exp"].to_numpy(), d["se_out"].to_numpy()
    n = len(d)

    b, se = ivw(bx, by, sx, sy)
    orv = np.exp(b)
    # F statistic (instrument strength)
    r2 = 2 * d["ea_exposure"].map(eaf).fillna(0.3).to_numpy() * (1 - d["ea_exposure"].map(eaf).fillna(0.3).to_numpy())
    F = np.mean((bx ** 2) / (sx ** 2))

    # Cochran's Q and per-SNP contributions
    w = 1.0 / (sy ** 2 / bx ** 2)
    ratio = by / bx
    q_i = w * (ratio - b) ** 2
    Q = float(q_i.sum()); dof = n - 1
    Qp = float(1 - stats.chi2.cdf(Q, dof)) if dof > 0 else np.nan
    thr = stats.chi2.ppf(1 - 0.05 / n, 1)
    outliers = d.loc[q_i > thr, "rsid"].tolist()

    # corrected IVW excluding outliers
    keep = q_i <= thr
    if outliers and keep.sum() >= 3:
        b2, se2 = ivw(bx[keep], by[keep], sx[keep], sy[keep])
        or2 = np.exp(b2); lo2, hi2 = np.exp(b2 - 1.96 * se2), np.exp(b2 + 1.96 * se2)
    else:
        or2 = lo2 = hi2 = np.nan

    # leave-one-out
    loo = []
    for i in range(n):
        m = np.ones(n, dtype=bool); m[i] = False
        if m.sum() < 2:
            continue
        bb, ss = ivw(bx[m], by[m], sx[m], sy[m])
        loo.append({"rsid": d["rsid"].iloc[i], "or": float(np.exp(bb)),
                    "lo": float(np.exp(bb - 1.96 * ss)), "hi": float(np.exp(bb + 1.96 * ss)),
                    "p": float(2 * (1 - stats.norm.cdf(abs(bb / ss))))})
    loo = pd.DataFrame(loo)
    if len(loo):
        loo.to_csv(os.path.join(RES, f"mr_loo_{name}.csv"), index=False)

    # Egger intercept
    X = np.column_stack([np.ones(n), bx]); W = np.diag(1.0 / sy ** 2)
    beta = np.linalg.pinv(X.T @ W @ X) @ (X.T @ W @ by)
    resid = by - X @ beta
    sig2 = (resid @ W @ resid) / (n - 2) if n > 2 else np.nan
    cov = np.linalg.pinv(X.T @ W @ X) * sig2
    int_p = 2 * (1 - stats.norm.cdf(abs(beta[0] / np.sqrt(cov[0, 0])))) if n > 2 else np.nan

    # weighted mode
    wm = wmode(bx, by, sx, sy) if n >= 4 else (np.nan, np.nan, np.nan)

    # Steiger directionality: variance explained in exposure vs outcome
    def _f(r):
        v = eaf.get(r)
        return v if (v is not None and np.isfinite(v) and 0 < v < 1) else 0.3
    fq = np.array([_f(r) for r in d["rsid"]])
    vv = 2 * fq * (1 - fq)
    r2_exp = float(np.nansum(vv * bx ** 2))
    r2_out = float(np.nansum(vv * by ** 2))
    steiger = "correct" if r2_exp > r2_out else "reverse"

    rows.append({"outcome": name, "n_snp": n, "ivw_or": orv,
                 "ivw_lo": np.exp(b - 1.96 * se), "ivw_hi": np.exp(b + 1.96 * se),
                 "ivw_p": float(2 * (1 - stats.norm.cdf(abs(b / se)))),
                 "mean_F": float(F), "Q": Q, "Q_dof": dof, "Q_p": Qp,
                 "n_outlier": len(outliers), "outliers": ";".join(outliers),
                 "ivw_or_no_outlier": or2, "ivw_no_outlier_lo": lo2, "ivw_no_outlier_hi": hi2,
                 "egger_intercept_p": float(int_p) if np.isfinite(int_p) else np.nan,
                 "wmode_or": float(np.exp(wm[0])) if np.isfinite(wm[0]) else np.nan,
                 "wmode_lo": float(np.exp(wm[1])) if np.isfinite(wm[1]) else np.nan,
                 "wmode_hi": float(np.exp(wm[2])) if np.isfinite(wm[2]) else np.nan,
                 "loo_or_min": float(loo["or"].min()) if len(loo) else np.nan,
                 "loo_or_max": float(loo["or"].max()) if len(loo) else np.nan,
                 "loo_all_sig": bool((loo["p"] < 0.05).all()) if len(loo) else None,
                 "steiger": steiger, "r2_exposure": r2_exp, "r2_outcome": r2_out})
    log(f"\n{name}: n={n}")
    log(f"   IVW OR={orv:.3f} ({np.exp(b-1.96*se):.3f}-{np.exp(b+1.96*se):.3f})  mean F={F:.0f}")
    log(f"   Cochran Q={Q:.1f} (df={dof}) p={Qp:.3f} | outliers={len(outliers)} {outliers[:5]}")
    if np.isfinite(or2):
        log(f"   IVW after outlier removal: OR={or2:.3f} ({lo2:.3f}-{hi2:.3f})")
    log(f"   Egger intercept p={int_p:.3f} | weighted-mode OR={np.exp(wm[0]):.3f} "
        f"({np.exp(wm[1]):.3f}-{np.exp(wm[2]):.3f})")
    if len(loo):
        log(f"   leave-one-out OR range: {loo['or'].min():.3f}-{loo['or'].max():.3f} "
            f"(all LOO estimates significant: {(loo['p']<0.05).all()})")
    log(f"   Steiger: {steiger} (R2 exposure {r2_exp:.4f} vs outcome {r2_out:.4f})")

sm = pd.DataFrame(rows)
sm.to_csv(os.path.join(RES, "mr_sensitivity.csv"), index=False)
R["mr_sensitivity"] = sm.to_dict("records")
json.dump(R, open(os.path.join(RES, "mr_sensitivity.json"), "w"), indent=1, default=str)
open(os.path.join(RES, "mr_sensitivity_log.txt"), "w").write("\n".join(LOG))
print("\nMR sensitivity suite done")
