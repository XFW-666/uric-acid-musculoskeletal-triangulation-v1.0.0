"""Independent temporal corroboration: NHIS Sample Adult 2019-2024.

Annual weighted arthritis prevalence from the NHIS Sample Adult component,
extending the observation window to 2024.

Input:  data/nhis/adult*csv.zip (fetch with code/download_nhis.py)
Output: results/nhis_arthritis_trend.csv
"""
import requests, zipfile, io, os, json, numpy as np, pandas as pd
S = requests.Session()
S.headers.update({"User-Agent": "Mozilla/5.0 Chrome/124.0"})
B = "https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS"
os.makedirs(os.path.join(ROOT, "data", "nhis"), exist_ok=True)
RES = os.path.join(ROOT, "results"); os.makedirs(RES, exist_ok=True)

YEARS = ["2019", "2020", "2021", "2022", "2023", "2024"]
rows = []
for y in YEARS:
    yy = y[2:]
    fn = os.path.join(ROOT, "data", "nhis", f"adult{yy}csv.zip")
    if not os.path.exists(fn):
        r = S.get(f"{B}/{y}/adult{yy}csv.zip", timeout=240)
        if r.status_code != 200:
            print(f"{y}: download failed {r.status_code}"); continue
        open(fn, "wb").write(r.content)
    zf = zipfile.ZipFile(fn)
    name = [n for n in zf.namelist() if n.lower().endswith(".csv")][0]
    df = pd.read_csv(io.BytesIO(zf.read(name)), low_memory=False)
    arth = [c for c in df.columns if c.upper().startswith("ARTHEV")]
    wts = [c for c in df.columns if c.upper() in ("WTFA_A", "WTFA")]
    strat = [c for c in df.columns if c.upper() in ("PSTRAT", "STRATUM")]
    psu = [c for c in df.columns if c.upper() in ("PPSU", "PSU")]
    age = [c for c in df.columns if c.upper() in ("AGEP_A", "AGE_P", "AGEP")]
    sex = [c for c in df.columns if c.upper() in ("SEX_A", "SEX")]
    print(f"{y}: n={len(df)} arth={arth} wt={wts} strat={strat} psu={psu} age={age} sex={sex}")
    if not arth or not wts:
        continue
    a, w = arth[0], wts[0]
    d = df[[a, w]].copy()
    if age:
        d["age"] = pd.to_numeric(df[age[0]], errors="coerce")
        d = d[d["age"] >= 18]
    d["arth"] = d[a].map({1.0: 1.0, 2.0: 0.0})
    d = d.dropna(subset=["arth", w])
    d = d[d[w] > 0]
    prev = np.average(d["arth"], weights=d[w]) * 100
    # design-based SE (strata x psu)
    se = np.nan
    if strat and psu:
        d2 = d.assign(_s=df.loc[d.index, strat[0]], _p=df.loc[d.index, psu[0]])
        W = d2[w].to_numpy(float); Y = d2["arth"].to_numpy(float)
        est = (W * Y).sum() / W.sum()
        z = W * (Y - est) / W.sum()
        t = pd.DataFrame({"s": d2["_s"].to_numpy(), "p": d2["_p"].to_numpy(), "z": z})
        ps = t.groupby(["s", "p"], observed=True)["z"].sum()
        var = 0.0
        for h, g in ps.groupby(level=0, observed=True):
            v = g.to_numpy(float); nh = len(v)
            if nh > 1:
                var += (nh / (nh - 1.0)) * ((v - v.mean()) ** 2).sum()
        se = np.sqrt(var) * 100
    rows.append({"year": int(y), "n": int(len(d)), "arthritis": float(prev), "se": float(se)})
    print(f"   -> {y}: arthritis {prev:.2f}% (SE {se:.2f}) n={len(d)}")

out = pd.DataFrame(rows)
out.to_csv(os.path.join(RES, "nhis_arthritis_trend.csv"), index=False)
print("\n=== NHIS arthritis prevalence 2019-2024 ===")
print(out.round(2).to_string(index=False))
