"""Target-disease genetic evidence for urate-pathway genes (Open Targets).

Queries the Open Targets Platform for the association of SLC22A12, SLC2A9,
ABCG2, XDH, SLC17A1, SLC16A9, PDZK1, GCKR, NLRP3 and IL1B with gout,
osteoarthritis and osteoporosis, recording the overall and genetic association
scores and the rank of each target among all associated targets.

Input:  Open Targets Platform GraphQL API (remote)
Output: results/opentargets_panel.csv, results/opentargets_ensembl.json,
        results/opentargets_disease_targets.csv
"""
import requests, json, os, time, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results"); os.makedirs(RES, exist_ok=True)
S = requests.Session()
S.headers.update({"User-Agent": "Mozilla/5.0 (compatible; research-tool)",
                  "Content-Type": "application/json"})
API = "https://api.platform.opentargets.org/api/v4/graphql"


def gql(query, variables=None):
    for _ in range(3):
        try:
            r = S.post(API, json={"query": query, "variables": variables or {}}, timeout=90)
            if r.status_code == 200:
                j = r.json()
                if "errors" in j:
                    print("   GQL errors:", str(j["errors"])[:200])
                return j.get("data")
        except Exception as e:
            print("   ERR", type(e).__name__, str(e)[:70])
        time.sleep(2)
    return None


GENES = {"SLC22A12": "URAT1", "SLC2A9": "GLUT9", "ABCG2": "ABCG2", "XDH": "XDH",
         "SLC17A1": "NPT1", "SLC16A9": "MCT9", "PDZK1": "PDZK1", "GCKR": "GCKR",
         "NLRP3": "NLRP3", "IL1B": "IL1B"}
DISEASES = {"gout": None, "osteoarthritis": None, "osteoporosis": None}

print("=== resolve Ensembl IDs ===")
ens = {}
q = '''query($s:String!){ search(queryString:$s, entityNames:["target"], page:{index:0,size:1})
        { hits { id name entity } } }'''
for sym in GENES:
    d = gql(q, {"s": sym})
    if d and d.get("search", {}).get("hits"):
        h = d["search"]["hits"][0]
        ens[sym] = h["id"]
        print(f"  {sym:10s} -> {h['id']}")
    time.sleep(0.3)
json.dump(ens, open(os.path.join(RES, "opentargets_ensembl.json"), "w"), indent=1)

print("\n=== resolve disease IDs ===")
for dn in list(DISEASES):
    d = gql(q.replace('entityNames:["target"]', 'entityNames:["disease"]'), {"s": dn})
    if d and d.get("search", {}).get("hits"):
        h = d["search"]["hits"][0]
        DISEASES[dn] = h["id"]
        print(f"  {dn:16s} -> {h['id']}  ({h['name']})")
    time.sleep(0.3)
print("  resolved:", DISEASES)

print("\n=== disease -> associated targets (top rows) ===")
qd = '''query($efo:String!){ disease(efoId:$efo){ id name
        associatedTargets(page:{index:0,size:200}){ count
          rows { target { approvedSymbol } score datatypeScores { id score } } } } }'''
rows = []
for dn, efo in DISEASES.items():
    d = gql(qd, {"efo": efo})
    if not d or not d.get("disease"):
        print(f"  {dn}: no data"); continue
    dis = d["disease"]
    print(f"  {dn} ({dis['name']}): {dis['associatedTargets']['count']} associated targets")
    for r in dis["associatedTargets"]["rows"]:
        sym = r["target"]["approvedSymbol"]
        dt = {x["id"]: x["score"] for x in (r.get("datatypeScores") or [])}
        rows.append({"disease": dn, "target": sym, "overall": r["score"],
                     "genetic": dt.get("genetic_association", 0),
                     "somatic": dt.get("somatic_mutation", 0),
                     "expression": dt.get("rna_expression", 0),
                     "literature": dt.get("literature", 0)})
    time.sleep(0.4)

ot = pd.DataFrame(rows)
ot.to_csv(os.path.join(RES, "opentargets_disease_targets.csv"), index=False)

print("\n=== urate-pathway genes: evidence for each disease ===")
panel = ot[ot["target"].isin(GENES.keys())].copy()
if len(panel):
    piv = panel.pivot_table(index="target", columns="disease", values="genetic",
                            aggfunc="max").fillna(0)
    print(piv.round(3).to_string())
    panel.to_csv(os.path.join(RES, "opentargets_panel.csv"), index=False)

# where does the urate panel rank for each disease?
print("\n=== rank of urate-pathway genes among all targets (overall score) ===")
for dn in DISEASES:
    sub = ot[ot["disease"] == dn].sort_values("overall", ascending=False).reset_index(drop=True)
    hits = sub[sub["target"].isin(GENES.keys())]
    for _, h in hits.iterrows():
        rank = int(sub.index[sub["target"] == h["target"]][0]) + 1
        print(f"  {dn:16s} {h['target']:10s} rank {rank:4d}/{len(sub)}  overall={h['overall']:.3f} "
              f"genetic={h['genetic']:.3f}")
print("\nOpen Targets done.")
