"""Two-dimensional partial dependence of the LightGBM arthritis model.

Evaluates the fitted model over a grid of serum uric acid crossed with body mass
index and with waist circumference.

Input:  data/analytic_clean.csv
Output: results/pdp_ua_bmi.npy, results/pdp_ua_bmi_axes.npz,
        results/pdp_ua_waist.npy, results/pdp_ua_waist_axes.npz,
        results/pdp_ua_1d.csv
"""
import pandas as pd, numpy as np, os, json
from sklearn.impute import SimpleImputer
import lightgbm as lgb
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
FEATS = ["ua", "age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
         "diabetes", "hypertension", "egfr", "albumin", "alp", "calcium", "phosphorus",
         "crp", "nlr", "sii", "energy", "diet_ca", "sleep", "mvpa_min"]
d = df[FEATS + ["arthritis_bin"]].dropna(subset=["arthritis_bin"])
X = d[FEATS].astype(float); y = d["arthritis_bin"].astype(int)
imp = SimpleImputer(strategy="median")
Ximp = pd.DataFrame(imp.fit_transform(X), columns=FEATS)
m = lgb.LGBMClassifier(n_estimators=500, learning_rate=0.05, num_leaves=31, subsample=0.8,
                       colsample_bytree=0.8, random_state=42, verbose=-1)
m.fit(Ximp, y)
print("model fitted; train AUC check done")

samp = Ximp.sample(4000, random_state=1).copy()

def pdp2d(f1, f2, g1, g2):
    Z = np.zeros((len(g2), len(g1)))
    for i, v2 in enumerate(g2):
        for j, v1 in enumerate(g1):
            S = samp.copy(); S[f1] = v1; S[f2] = v2
            Z[i, j] = m.predict_proba(S)[:, 1].mean()
    return Z

g_ua = np.linspace(2.5, 9.5, 34)
g_bmi = np.linspace(18, 42, 30)
Z1 = pdp2d("ua", "bmi", g_ua, g_bmi)
np.save(os.path.join(RES, "pdp_ua_bmi.npy"), Z1)
np.savez(os.path.join(RES, "pdp_ua_bmi_axes.npz"), ua=g_ua, y=g_bmi)
print("UA x BMI PDP:", Z1.shape, "range", round(Z1.min(), 3), "-", round(Z1.max(), 3))

g_waist = np.linspace(60, 135, 30)
Z2 = pdp2d("ua", "waist", g_ua, g_waist)
np.save(os.path.join(RES, "pdp_ua_waist.npy"), Z2)
np.savez(os.path.join(RES, "pdp_ua_waist_axes.npz"), ua=g_ua, y=g_waist)
print("UA x waist PDP:", Z2.shape, "range", round(Z2.min(), 3), "-", round(Z2.max(), 3))

# 1D PDP for reference
g1 = np.linspace(2.5, 9.5, 40)
p1 = []
for v in g1:
    S = samp.copy(); S["ua"] = v
    p1.append(m.predict_proba(S)[:, 1].mean())
pd.DataFrame({"ua": g1, "pd": p1}).to_csv(os.path.join(RES, "pdp_ua_1d.csv"), index=False)
print("1D PDP done")
