"""Joint design-based Wald tests of non-linearity for the spline models.

Refits the arthritis, femoral-neck BMD and fracture splines and tests the joint
null of linearity (2 df) using the covariance between the two non-linear basis
terms recovered from contrast variances.

Input:  data/analytic_clean.csv
Output: results/spline_joint_tests.json
"""
import os, json, warnings
import numpy as np
import pandas as pd
import polars as pl
import svy
from scipy.stats import chi2
warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
df = pd.read_csv(os.path.join(ROOT, "data", "analytic_clean.csv"), low_memory=False)
CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes",
        "hypertension", "bmi_cat", "age_grp"]
FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]
for c in CATS:
    if c in df.columns:
        df[c] = df[c].astype("float")


def rcs(x, knots):
    k = np.asarray(knots, float); x = np.asarray(x, float)
    n = len(k); basis = [x]
    for j in range(n - 2):
        t1 = np.maximum(x - k[j], 0) ** 3
        t2 = np.maximum(x - k[n - 2], 0) ** 3 * (k[n - 1] - k[j]) / (k[n - 1] - k[n - 2])
        t3 = np.maximum(x - k[n - 1], 0) ** 3 * (k[n - 2] - k[j]) / (k[n - 1] - k[n - 2])
        basis.append(t1 - t2 + t3)
    return np.column_stack(basis)


def wq(x, w, qs):
    x = np.asarray(x, float); w = np.asarray(w, float)
    m = ~np.isnan(x) & ~np.isnan(w); x, w = x[m], w[m]
    o = np.argsort(x); x, w = x[o], w[o]
    return np.interp(qs, np.cumsum(w) / w.sum(), x)


def to_pl(d, cols):
    x = d[cols].copy()
    for c in cols:
        if c in CATS:
            x[c] = x[c].astype("Int32").astype(str)
    return pl.from_pandas(x)


def samp(d, cols):
    return svy.Sample(to_pl(d, sorted(set(cols))),
                      svy.Design(stratum="strata", psu="psu", wgt="wt_comb",
                                 singleton="center"))


def fit(d, y, xs, family="binomial"):
    cols = {y, "strata", "psu", "wt_comb"} | set(xs)
    cols = [c for c in cols if c in d.columns]
    m = samp(d, cols).glm.fit(y=y, x=xs, family=family)
    t = m.to_polars().to_pandas()
    return m, t


def joint_test(m, t, terms=("rcs1", "rcs2")):
    rows = {r["term"]: r for _, r in t.iterrows()}
    b = np.array([float(rows[x]["estimate"]) for x in terms])
    v = np.array([float(rows[x]["std_err"]) ** 2 for x in terms])
    try:
        con = m.contrast(svy.estd(terms[0]) + svy.estd(terms[1]))
        tab = con.to_polars().to_pandas() if hasattr(con, "to_polars") else con
        se_col = "se" if "se" in tab.columns else "std_err"
        se_sum = float(tab[se_col].iloc[0])
        cov = (se_sum ** 2 - v[0] - v[1]) / 2.0
        V = np.array([[v[0], cov], [cov, v[1]]])
        W = float(b @ np.linalg.inv(V) @ b)
        p = float(chi2.sf(W, len(terms)))
        return {"terms": list(terms), "betas": b.tolist(), "var": v.tolist(),
                "cov": cov, "Wald_chi2": W, "df": len(terms), "p_joint": p,
                "p_individual": [float(rows[x]["p_value"]) for x in terms]}
    except Exception as e:
        return {"error": str(e)[:200], "p_individual": [float(rows[x]["p_value"]) for x in terms]}


R = {}

# 1. arthritis spline
d = df.dropna(subset=["ua", "arthritis_bin"] + FULL).copy()
kn = wq(d["ua"], d["wt_comb"], [0.05, 0.35, 0.65, 0.95])
B = rcs(d["ua"].to_numpy(), kn)
for j in range(1, B.shape[1]):
    d[f"rcs{j}"] = B[:, j]
m, t = fit(d, "arthritis_bin", ["ua"] + [f"rcs{j}" for j in range(1, B.shape[1])] + FULL)
R["arthritis"] = {"knots": list(np.round(kn, 3)), "n": len(d), **joint_test(m, t)}
print("arthritis:", json.dumps(R["arthritis"]))

# 2. BMD spline
bmd = df.dropna(subset=["fn_bmd", "ua"]).copy()
bmd["ua_q"] = pd.cut(bmd["ua"], bins=[-np.inf, 4.4, 5.3, 6.3, np.inf], labels=[1, 2, 3, 4]).astype(float)
bmd = bmd.dropna(subset=["ua_q"])
bd = bmd.dropna(subset=FULL + ["fn_bmd"]).copy()
kn = wq(bd["ua"], bd["wt_comb"], [0.05, 0.35, 0.65, 0.95])
B = rcs(bd["ua"].to_numpy(), kn)
for j in range(1, B.shape[1]):
    bd[f"rcs{j}"] = B[:, j]
m, t = fit(bd, "fn_bmd", ["ua"] + [f"rcs{j}" for j in range(1, B.shape[1])] + FULL, family="gaussian")
R["bmd"] = {"knots": list(np.round(kn, 3)), "n": len(bd), **joint_test(m, t)}
print("bmd:", json.dumps(R["bmd"]))

# 3. fracture spline
fx = df.dropna(subset=["osq_fracture"]).copy()
d = fx.dropna(subset=["ua"] + FULL).copy()
kn = wq(d["ua"], d["wt_comb"], [0.05, 0.35, 0.65, 0.95])
B = rcs(d["ua"].to_numpy(), kn)
for j in range(1, B.shape[1]):
    d[f"rcs{j}"] = B[:, j]
m, t = fit(d, "osq_fracture", ["ua"] + [f"rcs{j}" for j in range(1, B.shape[1])] + FULL)
R["fracture"] = {"knots": list(np.round(kn, 3)), "n": len(d), **joint_test(m, t)}
print("fracture:", json.dumps(R["fracture"]))

with open(os.path.join(ROOT, "results", "spline_joint_tests.json"), "w", encoding="utf-8") as f:
    json.dump(R, f, indent=1)
print("saved results/spline_joint_tests.json")
