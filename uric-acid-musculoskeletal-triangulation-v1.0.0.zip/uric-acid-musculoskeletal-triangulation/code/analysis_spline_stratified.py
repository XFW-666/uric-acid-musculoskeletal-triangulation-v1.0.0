"""Stratified restricted-cubic-spline curves for the dose-response panels.

Fits the uric-acid spline separately by sex and by BMI category for arthritis
and for femoral-neck BMD.

Input:  data/analytic_clean.csv
Output: results/rcs_arthritis_bmi.csv, results/rcs_arthritis_sex.csv,
        results/rcs_bmd_sex.csv
"""
import pandas as pd, numpy as np, polars as pl, svy, os, json, warnings
warnings.filterwarnings("ignore")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
CATS = ["ua_q", "sex", "race5", "edu3", "smoke", "alcohol", "diabetes",
        "hypertension", "bmi_cat", "age_grp"]
for c in CATS:
    df[c] = df[c].astype("float")
FULL = ["age", "sex", "race5", "edu3", "pir", "bmi", "waist", "smoke", "alcohol",
        "diabetes", "hypertension", "egfr", "energy", "diet_ca"]


def to_pl(d, cols):
    x = pl.from_pandas(d[cols].copy())
    for c in cols:
        if c in CATS:
            x = x.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    return x


def feats(xs):
    out = []
    for x in xs:
        if isinstance(x, str) and x.startswith("Cat("):
            inner = x[4:-1].split(","); nm = inner[0].strip()
            ref = inner[1].split("=")[1].strip() if len(inner) > 1 else None
            out.append(svy.Cat(nm, ref=ref) if ref else svy.Cat(nm))
        else:
            out.append(x)
    return out


def rcs(x, knots):
    k = np.asarray(knots, float); x = np.asarray(x, float); n = len(k)
    b = [x]
    for j in range(n - 2):
        t1 = np.maximum(x - k[j], 0) ** 3
        t2 = np.maximum(x - k[n - 2], 0) ** 3 * (k[n - 1] - k[j]) / (k[n - 1] - k[n - 2])
        t3 = np.maximum(x - k[n - 1], 0) ** 3 * (k[n - 2] - k[j]) / (k[n - 1] - k[n - 2])
        b.append(t1 - t2 + t3)
    return np.column_stack(b)


def wq(x, w, qs):
    x = np.asarray(x, float); w = np.asarray(w, float)
    m = ~np.isnan(x) & ~np.isnan(w); x, w = x[m], w[m]
    o = np.argsort(x); x, w = x[o], w[o]
    return np.interp(qs, np.cumsum(w) / w.sum(), x)


def curve(d, y, family, knots, covs, grid):
    dd = d.dropna(subset=["ua", y] + covs).copy()
    B = rcs(dd["ua"].to_numpy(), knots)
    for j in range(1, B.shape[1]):
        dd[f"rcs{j}"] = B[:, j]
    rcst = [f"rcs{j}" for j in range(1, B.shape[1])]
    cols = list(set([y, "ua", "strata", "psu", "wt_comb"] + rcst + covs))
    s = svy.Sample(to_pl(dd, cols), svy.Design(stratum="strata", psu="psu",
                                               wgt="wt_comb", singleton="center"))
    m = s.glm.fit(y=y, x=feats(["ua"] + rcst + covs), family=family)
    Bg = rcs(grid, knots)
    rows = []
    for i, v in enumerate(grid):
        row = {c: float(dd[c].median()) for c in covs}
        for c in ["sex", "race5", "edu3", "smoke", "alcohol", "diabetes", "hypertension"]:
            if c in covs:
                row[c] = float(dd[c].mode()[0])
        row["ua"] = v
        for j in range(1, Bg.shape[1]):
            row[f"rcs{j}"] = Bg[i, j]
        rows.append(row)
    new = pl.DataFrame({k: [r[k] for r in rows] for k in rows[0]})
    for c in CATS:
        if c in new.columns:
            new = new.with_columns(pl.col(c).cast(pl.Int32, strict=False).cast(pl.Utf8))
    pr = m.predict(new).to_polars().to_pandas()
    return pr


# ---- arthritis by sex ----
d = df.dropna(subset=["ua", "arthritis_bin", "sex"]).copy()
kn = wq(d["ua"], d["wt_comb"], [0.05, 0.35, 0.65, 0.95])
grid = np.linspace(2.5, 9.5, 55)
out = {"ua": grid}
for lab, sx in [("male", 1), ("female", 2)]:
    sub = d[d["sex"] == sx]
    covs = [c for c in FULL if c != "sex"]
    pr = curve(sub, "arthritis_bin", "binomial", kn, covs, grid)
    lg = np.log(pr["yhat"] / (1 - pr["yhat"]))
    lo = np.log(pr["lci"] / (1 - pr["lci"])); hi = np.log(pr["uci"] / (1 - pr["uci"]))
    ref = float(np.median(sub["ua"]))
    r0 = np.interp(ref, grid, lg); rl = np.interp(ref, grid, lo); rh = np.interp(ref, grid, hi)
    out[f"or_{lab}"] = np.exp(lg - r0)
    out[f"lo_{lab}"] = np.exp(lo - rh)
    out[f"hi_{lab}"] = np.exp(hi - rl)
    print("sex", lab, "n", len(sub), "knots", np.round(kn, 2))
pd.DataFrame(out).to_csv(os.path.join(RES, "rcs_arthritis_sex.csv"), index=False)

# ---- arthritis by BMI category (<30 vs >=30) ----
d["bmi30"] = np.where(d["bmi"] < 30, 0, 1)
out = {"ua": grid}
for lab, bv in [("lt30", 0), ("ge30", 1)]:
    sub = d[d["bmi30"] == bv]
    covs = [c for c in FULL if c != "bmi"]
    pr = curve(sub, "arthritis_bin", "binomial", kn, covs, grid)
    lg = np.log(pr["yhat"] / (1 - pr["yhat"]))
    lo = np.log(pr["lci"] / (1 - pr["lci"])); hi = np.log(pr["uci"] / (1 - pr["uci"]))
    ref = float(np.median(sub["ua"]))
    r0 = np.interp(ref, grid, lg); rl = np.interp(ref, grid, lo); rh = np.interp(ref, grid, hi)
    out[f"or_{lab}"] = np.exp(lg - r0)
    out[f"lo_{lab}"] = np.exp(lo - rh); out[f"hi_{lab}"] = np.exp(hi - rl)
    print("bmi", lab, "n", len(sub))
pd.DataFrame(out).to_csv(os.path.join(RES, "rcs_arthritis_bmi.csv"), index=False)

# ---- BMD by sex ----
b = df.dropna(subset=["ua", "fn_bmd", "sex"]).copy()
knb = wq(b["ua"], b["wt_comb"], [0.05, 0.35, 0.65, 0.95])
gb = np.linspace(2.5, 9.0, 50)
out = {"ua": gb}
for lab, sx in [("male", 1), ("female", 2)]:
    sub = b[b["sex"] == sx]
    covs = [c for c in FULL if c != "sex"]
    pr = curve(sub, "fn_bmd", "gaussian", knb, covs, gb)
    ref = float(np.median(sub["ua"]))
    y0 = np.interp(ref, gb, pr["yhat"].to_numpy())
    c0 = np.interp(ref, gb, pr["lci"].to_numpy()); c1 = np.interp(ref, gb, pr["uci"].to_numpy())
    out[f"d_{lab}"] = pr["yhat"].to_numpy() - y0
    out[f"lo_{lab}"] = pr["lci"].to_numpy() - c1
    out[f"hi_{lab}"] = pr["uci"].to_numpy() - c0
    print("bmd sex", lab, "n", len(sub))
pd.DataFrame(out).to_csv(os.path.join(RES, "rcs_bmd_sex.csv"), index=False)
print("done stratified RCS")
