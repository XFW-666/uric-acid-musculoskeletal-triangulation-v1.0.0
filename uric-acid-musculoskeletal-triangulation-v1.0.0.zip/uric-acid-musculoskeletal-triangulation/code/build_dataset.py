"""Assemble the pooled NHANES 1999-2023 analytic dataset.

Harmonises the era-specific file and variable names used across the 12 two-year
NHANES cycles, assigns cycle-appropriate survey weights and derives the analysis
variables.

Input:  data/<cycle>/*.xpt   (fetch with code/download_nhanes.py)
Output: data/analytic.csv, data/diag.json
"""
import pandas as pd, numpy as np, os, json, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(DATA, "analytic.csv")

CYCLES = [
    ("1999-2000", 1999, ""), ("2001-2002", 2001, "_B"), ("2003-2004", 2003, "_C"),
    ("2005-2006", 2005, "_D"), ("2007-2008", 2007, "_E"), ("2009-2010", 2009, "_F"),
    ("2011-2012", 2011, "_G"), ("2013-2014", 2013, "_H"), ("2015-2016", 2015, "_I"),
    ("2017-2018", 2017, "_J"), ("2017-2020", 2017, "_P"), ("2021-2023", 2021, "_L"),
]

# candidate variable names per concept (first present wins)
V = {
    "age": ["RIDAGEYR"], "sex": ["RIAGENDR"], "race": ["RIDRETH1", "RIDRETH3"],
    "edu": ["DMDEDUC2"], "pir": ["INDFMPIR"], "preg": ["RIDEXPRG"],
    "bmi": ["BMXBMI"], "waist": ["BMXWAIST"], "height": ["BMXHT"], "weight": ["BMXWT"],
    "arthritis": ["MCQ160A"], "arthritis_type": ["MCQ195"], "gout_a": ["MCQ160N"], "gout_b": ["MCQ160M"],
    "osq_osteo": ["OSQ010A"], "osq_fx": ["OSQ010B"], "hip_fx": ["OSQ040AA"],
    "ua": ["LBXSUA"], "albumin": ["LBXSAL"], "alp": ["LBXSAPSI", "LBDSAPSI"],
    "calcium": ["LBXSCA"], "phosphorus": ["LBXSPH", "LBDSPH"],
    "creatinine": ["LBXSCR", "LBDSCR"], "glucose": ["LBXSGL", "LBDSGL"],
    "trigly": ["LBXSTR", "LBDSTR"], "chol": ["LBXSCH", "LBDSCH"],
    "totprot": ["LBXSTP", "LBDSTP"], "bun": ["LBXSBU", "LBDSBU"],
    "wbc": ["LBXWBCSI"], "neut_no": ["LBDNENO"], "lymph_no": ["LBDLYMNO"],
    "neut_pct": ["LBXNEPCT"], "lymph_pct": ["LBXLYPCT"], "plt": ["LBXPLTSI"], "hgb": ["LBXHGB"],
    "crp": ["LBXHSCRP", "LBXCRP"],
    "smoke100": ["SMQ020"], "smoke_now": ["SMQ040"],
    "alc_ever": ["ALQ101", "ALQ111", "ALQ100", "ALQ110"],
    "alc_freq": ["ALQ120Q", "ALQ121"], "alc_drinks": ["ALQ130"],
    "diabetes": ["DIQ010"], "hypertension": ["BPQ020"], "hbp_med": ["BPQ040A", "BPQ050A"],
    "menopause": ["RHQ060"], "sleep": ["SLD010H", "SLD012"],
    "energy": ["DR1TKCAL", "DRXTKCAL"], "diet_ca": ["DR1TCALC", "DRXTCALC"],
    "diet_prot": ["DR1TPROT", "DRXTPROT"],
    "sedentary": ["PAD680"], "mvpa_vig": ["PAQ650", "PAQ605", "PAD790Q", "PAQ500"],
    "mvpa_mod": ["PAQ665", "PAQ625", "PAD810Q", "PAQ520"],
    "fn_bmd": ["DXXNKBMD", "DXXFNBMD"], "totfemur_bmd": ["DXXOFBMD"],
    "troch_bmd": ["DXXTRBMD"], "totbody_bmd": ["DXDTOBMD"],
    "wt2": ["WTMEC2YR"], "wt4": ["WTMEC4YR"], "wtprp": ["WTMECPRP"],
    "psu": ["SDMVPSU"], "strata": ["SDMVSTRA"],
}


def load_cycle(cyc):
    d = os.path.join(DATA, cyc)
    frames = {}
    for f in sorted(os.listdir(d)):
        if f.endswith(".xpt"):
            try:
                frames[f] = pd.read_sas(os.path.join(d, f), format="xport")
            except Exception as e:
                print(f"   !! read fail {cyc}/{f}: {e}")
    return frames


def build_index(frames):
    """map column -> (df, filename)"""
    idx = {}
    for f, df in frames.items():
        for c in df.columns:
            idx.setdefault(c, (df, f))
    return idx


def extract(idx, key, name=None):
    """Return (SEQN, value) DataFrame for concept `key`, or None."""
    nm = name or key
    for cand in V[key]:
        if cand in idx:
            df, _ = idx[cand]
            return df[["SEQN", cand]].rename(columns={cand: nm}).drop_duplicates("SEQN")
    return None


rows = []
diag = []
for cyc, year, suf in CYCLES:
    frames = load_cycle(cyc)
    idx = build_index(frames)
    if "SEQN" not in idx:
        diag.append({"cycle": cyc, "n": 0, "err": "no SEQN"}); continue
    base = pd.DataFrame({"SEQN": frames[[k for k in frames if "DEMO" in k or k.startswith("P_DEMO")][0]]["SEQN"].unique()})
    merged = base.copy()
    used = {}
    for key in list(V.keys()):
        part = extract(idx, key)
        if part is None:
            used[key] = None
            continue
        cand = None
        for c in V[key]:
            if c in idx:
                cand = c; break
        used[key] = cand
        merged = merged.merge(part, on="SEQN", how="left")
    merged["cycle"] = cyc
    merged["year"] = year
    merged = merged.drop_duplicates("SEQN")
    rows.append(merged)
    diag.append({"cycle": cyc, "n": len(merged),
                 "ua": used.get("ua"), "arth": used.get("arthritis"),
                 "wt": [k for k in ["wt2", "wt4", "wtprp"] if used.get(k)],
                 "gout": [k for k in ["gout_a", "gout_b"] if used.get(k)],
                 "fn_bmd": used.get("fn_bmd"), "crp": used.get("crp")})
    print(f"{cyc}: n={len(merged)} ua={used.get('ua')} arth={used.get('arthritis')} "
          f"wt={[k for k in ['wt2','wt4','wtprp'] if used.get(k)]}", flush=True)

df = pd.concat(rows, ignore_index=True, sort=False)
df.to_csv(OUT, index=False)
print(f"\nCombined: {df.shape}  -> {OUT}")
json.dump(diag, open(os.path.join(DATA, "diag.json"), "w"), indent=1, default=str)

# quick sanity: uric acid + arthritis
print("\n--- sanity ---")
print("UA non-missing:", df["ua"].notna().sum())
print("arthritis non-missing:", df["arthritis"].notna().sum())
print("UA describe:", df["ua"].describe().to_dict())
print("arthritis value counts:", df["arthritis"].value_counts(dropna=False).to_dict())
