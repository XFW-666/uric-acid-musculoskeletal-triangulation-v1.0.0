"""Assemble the manuscript DOCX from the markdown source.

Renders the title block, headings, three-line tables and the figure captions,
embeds the figures at full resolution and adds page numbering.

Input:  manuscript/manuscript.md, figures/*.png
Output: manuscript/Uric_acid_arthritis_BMD_JOSR_manuscript.docx
"""
import os, re, sys
from docx import Document
from docx.shared import Pt, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MD = os.path.join(ROOT, "manuscript", "manuscript.md")
FIG = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "manuscript", "Uric_acid_arthritis_BMD_JOSR_manuscript.docx")

FONT = "Times New Roman"
BODY_PT = 12
LINE = 1.3


def set_run_font(run, size=BODY_PT, bold=None, italic=None, color=(0, 0, 0), font=FONT):
    run.font.name = font
    run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if italic is not None:
        run.font.italic = italic
    run.font.color.rgb = RGBColor(*color)
    rpr = run._element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts"); rpr.append(rf)
    rf.set(qn("w:ascii"), font); rf.set(qn("w:hAnsi"), font)
    rf.set(qn("w:eastAsia"), font); rf.set(qn("w:cs"), font)


def add_runs(par, text, size=BODY_PT):
    """Parse **bold** and *italic* into runs."""
    for tok in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*)", text):
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**"):
            set_run_font(par.add_run(tok[2:-2]), size=size, bold=True)
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            set_run_font(par.add_run(tok[1:-1]), size=size, italic=True)
        else:
            set_run_font(par.add_run(tok), size=size)


def body_par(doc, text, size=BODY_PT, align=WD_ALIGN_PARAGRAPH.JUSTIFY, space_after=6,
             indent_first=False, italic_all=False):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = LINE
    pf.space_after = Pt(space_after)
    pf.alignment = align
    if indent_first:
        pf.first_line_indent = Pt(size * 2)
    if italic_all:
        set_run_font(p.add_run(text), size=size, italic=True)
    else:
        add_runs(p, text, size=size)
    return p


def heading(doc, text, level, break_before=False):
    sizes = {1: 15, 2: 13, 3: 12}
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = LINE
    pf.space_before = Pt(14 if level == 1 else 10)
    pf.space_after = Pt(6)
    pf.keep_with_next = True
    if break_before:
        pf.page_break_before = True
    set_run_font(p.add_run(text), size=sizes.get(level, 12), bold=True)
    return p


def set_cell_borders(cell, top=None, bottom=None):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge, spec in (("top", top), ("bottom", bottom)):
        el = OxmlElement(f"w:{edge}")
        if spec is None:
            el.set(qn("w:val"), "nil")
        else:
            el.set(qn("w:val"), "single"); el.set(qn("w:sz"), str(spec))
            el.set(qn("w:space"), "0"); el.set(qn("w:color"), "000000")
        borders.append(el)
    for edge in ("left", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}"); el.set(qn("w:val"), "nil"); borders.append(el)
    tcPr.append(borders)


def shade(cell, hexcolor="F2F2F2"):
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto")
    sh.set(qn("w:fill"), hexcolor)
    tcPr.append(sh)


def add_three_line_table(doc, rows, fontsize=8.5):
    ncols = max(len(r) for r in rows)
    t = doc.add_table(rows=0, cols=ncols)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = True
    for i, row in enumerate(rows):
        cells = t.add_row().cells
        for j in range(ncols):
            txt = row[j] if j < len(row) else ""
            cell = cells[j]
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.space_before = Pt(1)
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if j == 0 else WD_ALIGN_PARAGRAPH.CENTER
            set_run_font(p.add_run(txt), size=fontsize, bold=(i == 0))
            top = 12 if i == 0 else None
            bottom = 6 if i == 0 else (12 if i == len(rows) - 1 else None)
            set_cell_borders(cell, top=top, bottom=bottom)
            if i == 0:
                shade(cell)
    return t


def add_page_number_footer(section):
    footer = section.footer
    p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    set_run_font(run, size=10, color=(0x33, 0x33, 0x33))
    fld1 = OxmlElement("w:fldChar"); fld1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE \\* arabic \\* MERGEFORMAT"
    fld2 = OxmlElement("w:fldChar"); fld2.set(qn("w:fldCharType"), "end")
    run._r.append(fld1); run._r.append(instr); run._r.append(fld2)


def _embed_path(path, max_px=4400):
    """Keep sources at their native 600-dpi resolution inside the DOCX."""
    try:
        from PIL import Image
        im = Image.open(path)
        if im.width <= max_px:
            return path
        h = max(1, int(im.height * max_px / im.width))
        im = im.convert("RGB").resize((max_px, h), Image.LANCZOS)
        tmp = path + ".embed.png"
        im.save(tmp, "PNG", optimize=True)
        return tmp
    except Exception:
        return path


def _sup_runs(par, text, size):
    """Add runs to a paragraph, rendering ^digit markers as superscripts."""
    import re as _re
    for tok in _re.split(r"(\^\d)", text):
        if not tok:
            continue
        m = _re.fullmatch(r"\^(\d)", tok)
        if m:
            r = par.add_run(m.group(1))
            set_run_font(r, size=size)
            r.font.superscript = True
        else:
            r = par.add_run(tok)
            set_run_font(r, size=size)


def add_figure(doc, path, caption, width_cm=16.0):
    path = _embed_path(path)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    run = p.add_run()
    run.add_picture(path, width=Cm(width_cm))
    cp = doc.add_paragraph()
    cp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    cp.paragraph_format.line_spacing = 1.15
    cp.paragraph_format.space_after = Pt(12)
    add_runs(cp, caption, size=9)


# ---------------------------------------------------------------- build
doc = Document()
st = doc.styles["Normal"]
st.font.name = FONT
st.font.size = Pt(BODY_PT)
st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
sec.top_margin = sec.bottom_margin = Cm(2.54)
sec.left_margin = Cm(3.0); sec.right_margin = Cm(2.5)
add_page_number_footer(sec)

md = open(MD, encoding="utf-8").read()
lines = md.split("\n")

# ---- title block ----
i = 0
while i < len(lines) and not lines[i].startswith("## Abstract"):
    ln = lines[i].strip()
    if ln.startswith("# "):
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(10); p.paragraph_format.line_spacing = 1.2
        set_run_font(p.add_run(ln[2:]), size=16, bold=True)
    elif ln.startswith("**Running head:**") or ln.startswith("**Authors:**") or \
         ln.startswith("**Affiliations:**") or ln.startswith("*Correspondence:"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(4)
        _sup_runs(p, ln, 10.5)
    elif ln.startswith("^"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        _sup_runs(p, ln, 9.5)
    elif ln.startswith("**Word count"):
        body_par(doc, ln, size=9.5, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2)
    i += 1

# ---- body: parse headings / tables / paragraphs ----
FIGURES = [
    ("Figure1_framework.png",
     "**Figure 1. Conceptual framework and multi-database triangulation design.** Mechanistic framework "
     "linking urate determinants to joint and bone outcomes, showing the dominant adiposity pathway, "
     "together with the six independent data sources used and their convergent conclusion."),
    ("Figure2_cohort_trends.png",
     "**Figure 2. NHANES 1999-2023: cohort assembly, exposure gradients and temporal trends.** "
     "(a) Participant selection (CONSORT-style). (b) Streamgraph of the weighted age composition of each "
     "survey cycle, showing progressive population ageing. (c) Distribution of serum uric acid with "
     "kernel density, quartile shading, quartile cut-points, the 6.8 mg/dL saturation threshold and a "
     "rug plot of individual observations. (d) Slope chart of crude versus fully adjusted odds ratios "
     "for uric acid quartiles 2-4, showing the reversal of the association after adiposity adjustment. "
     "(e) Ridgeline plot of the age distribution within each uric acid quartile. (f) Triangulated "
     "arthritis trend, 1999-2024, showing crude and age-standardised NHANES estimates alongside the "
     "independent NHIS series."),
    ("Figure3_associations.png",
     "**Figure 3. Serum uric acid and musculoskeletal outcomes.** (a) Odds ratios for arthritis by uric "
     "acid quartile across progressively adjusted models. (b) Adjustment ladder for hyperuricaemia. "
     "(c) Restricted cubic spline dose-response for arthritis. (d) Spline dose-response for femoral-neck bone "
     "mineral density. (e) Spline dose-response for self-reported fracture. (f) Prevalence of WHO T-score "
     "categories (osteopenia, osteoporosis) by uric acid quartile. (g) Subgroup analyses. (h) Sankey diagram of the mediation pathways, with ribbon width "
     "proportional to the proportion of the association mediated by each candidate pathway; the direct "
     "effect is approximately zero."),
    ("Figure4_prediction.png",
     "**Figure 4. Prediction of arthritis and multi-method interpretability.** (a) ROC curves for five "
     "models. (b) Calibration. (c) Decision-curve analysis. (d) Radar chart comparing the five models "
     "across six performance metrics. (e) Permutation importance with 95% confidence intervals. "
     "(f) Shape functions from the inherently interpretable Explainable Boosting Machine. (g) Accumulated "
     "local effects. (h) Individual conditional expectation curves for uric acid. (i) Two-dimensional "
     "partial-dependence surface over uric acid and body mass index, showing that the adiposity gradient "
     "dominates while the uric acid gradient is essentially flat."),
    ("Figure5_cross_database.png",
     "**Figure 5. Cross-database triangulation: genetics, drug safety and target evidence.** (a) "
     "Mendelian randomisation estimates for gout (positive control), osteoarthritis and osteoporosis in "
     "FinnGen R10. (b) Leave-one-out sensitivity analysis for gout, osteoarthritis and osteoporosis. "
     "(c) Manhattan-style landscape of the genetic instruments across the genome. (d) Agreement between the "
     "inverse-variance weighted, outlier-corrected and weighted-mode estimators. (e) Bubble matrix of Open "
     "Targets target-disease evidence, with bubble size encoding the overall association score and colour "
     "encoding the genetic score. (f) FAERS reporting odds ratios for urate-related drugs across "
     "musculoskeletal events. (g) Indication-matched comparison of febuxostat versus allopurinol. "
     "(h) Evidence matrix summarising the direction of evidence from each database for joint and bone "
     "outcomes."),
    ("Figure6_geo.png",
     "**Figure 6. Cartilage transcriptome (GEO GSE114007).** (a) Volcano plot of the osteoarthritis "
     "versus normal cartilage transcriptome, with pre-specified gene categories highlighted. "
     "(b) Raincloud plots of composite signature scores (half-violin density, box plot and jittered "
     "individual samples) for the urate-pathway, inflammasome and matrix-degradation signatures. "
     "(c) Clustered heatmap of row z-scored expression for selected panel genes across individual normal "
     "and osteoarthritis cartilage samples."),
]

FIGMAP = {}
for _fn, _cap in FIGURES:
    _m = re.search(r"Figure(\d+)", _fn)
    if _m:
        FIGMAP[int(_m.group(1))] = (_fn, _cap)
_inserted_figs = set()


def maybe_insert_figures(doc, text):
    """Insert a figure (image + caption) the first time it is cited in the body."""
    for m in re.finditer(r"Figure\s+(\d)", text):
        n = int(m.group(1))
        if n in _inserted_figs or n not in FIGMAP:
            continue
        fn, cap = FIGMAP[n]
        path = os.path.join(FIG, fn)
        if os.path.exists(path):
            add_figure(doc, path, cap)
            _inserted_figs.add(n)

in_refs = False
first_break = True
while i < len(lines):
    ln = lines[i]
    s = ln.strip()
    if s.startswith("## References"):
        in_refs = True
    if s.startswith("### ") and not in_refs:
        heading(doc, s[4:], 2); i += 1; continue
    if s.startswith("## "):
        brk = first_break or s[3:].startswith("References")
        first_break = False
        heading(doc, s[3:], 1, break_before=brk); i += 1; continue
    if s.startswith("|") and i + 1 < len(lines) and set(lines[i + 1].replace("|", "").replace(" ", "")) <= set("-:") and lines[i + 1].strip():
        tbl = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(set(c) <= set("-:") and c for c in cells):
                tbl.append(cells)
            i += 1
        add_three_line_table(doc, tbl)
        body_par(doc, "", size=6, space_after=2)
        continue
    if s == "---":
        i += 1; continue
    if not s:
        i += 1; continue
    if s.startswith("[") and in_refs:
        body_par(doc, s, size=10, align=WD_ALIGN_PARAGRAPH.LEFT, space_after=4)
        i += 1; continue
    if in_refs:
        body_par(doc, s, size=10, align=WD_ALIGN_PARAGRAPH.LEFT, space_after=4)
        i += 1; continue
    body_par(doc, s)
    maybe_insert_figures(doc, s)
    i += 1

# ---- figures section ----
# any figure not yet cited is appended at the end
_remaining = [(n, FIGMAP[n]) for n in sorted(FIGMAP) if n not in _inserted_figs]
if _remaining:
    heading(doc, "Figures", 1, break_before=True)
    for n, (fn, cap) in _remaining:
        pth = os.path.join(FIG, fn)
        if os.path.exists(pth):
            add_figure(doc, pth, cap)

doc.save(OUT)
print("saved", OUT)
print("size", os.path.getsize(OUT))
