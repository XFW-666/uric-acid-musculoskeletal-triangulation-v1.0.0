"""Figure QA: detect overlapping or out-of-bounds text in the generated figures.

Re-runs each figure script with an instrumented figure-save hook that measures
the rendered extent of every text artist and reports pairwise overlaps and text
that falls outside the canvas. Only artists that are actually drawn are
measured (tick labels outside the view interval are skipped).

Usage:  python code/check_label_overlaps.py [--details]
"""
import sys, os, runpy, itertools

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")
import figstyle

DETAILS = "--details" in sys.argv
REPORT = {}


def _interval(ax, axis):
    lo, hi = axis.get_view_interval()
    return lo, hi


def collect_texts(fig):
    rend = fig.canvas.get_renderer()
    items = []
    for ax_i, ax in enumerate(fig.axes):
        # ---- tick labels that are actually drawn ----
        if getattr(ax, "axison", True):
            for axis, (tmin, tmax) in ((ax.xaxis, _interval(ax, ax.xaxis)),
                                       (ax.yaxis, _interval(ax, ax.yaxis))):
                if not axis.get_visible():
                    continue
                for major in (True, False):
                    ticks = axis.get_major_ticks() if major else axis.get_minor_ticks()
                    for tk in ticks:
                        t = tk.label1
                        try:
                            loc = tk.get_loc()
                        except Exception:
                            continue
                        if not (tmin <= loc <= tmax):
                            continue
                        s = t.get_text()
                        if not s.strip():
                            continue
                        try:
                            bb = t.get_window_extent(renderer=rend)
                        except Exception:
                            continue
                        if bb.width <= 1 or bb.height <= 1:
                            continue
                        kind = "xtick" if axis is ax.xaxis else "ytick"
                        items.append((f"ax{ax_i}", f"[{kind}@{loc:g}] {s[:40]}", bb))
        # ---- free texts ----
        arts = [(t, "text") for t in ax.texts]
        if ax.get_title():
            arts.append((ax.title, "title"))
        for lbl, kind in ((ax.xaxis.label, "xlabel"), (ax.yaxis.label, "ylabel")):
            if lbl.get_text():
                arts.append((lbl, kind))
        leg = ax.get_legend()
        if leg is not None:
            arts.extend((t, "legend") for t in leg.get_texts())
        for t, kind in arts:
            try:
                bb = t.get_window_extent(renderer=rend)
            except Exception:
                continue
            if bb.width <= 1 or bb.height <= 1:
                continue
            s = t.get_text().replace("\n", " / ")
            if not s.strip():
                continue
            items.append((f"ax{ax_i}", f"[{kind}] {s[:46]}", bb))
    for t in fig.texts:
        try:
            bb = t.get_window_extent(renderer=rend)
        except Exception:
            continue
        if bb.width > 1 and t.get_text().strip():
            items.append(("fig", f"[figtext] {t.get_text()[:42]}", bb))
    return items


def overlaps(a, b):
    ix = max(0, min(a.x1, b.x1) - max(a.x0, b.x0))
    iy = max(0, min(a.y1, b.y1) - max(a.y0, b.y0))
    inter = ix * iy
    smaller = min(a.width * a.height, b.width * b.height)
    if smaller <= 0:
        return 0
    return inter / smaller


def check(fig, name):
    items = collect_texts(fig)
    hits = []
    fw, fh = fig.canvas.get_width_height()
    for (a1, s1, b1), (a2, s2, b2) in itertools.combinations(items, 2):
        r = overlaps(b1, b2)
        if r > 0.30:
            hits.append((r, a1, s1, b1, a2, s2, b2))
    oob = []
    for a1, s1, b1 in items:
        if b1.x0 < -2 or b1.y0 < -2 or b1.x1 > fw + 2 or b1.y1 > fh + 2:
            oob.append((a1, s1, b1))
    REPORT[name] = {"n_texts": len(items), "overlaps": hits, "out_of_bounds": oob,
                    "fw": fw, "fh": fh}


def dump(a, s, bb, fw, fh):
    print(f"      {a} '{s}'  bbox=({bb.x0:.0f},{bb.y0:.0f})-({bb.x1:.0f},{bb.y1:.0f}) "
          f"canvas={fw}x{fh}")


_orig = figstyle.save


def checked_save(fig, path, theme):
    try:
        fig.canvas.draw()
        check(fig, os.path.basename(path))
    except Exception as e:
        REPORT.setdefault(os.path.basename(path), {"error": str(e)[:120]})
    _orig(fig, path, theme)


figstyle.save = checked_save

SCRIPTS = ["code/figure2_3_cohort_and_associations.py",
           "code/figure4_prediction_interpretability.py",
           "code/figure5_6_cross_database.py"]

for sc in SCRIPTS:
    print("\n" + "=" * 74)
    print("RUNNING", sc)
    print("=" * 74)
    try:
        runpy.run_path(sc, run_name="__qa__")
    except SystemExit:
        pass
    except Exception as e:
        print("SCRIPT ERROR:", type(e).__name__, str(e)[:200])

print("\n" + "#" * 74)
print("# RENDERED-TEXT OVERLAP REPORT")
print("#" * 74)
total_bad = 0
for name, r in REPORT.items():
    if "error" in r:
        print(f"\n{name}: ERROR {r['error']}")
        continue
    print(f"\n{name}: {r['n_texts']} rendered text artists, {len(r['overlaps'])} overlaps, "
          f"{len(r['out_of_bounds'])} out-of-bounds")
    total_bad += len(r["overlaps"]) + len(r["out_of_bounds"])
    for frac, a1, s1, b1, a2, s2, b2 in sorted(r["overlaps"], reverse=True)[:14]:
        print(f"   [{frac*100:5.1f}%] {a1} '{s1}'  <->  {a2} '{s2}'")
        if DETAILS:
            dump(a1, s1, b1, r["fw"], r["fh"])
            dump(a2, s2, b2, r["fw"], r["fh"])
    for a1, s1, b1 in r["out_of_bounds"][:10]:
        print(f"   [OUT ] {a1} '{s1}'")
        if DETAILS:
            dump(a1, s1, b1, r["fw"], r["fh"])
print(f"\nTOTAL issues flagged: {total_bad}")
