"""Check reference integrity of the manuscript.

Verifies that every reference entry is cited in the text, that every citation
resolves to an entry, and that the reference list is numbered in order of first
appearance.

Usage:  python code/check_reference_integrity.py
"""
import io, re, sys

s = io.open("manuscript/manuscript.md", encoding="utf-8").read()
body, refs = s.split("## References", 1)

# reference entries
entries = {}
for m in re.finditer(r"^\[(\d+)\]\s", refs, re.M):
    entries[int(m.group(1))] = m.start()
n_refs = len(entries)
print("reference entries:", n_refs, "(numbers", min(entries), "-", max(entries), ")")

# citations in body (exclude the reference list)
cited = []
for m in re.finditer(r"\[([0-9,\s]+)\]", body):
    for part in m.group(1).split(","):
        part = part.strip()
        if part.isdigit():
            cited.append(int(part))
cited_set = set(cited)
print("distinct cited numbers:", len(cited_set))

missing_entry = sorted(c for c in cited_set if c not in entries)
uncited = sorted(n for n in entries if n not in cited_set)
print("cited but no entry:", missing_entry)
print("entry never cited:", uncited)

# first-appearance order
first = {}
for i, c in enumerate(cited):
    if c not in first:
        first[c] = i
order = sorted(first, key=lambda c: first[c])
print("\nfirst-appearance order:")
print(order)
inorder = order == sorted(order)
print("in strictly ascending order of first appearance:", inorder)
# count total citations
print("total citation instances:", len(cited))
