"""Apply the eligibility criteria and derive the final analysis variables.

Eligibility: adults aged >=20 years, not pregnant, valid serum uric acid
(0.5-20 mg/dL), determinate arthritis status.
Derives: hyperuricaemia, uric-acid quartiles, eGFR (CKD-EPI 2021), NLR, SII,
PLR and the categorical analysis variables.

Input:  data/analytic.csv
Output: data/analytic_clean.csv
"""
import pandas as pd, numpy as np, os, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
df = pd.read_csv(os.path.join(DATA, "analytic.csv"), low_memory=False)
print("raw:", df.shape)

# ---------- weights ----------
# per-2-year equivalent weights
wt = np.where(df["year"] <= 2002, df["wt4"] / 2.0,
      np.where(df["cycle"] == "2017-2020", df["wtprp"], df["wt2"]))
df["wt"] = wt
NCYC = 12
df["wt_comb"] = df["wt"] / NCYC
print("weight coverage:", df["wt"].notna().sum(), "/", len(df))

# ---------- eligibility ----------
n0 = len(df)
df = df[df["age"] >= 20]
print(f"age>=20: {len(df)} (dropped {n0-len(df)})")
n1 = len(df)
df = df[~(df["preg"] == 1)]
print(f"non-pregnant: {len(df)} (dropped {n1-len(df)})")
n2 = len(df)
df = df[df["ua"].notna() & (df["ua"] > 0.5) & (df["ua"] < 20)]
print(f"valid UA: {len(df)} (dropped {n2-len(df)})")
n3 = len(df)
df = df[df["arthritis"].isin([1.0, 2.0])]
print(f"known arthritis: {len(df)} (dropped {n3-len(df)})")
df = df[df["wt"].notna() & (df["wt"] > 0)]
print(f"with weight: {len(df)}")

# ---------- outcomes ----------
df["arthritis_bin"] = (df["arthritis"] == 1).astype(int)
df["gout_n"] = df["gout_a"].map({1.0: 1, 2.0: 0})
df["gout_m"] = df["gout_b"].map({1.0: 1, 2.0: 0})
df["osteoporosis"] = df["osq_osteo"].map({1.0: 1, 2.0: 0})
df["osq_fracture"] = df["osq_fx"].map({1.0: 1, 2.0: 0})
df["hip_fracture"] = df["hip_fx"].map({1.0: 1, 2.0: 0})
# arthritis subtype (2011+)
df["oa_subtype"] = np.where(df["arthritis_type"].isin([1.0]), 1,
                     np.where(df["arthritis_type"].notna(), 0, np.nan))

# ---------- exposure ----------
df["hyperuricemia"] = (((df["sex"] == 1) & (df["ua"] > 7.0)) |
                       ((df["sex"] == 2) & (df["ua"] > 6.0))).astype(int)
df["hyperuricemia_sat"] = (df["ua"] > 6.8).astype(int)
df["log_ua"] = np.log(df["ua"])


def wquantile(x, w, qs):
    x = np.asarray(x, float); w = np.asarray(w, float)
    m = ~np.isnan(x) & ~np.isnan(w) & (w > 0)
    x, w = x[m], w[m]
    o = np.argsort(x); x, w = x[o], w[o]
    cw = np.cumsum(w) / w.sum()
    return np.interp(qs, cw, x)


qs = wquantile(df["ua"], df["wt"], [0.25, 0.50, 0.75])
print("weighted UA quartile cutpoints:", np.round(qs, 3))
df["ua_q"] = pd.cut(df["ua"], bins=[-np.inf, qs[0], qs[1], qs[2], np.inf], labels=[1, 2, 3, 4]).astype(float)

# ---------- renal function: CKD-EPI 2021 (race-free) ----------
scr = df["creatinine"]
female = (df["sex"] == 2)
k = np.where(female, 0.7, 0.9)
a = np.where(female, -0.241, -0.302)
egfr = 142 * np.minimum(scr / k, 1) ** a * np.maximum(scr / k, 1) ** (-1.200) * 0.9938 ** df["age"]
egfr = np.where(female, egfr * 1.012, egfr)
df["egfr"] = egfr
df.loc[(df["age"] < 20) | scr.isna() | (scr <= 0), "egfr"] = np.nan

# ---------- inflammation indices ----------
df["nlr"] = df["neut_no"] / df["lymph_no"]
df["sii"] = df["plt"] * df["neut_no"] / df["lymph_no"]
df["plr"] = df["plt"] / df["lymph_no"]
df.loc[(df["nlr"] <= 0) | (df["nlr"] > 100), "nlr"] = np.nan
df.loc[(df["sii"] <= 0) | (df["sii"] > 1e5), "sii"] = np.nan

# ---------- covariates ----------
df["smoke"] = np.where(df["smoke100"] == 2, 0,
               np.where((df["smoke100"] == 1) & (df["smoke_now"] == 3), 1,
               np.where((df["smoke100"] == 1) & df["smoke_now"].isin([1, 2]), 2, np.nan)))
df["alcohol"] = df["alc_ever"].map({1.0: 1, 2.0: 0})
df["diabetes"] = df["diabetes"].map({1.0: 1, 2.0: 0})
df["hypertension"] = df["hypertension"].map({1.0: 1, 2.0: 0})
df["hbp_med"] = df["hbp_med"].map({1.0: 1, 2.0: 0})
df["edu3"] = df["edu"].map({1.0: 1, 2.0: 1, 3.0: 2, 4.0: 3, 5.0: 3})
df["race5"] = df["race"]
df["bmi_cat"] = pd.cut(df["bmi"], [0, 25, 30, 35, 100], labels=[1, 2, 3, 4]).astype(float)
df["age_grp"] = pd.cut(df["age"], [20, 40, 60, 200], labels=[1, 2, 3], right=False).astype(float)
df["postmeno"] = np.where((df["sex"] == 2) & ((df["menopause"].notna()) | (df["age"] >= 55)), 1,
                  np.where(df["sex"] == 2, 0, np.nan))

# physical activity (min/wk MVPA) where the standard leisure items exist
for c in ["mvpa_vig", "mvpa_mod"]:
    df[c + "_min"] = pd.to_numeric(df[c], errors="coerce")
mv = df[["mvpa_vig_min", "mvpa_mod_min"]].fillna(0).sum(axis=1)
df["mvpa_min"] = np.where(df["mvpa_vig_min"].notna() | df["mvpa_mod_min"].notna(), mv, np.nan)
df["mvpa_active"] = np.where(df["mvpa_min"].isna(), np.nan,
                      np.where(df["mvpa_min"] >= 150, 2,
                      np.where(df["mvpa_min"] > 0, 1, 0)))

df.to_csv(os.path.join(DATA, "analytic_clean.csv"), index=False)
print("\nsaved analytic_clean.csv", df.shape)

# ---------- diagnostics ----------
print("\n=== N per cycle ===")
print(df.groupby("cycle").agg(n=("SEQN", "size"), ua=("ua", "count"),
                              arth=("arthritis_bin", "sum")).to_string())
print("\n=== weighted prevalence of arthritis by cycle ===")
def wprev(g):
    w = g["wt"]; y = g["arthritis_bin"]
    return np.average(y, weights=w) * 100
print(df.groupby("cycle").apply(wprev, include_groups=False).round(2).to_string())

print("\n=== key variable completeness (%) ===")
for c in ["ua", "arthritis_bin", "age", "sex", "race5", "edu3", "pir", "bmi", "waist",
          "smoke", "alcohol", "diabetes", "hypertension", "egfr", "albumin", "alp",
          "calcium", "phosphorus", "energy", "diet_ca", "crp", "nlr", "sii",
          "sleep", "mvpa_min", "fn_bmd", "osteoporosis"]:
    print(f"  {c:16s} {df[c].notna().mean()*100:6.1f}")

print("\n=== gout variable check (prevalence %) ===")
for c in ["gout_n", "gout_m"]:
    sub = df[df["cycle"].isin(["2007-2008", "2011-2012"])]
    print(f"  {c}: {sub[c].mean()*100:.2f}% (2007-2012), overall {df[c].mean()*100:.2f}%")

print("\n=== ua_q distribution ===")
print(df["ua_q"].value_counts().sort_index().to_string())
print("\nhyperuricemia prev (weighted):", round(np.average(df["hyperuricemia"], weights=df["wt"]) * 100, 2), "%")
print("arthritis prev (weighted):", round(np.average(df["arthritis_bin"], weights=df["wt"]) * 100, 2), "%")
