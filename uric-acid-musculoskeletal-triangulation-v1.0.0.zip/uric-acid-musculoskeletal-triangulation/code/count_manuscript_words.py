"""Report the abstract, main-text and table counts of the manuscript source."""

import re
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
md = open("manuscript/manuscript.md", encoding="utf-8").read()
ab = md.split("## Abstract")[1].split("**Keywords:**")[0]
ab = re.sub(r"\*\*[^*]+\*\*", "", ab)
print("abstract words:", len([w for w in re.split(r"\s+", ab) if w.strip()]))
body = md.split("## Background")[1].split("## Declarations")[0]
body = re.sub(r"\*\*[^*]+\*\*", "", body)
print("main text words:", len([w for w in re.split(r"\s+", body) if w.strip()]))
print("tables:", md.count("### Table"))
print("figures referenced:", len(re.findall(r"\*\*Figure \d", md)))
