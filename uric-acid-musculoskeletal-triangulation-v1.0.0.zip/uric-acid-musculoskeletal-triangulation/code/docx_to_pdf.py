"""Convert the assembled manuscript DOCX to PDF at print quality (Microsoft Word)."""
import os, sys
import win32com.client

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = os.path.join(ROOT, "manuscript", "Uric_acid_arthritis_BMD_JOSR_manuscript.docx")
dst = os.path.join(ROOT, "manuscript", "Uric_acid_arthritis_BMD_JOSR_manuscript.pdf")

word = win32com.client.DispatchEx("Word.Application")
word.Visible = False
word.DisplayAlerts = 0
try:
    doc = word.Documents.Open(src, ReadOnly=True)
    doc.ExportAsFixedFormat(OutputFileName=dst, ExportFormat=17,  # 17 = PDF
                        OpenAfterExport=False, OptimizeFor=0)  # 0 = print quality
    doc.Close(False)
    print("PDF written:", dst, os.path.getsize(dst))
finally:
    word.Quit()
