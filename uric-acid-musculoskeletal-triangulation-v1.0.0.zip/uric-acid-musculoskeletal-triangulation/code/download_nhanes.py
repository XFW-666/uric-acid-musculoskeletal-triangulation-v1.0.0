"""Download the NHANES 1999-2023 source files used in this study.

The files that make up the pooled dataset are listed in data/manifest.json,
which records the exact file name retrieved for every survey component and
cycle.  This script fetches them from the CDC/NCHS public server into
data/<cycle>/, together with the 27 files of the 2017-March 2020 pre-pandemic
cycle (published with a P_ prefix).  Files that are already present and valid
are skipped, so the script is safe to re-run.

URL pattern:  https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/<year>/DataFiles/<file>

Usage:   python code/download_nhanes.py
Input:   data/manifest.json
Output:  data/<cycle>/*.xpt
"""
import json
import os
import time

import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
BASE = "https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public"
XPT_MAGIC = b"HEADER RECORD**"

# 2017-March 2020 pre-pandemic cycle: published with the P_ prefix
# (the 27 files retrieved for this study)
PRE_PANDEMIC = [
    "P_ALB_CR.xpt",
    "P_ALQ.xpt",
    "P_BIOPRO.xpt",
    "P_BMX.xpt",
    "P_BPQ.xpt",
    "P_CBC.xpt",
    "P_COT.xpt",
    "P_DEMO.xpt",
    "P_DIQ.xpt",
    "P_DR1TOT.xpt",
    "P_DXXFEM.xpt",
    "P_GHB.xpt",
    "P_GLU.xpt",
    "P_HDL.xpt",
    "P_HIQ.xpt",
    "P_HSCRP.xpt",
    "P_INQ.xpt",
    "P_INS.xpt",
    "P_MCQ.xpt",
    "P_OSQ.xpt",
    "P_PAQ.xpt",
    "P_PBCD.xpt",
    "P_RHQ.xpt",
    "P_SLQ.xpt",
    "P_SMQ.xpt",
    "P_TCHOL.xpt",
    "P_TRIGLY.xpt",
]

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "Mozilla/5.0 (compatible; research-tool)"})


def fetch(url, dest, tries=4):
    """Download url to dest; return the number of bytes written (0 on failure)."""
    if os.path.exists(dest) and os.path.getsize(dest) > 5000:
        return -1                                     # already present
    for attempt in range(tries):
        try:
            r = SESSION.get(url, timeout=300)
            if r.status_code == 404:
                return 0
            if r.status_code == 200 and r.content[:len(XPT_MAGIC)] == XPT_MAGIC:
                with open(dest, "wb") as f:
                    f.write(r.content)
                return len(r.content)
        except Exception:
            pass
        time.sleep(4 * (attempt + 1))
    return 0


def main():
    manifest = json.load(open(os.path.join(DATA, "manifest.json"), encoding="utf-8"))
    targets = []
    for key, rec in manifest.items():
        if not rec.get("ok"):
            continue
        cycle, _component = key.split("/", 1)
        targets.append((cycle, rec["file"]))
    targets += [("2017-2020", f) for f in PRE_PANDEMIC]

    ok = skipped = missing = 0
    for cycle, fname in targets:
        year = cycle.split("-")[0]
        outdir = os.path.join(DATA, cycle)
        os.makedirs(outdir, exist_ok=True)
        dest = os.path.join(outdir, fname)
        size = fetch(f"{BASE}/{year}/DataFiles/{fname}", dest)
        if size == -1:
            skipped += 1
        elif size > 0:
            ok += 1
            print(f"  OK    {cycle}/{fname}  {size / 1e6:.2f} MB", flush=True)
        else:
            missing += 1
            print(f"  MISS  {cycle}/{fname}", flush=True)
        time.sleep(0.4)

    print(f"\nDownloaded {ok}, already present {skipped}, unavailable {missing}.")
    print(f"Files are in {os.path.join(DATA, '<cycle>')}.")


if __name__ == "__main__":
    main()
