"""Download the NHIS Sample Adult public-use files (2019-2024).

The National Health Interview Survey Sample Adult component is used for the
independent temporal corroboration of the arthritis trend.  The CSV archives
published by NCHS are stored in data/nhis/ and read directly by
code/analysis_nhis_trend.py.

URL pattern:  https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS/<year>/adult<yy>csv.zip

Usage:   python code/download_nhis.py
Output:  data/nhis/adult19csv.zip ... adult24csv.zip
"""
import os
import time

import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEST = os.path.join(ROOT, "data", "nhis")
BASE = "https://ftp.cdc.gov/pub/Health_Statistics/NCHS/Datasets/NHIS"
YEARS = [2019, 2020, 2021, 2022, 2023, 2024]

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "Mozilla/5.0 (compatible; research-tool)"})


def main():
    os.makedirs(DEST, exist_ok=True)
    for year in YEARS:
        yy = str(year)[2:]
        dest = os.path.join(DEST, f"adult{yy}csv.zip")
        if os.path.exists(dest) and os.path.getsize(dest) > 100000:
            print(f"  have  {year}")
            continue
        url = f"{BASE}/{year}/adult{yy}csv.zip"
        for attempt in range(4):
            try:
                r = SESSION.get(url, timeout=300)
                if r.status_code == 200:
                    with open(dest, "wb") as f:
                        f.write(r.content)
                    print(f"  OK    {year}  {len(r.content) / 1e6:.2f} MB", flush=True)
                    break
            except Exception:
                pass
            time.sleep(4 * (attempt + 1))
        else:
            print(f"  MISS  {year}  {url}")
        time.sleep(0.5)


if __name__ == "__main__":
    main()
