"""Shared figure styling.

Primary theme: 'vivid' — white background, saturated high-contrast palette
(no black background), print-safe, with soft colour halos for emphasis.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from matplotlib.colors import LinearSegmentedColormap

VIVID = {
    "name": "vivid",
    "bg": "#ffffff", "panel": "#fcfdff", "panel_edge": "#dbe3ef",
    "text": "#0d1526", "muted": "#5b6b85", "grid": "#e9eff7",
    "cyan": "#0891b2", "magenta": "#db2777", "lime": "#4d7c0f", "amber": "#ea580c",
    "violet": "#7c3aed", "blue": "#2563eb", "red": "#dc2626", "teal": "#0d9488",
    "pink": "#e11d8f", "orange": "#f97316",
    "seq": ["#0891b2", "#db2777", "#4d7c0f", "#ea580c", "#7c3aed", "#2563eb", "#0d9488"],
    "glow": True, "glow_alphas": (0.045, 0.10, 0.20),
}

# kept for backwards compatibility / optional use
NEON = {
    "name": "neon", "bg": "#070a12", "panel": "#0d1320", "panel_edge": "#1c2740",
    "text": "#eaf1ff", "muted": "#8ea3c9", "grid": "#16203a",
    "cyan": "#22e0ff", "magenta": "#ff2f92", "lime": "#9dff2f", "amber": "#ffb020",
    "violet": "#a97bff", "blue": "#4d8dff", "red": "#ff5a5a", "teal": "#2ff5c8",
    "pink": "#ff7ac6", "orange": "#ff8a3d",
    "seq": ["#22e0ff", "#ff2f92", "#9dff2f", "#ffb020", "#a97bff", "#4d8dff", "#2ff5c8"],
    "glow": True, "glow_alphas": (0.05, 0.12, 0.25),
}
LIGHT = dict(VIVID)  # alias

_FONT = "DejaVu Sans"


def apply(theme):
    plt.rcParams.update({
        "font.family": _FONT, "font.size": 9.5,
        "axes.facecolor": theme["panel"], "figure.facecolor": theme["bg"],
        "savefig.facecolor": theme["bg"],
        "axes.edgecolor": theme["panel_edge"], "axes.labelcolor": theme["text"],
        "axes.titlecolor": theme["text"], "text.color": theme["text"],
        "xtick.color": theme["muted"], "ytick.color": theme["muted"],
        "grid.color": theme["grid"], "grid.linewidth": 0.8,
        "axes.grid": True, "axes.axisbelow": True,
        "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": False, "legend.labelcolor": theme["text"],
        "figure.dpi": 200, "savefig.dpi": 300,
        "lines.linewidth": 1.8, "lines.solid_capstyle": "round",
        "font.weight": "normal",
    })


def _ga(theme):
    return theme.get("glow_alphas", (0.05, 0.12, 0.25))


def glow_line(ax, x, y, color, lw=2.0, layers=(9, 5, 2.5), alphas=None, **kw):
    lbl = kw.pop("label", None)
    glow = kw.pop("glow", True)
    if alphas is None:
        alphas = (0.05, 0.12, 0.25)
    if glow:
        for L, a in zip(layers, alphas):
            ax.plot(x, y, color=color, lw=lw + L, alpha=a, solid_capstyle="round", zorder=2, **kw)
    ax.plot(x, y, color=color, lw=lw, zorder=3, label=lbl, **kw)


def glow_scatter(ax, x, y, color, s=26, layers=(90, 45), alphas=(0.10, 0.22), **kw):
    kw.pop("label", None)
    for L, a in zip(layers, alphas):
        ax.scatter(x, y, s=s + L, color=color, alpha=a, edgecolors="none", zorder=3, **kw)
    ax.scatter(x, y, s=s, color=color, edgecolors="none", zorder=4, **kw)


def glow_bar(ax, xpos, heights, color, width=0.6, **kw):
    ax.bar(xpos, heights, width=width, color=color, alpha=0.28, zorder=2, **kw)
    ax.bar(xpos, heights, width=width, color=color, alpha=1.0, zorder=3, **kw)


def panel(ax, letter, title=None, theme=None, dx=-0.075, dy=1.035, fs=12, pad=8):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=fs, fontweight="bold",
            color=theme["text"], va="bottom", ha="left",
            bbox=dict(boxstyle="round,pad=0.30", fc=theme["panel_edge"], ec="none", alpha=0.9))
    if title:
        ax.set_title(title, fontsize=10.0, fontweight="bold", color=theme["text"], pad=pad)


def neon_box(ax, xy, w, h, label, color, theme, fontsize=8.6, radius=0.03, alpha=0.13):
    x, y = xy
    if theme.get("glow"):
        for pad, a in [(0.030, 0.05), (0.016, 0.12)]:
            ax.add_patch(FancyBboxPatch((x - pad, y - pad), w + 2 * pad, h + 2 * pad,
                         boxstyle=f"round,pad=0,rounding_size={radius}", fc="none",
                         ec=color, lw=3.2, alpha=a, zorder=1))
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                 boxstyle=f"round,pad=0,rounding_size={radius}",
                 fc=color, ec=color, lw=1.7, alpha=alpha, zorder=2))
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                 boxstyle=f"round,pad=0,rounding_size={radius}",
                 fc="none", ec=color, lw=1.7, zorder=3))
    ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=fontsize,
            color=theme["text"], zorder=4, linespacing=1.35)


def neon_arrow(ax, p1, p2, color, theme, lw=2.0, style="-|>", rad=0.0, ms=11):
    if theme.get("glow"):
        for L, a in [(8, 0.06), (4, 0.14)]:
            ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=ms,
                         lw=lw + L, color=color, alpha=a, zorder=2,
                         connectionstyle=f"arc3,rad={rad}"))
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=ms, lw=lw,
                 color=color, zorder=3, connectionstyle=f"arc3,rad={rad}"))


def cmap(theme, lo=None, hi=None, name="v"):
    lo = lo or theme["panel"]
    hi = hi or theme["magenta"]
    return LinearSegmentedColormap.from_list(name, [lo, theme["cyan"], hi])


def save(fig, path, theme):
    fig.savefig(path, facecolor=theme["bg"], bbox_inches="tight", pad_inches=0.22)
    plt.close(fig)
    print("saved", path)
