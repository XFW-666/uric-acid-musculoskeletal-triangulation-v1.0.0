"""Figure 2 (cohort assembly, exposure gradients, trends) and Figure 3
(associations, dose-response, subgroups, mediation).

Input:  data/analytic_clean.csv, results/main_results.json,
        results/rcs_*_curve.csv, results/who_by_quartile.csv,
        results/subgroups.csv, results/mediation.csv, results/trends*.csv,
        results/nhis_arthritis_trend.csv
Output: figures/Figure2_cohort_trends.png, figures/Figure3_associations.png
"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch, Rectangle, FancyBboxPatch, Polygon
from matplotlib.path import Path
from matplotlib.ticker import FixedLocator, FuncFormatter
from scipy.stats import gaussian_kde
import figstyle as fs

T = fs.VIVID
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")
df = pd.read_csv(os.path.join(DATA, "analytic_clean.csv"), low_memory=False)
tr = pd.read_csv(os.path.join(RES, "trends.csv"))
tas = pd.read_csv(os.path.join(RES, "trends_agestd.csv"))
nhis = pd.read_csv(os.path.join(RES, "nhis_arthritis_trend.csv"))
main = json.load(open(os.path.join(RES, "main_results.json")))
NUM = ["estimate", "conf_low", "conf_high", "p_value"]


def num(recs):
    d = pd.DataFrame(recs)
    for c in d.columns:
        if c in NUM:
            d[c] = pd.to_numeric(d[c], errors="coerce")
    return d


def ribbon(ax, x0, y0a, y0b, x1, y1a, y1b, color, alpha=0.35, z=3):
    """Draw a smooth ribbon between two vertical spans (Sankey link)."""
    n = 60
    t = np.linspace(0, 1, n)
    s = 3 * t ** 2 - 2 * t ** 3
    xs = x0 + (x1 - x0) * t
    ya = y0a + (y1a - y0a) * s
    yb = y0b + (y1b - y0b) * s
    verts = list(zip(xs, ya)) + list(zip(xs[::-1], yb[::-1]))
    ax.add_patch(PathPatch(Path(verts, closed=True), fc=color, ec="none", alpha=alpha, zorder=z))


# ============================== FIGURE 2 ==============================
def fig2():
    fs.apply(T)
    fig = plt.figure(figsize=(17.4, 10.0))
    gs = fig.add_gridspec(2, 3, hspace=0.46, wspace=0.28, top=0.885, bottom=0.075,
                          left=0.055, right=0.98)
    fig.suptitle("NHANES 1999–2023: cohort assembly, exposure gradients and temporal trends",
                 fontsize=15, fontweight="bold", color=T["text"], y=0.965)

    # (a) CONSORT-style selection
    ax = fig.add_subplot(gs[0, 0]); ax.axis("off"); ax.grid(False)
    steps = [("NHANES 1999–2023", "128,809 records · 12 cycles", T["violet"]),
             ("Adults aged ≥20 years", "72,122", T["blue"]),
             ("Not pregnant", "70,453", T["teal"]),
             ("Valid serum uric acid", "60,859", T["cyan"]),
             ("Analytic cohort", "60,730 with arthritis status", T["lime"])]
    y = 0.94
    for i, (lbl, v, c) in enumerate(steps):
        h = 0.115 if i < len(steps) - 1 else 0.135
        fs.neon_box(ax, (0.05, y - h), 0.90, h * 0.86, f"{lbl}\n{v}", c, T, fontsize=8.0)
        if i < len(steps) - 1:
            fs.neon_arrow(ax, (0.50, y - h), (0.50, y - h - 0.055), c, T, lw=1.6, ms=10)
        y -= h + 0.045
    fs.panel(ax, "a", "Participant selection", T, dx=-0.03, dy=1.0)

    # (b) streamgraph of age composition by cycle
    ax = fig.add_subplot(gs[0, 1])
    bins = [20, 40, 60, 200]; labs = ["20–39", "40–59", "60+"]
    df["age3"] = pd.cut(df["age"], bins, labels=labs, right=False)
    comp = df.groupby(["cycle", "age3"], observed=True)["wt_comb"].sum().unstack(fill_value=0)
    comp = comp.reindex(tr["cycle"])
    comp = comp.div(comp.sum(axis=1), axis=0) * 100
    x = np.arange(len(comp))
    xs = np.linspace(0, len(comp) - 1, 300)
    series = [np.interp(xs, x, comp[c].to_numpy()) for c in labs]
    base = np.zeros_like(xs)
    cols = [T["cyan"], T["amber"], T["magenta"]]
    for s, c, lb in zip(series, cols, labs):
        ax.fill_between(xs, base, base + s, color=c, alpha=0.72, zorder=3, label=lb)
        base = base + s
    ax.set_xticks(x); ax.set_xticklabels(tr["cycle"], rotation=55, ha="right", fontsize=6.8)
    ax.set_ylabel("Age composition (% of weighted sample)")
    ax.set_xlim(0, len(comp) - 1); ax.set_ylim(0, 100)
    ax.legend(fontsize=7.4, ncol=3, loc="lower center")
    ax.text(0.02, 0.95, "population ageing across cycles", transform=ax.transAxes,
            fontsize=7.6, color=T["text"], va="top", zorder=10,
            bbox=dict(boxstyle="round,pad=0.28", fc="white", ec="none", alpha=0.88))
    fs.panel(ax, "b", "Age composition by cycle", T)

    # (c) UA distribution: histogram + KDE + quartile bands + rug
    ax = fig.add_subplot(gs[0, 2])
    ua = df["ua"].dropna()
    qs = [4.4, 5.3, 6.3]
    bounds = [0] + qs + [12]
    bcols = [T["blue"], T["teal"], T["amber"], T["magenta"]]
    for i in range(4):
        ax.axvspan(bounds[i], bounds[i + 1], color=bcols[i], alpha=0.10, zorder=1)
    ax.hist(ua, bins=80, color=T["cyan"], alpha=0.45, edgecolor="none", density=True, zorder=2)
    kde = gaussian_kde(ua.sample(20000, random_state=1))
    xs = np.linspace(0.5, 12, 400)
    fs.glow_line(ax, xs, kde(xs), T["magenta"], lw=2.4)
    rug = ua.sample(600, random_state=2)
    ax.plot(rug, np.full(len(rug), -0.006), "|", color=T["muted"], ms=5, alpha=0.35, zorder=2)
    ax.axvline(6.8, color=T["magenta"], ls=":", lw=1.7, zorder=4)
    ax.text(6.9, kde(xs).max() * 0.92, "saturation\n6.8 mg/dL", fontsize=6.6, color=T["magenta"])
    for q in qs:
        ax.axvline(q, color=T["amber"], ls="--", lw=1.1, zorder=3)
    ax.set_xlim(0, 12); ax.set_ylim(-0.02, kde(xs).max() * 1.12)
    ax.set_xlabel("Serum uric acid (mg/dL)"); ax.set_ylabel("Density")
    for i, lb in enumerate(["Q1", "Q2", "Q3", "Q4"]):
        ax.text((bounds[i] + bounds[i + 1]) / 24, 1.035, lb, transform=ax.transAxes,
                ha="center", va="bottom", fontsize=7.6, color=bcols[i],
                fontweight="bold")
    fs.panel(ax, "c", "Uric acid distribution and quartiles", T, pad=22)

    # (d) slope chart: crude -> adjusted odds ratios
    ax = fig.add_subplot(gs[1, 0])
    qm = {"ua_q_2": "Q2 vs Q1", "ua_q_3": "Q3 vs Q1", "ua_q_4": "Q4 vs Q1"}
    crude = num([r for r in main["main_models"]["M1_crude"] if r["term"] in qm])
    adj = num([r for r in main["main_models"]["M3_full"] if r["term"] in qm])
    order = ["ua_q_2", "ua_q_3", "ua_q_4"]
    for i, t in enumerate(order):
        c = crude[crude["term"] == t].iloc[0]; a = adj[adj["term"] == t].iloc[0]
        col = [T["teal"], T["amber"], T["magenta"]][i]
        ax.plot([0, 1], [np.exp(c["estimate"]), np.exp(a["estimate"])], color=col, lw=2.6,
                marker="o", ms=8, zorder=3, solid_capstyle="round")
        ax.text(-0.06, np.exp(c["estimate"]), f"{np.exp(c['estimate']):.2f}", ha="right",
                va="center", fontsize=7.8, color=col, fontweight="bold")
        ax.text(1.06, np.exp(a["estimate"]), f"{np.exp(a['estimate']):.2f}", ha="left",
                va="center", fontsize=7.8, color=col, fontweight="bold")
    ax.axhline(1.0, color=T["blue"], ls="--", lw=1.3, zorder=1)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Crude", "Fully adjusted"], fontsize=8.6)
    ax.set_xlim(-0.42, 1.42); ax.set_ylabel("Odds ratio for arthritis")
    ax.text(0.97, 0.94, "The association reverses after adiposity adjustment",
            transform=ax.transAxes, ha="right", va="top", fontsize=7.4,
            color=T["muted"], style="italic")
    fs.panel(ax, "d", "Crude → adjusted odds ratios", T)

    # (e) ridgeline of age by quartile
    ax = fig.add_subplot(gs[1, 1])
    cols = [T["blue"], T["teal"], T["amber"], T["magenta"]]
    xs = np.linspace(18, 85, 300)
    for i, q in enumerate([1, 2, 3, 4]):
        v = df.loc[df["ua_q"] == q, "age"].dropna().to_numpy()
        vs = v if len(v) <= 20000 else np.random.RandomState(3).choice(v, 20000, replace=False)
        k = gaussian_kde(vs)
        y = k(xs); y = y / y.max() * 1.55
        base = 3 - i
        ax.fill_between(xs, base, base + y, color=cols[i], alpha=0.62, zorder=3 + i)
        ax.plot(xs, base + y, color=cols[i], lw=1.9, zorder=3 + i)
        ax.axhline(base, color=T["panel_edge"], lw=0.8, zorder=2)
        ax.text(18.6, base + 0.20, f"Q{i+1}", fontsize=8.2, color=cols[i], fontweight="bold",
                zorder=10, bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="none", alpha=0.88))
        med = np.median(v)
        ax.plot([med, med], [base, base + 0.30], color=T["text"], lw=1.2, zorder=9)
    ax.set_xlim(18, 85); ax.set_ylim(-0.15, 4.4)
    ax.set_yticks([]); ax.set_xlabel("Age (years)")
    ax.spines["left"].set_visible(False)
    fs.panel(ax, "e", "Age distribution by UA quartile (ridgeline)", T)

    # (f) triangulated trend
    ax = fig.add_subplot(gs[1, 2])
    x = tr["year"].to_numpy()
    ax.fill_between(x, tr["arthritis"] - 1.96 * tr["arthritis_se"],
                    tr["arthritis"] + 1.96 * tr["arthritis_se"], color=T["magenta"], alpha=0.15)
    fs.glow_line(ax, x, tr["arthritis"], T["magenta"], lw=2.4, marker="o", ms=5, label="NHANES crude")
    ax.fill_between(tas["year"], tas["agestd"] - 0.45, tas["agestd"] + 0.45, color=T["blue"], alpha=0.15)
    fs.glow_line(ax, tas["year"], tas["agestd"], T["blue"], lw=2.4, marker="s", ms=5,
                 label="NHANES age-standardised")
    fs.glow_line(ax, nhis["year"], nhis["arthritis"], T["teal"], lw=2.4, marker="^", ms=6,
                 label="NHIS (to 2024)")
    ax.set_xlabel("Year"); ax.set_ylabel("Arthritis prevalence (%)")
    ax.set_xticks([1999, 2005, 2011, 2017, 2024]); ax.tick_params(axis="x", labelsize=7.2)
    ax.legend(fontsize=7.2, loc="upper left")
    fs.panel(ax, "f", "Triangulated trend, 1999–2024", T)
    fs.save(fig, os.path.join(OUT, "Figure2_cohort_trends.png"), T)


# ============================== FIGURE 3 ==============================
def fig3():
    fs.apply(T)
    fig = plt.figure(figsize=(21.0, 10.4))
    gs = fig.add_gridspec(2, 4, hspace=0.44, wspace=0.34, top=0.885, bottom=0.075,
                          left=0.075, right=0.985)
    fig.suptitle("Serum uric acid and musculoskeletal outcomes: adjustment, dose-response, "
                 "subgroups, mediation and hard clinical endpoints",
                 fontsize=14.5, fontweight="bold", color=T["text"], y=0.965)
    M = [("M1_crude", "Crude", T["blue"]), ("M2_age_sex_race", "Age, sex, race", T["amber"]),
         ("M3_full", "Fully adjusted", T["magenta"])]

    # (a) quartile forest
    ax = fig.add_subplot(gs[0, 0])
    qm = {"ua_q_2": "Q2 vs Q1", "ua_q_3": "Q3 vs Q1", "ua_q_4": "Q4 vs Q1"}
    rows = []
    for k, lab, _ in M:
        for r in main["main_models"][k]:
            if r["term"] in qm:
                rows.append({"label": f"{qm[r['term']]} · {lab}", **{x: r[x] for x in NUM}})
    d = num(rows); n = 0; yt, yl, los, his = [], [], [], []
    for _, r in d.iterrows():
        c = T["magenta"] if "Fully" in r["label"] else (T["amber"] if "Age" in r["label"] else T["blue"])
        o, lo, hi = np.exp(r["estimate"]), np.exp(r["conf_low"]), np.exp(r["conf_high"])
        ax.plot([lo, hi], [-n, -n], color=c, lw=2.4, solid_capstyle="round", zorder=3)
        fs.glow_scatter(ax, [o], [-n], c, s=44)
        los.append(lo); his.append(hi); yt.append(-n); yl.append(r["label"]); n += 1
    ax.axvline(1.0, color=T["muted"], ls="--", lw=1.1)
    ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=7.0)
    ax.set_xscale("log"); ax.set_xlim(min(los) * 0.8, max(his) * 1.3)
    tk = [t for t in [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.4, 1.6] if min(los) * 0.8 < t < max(his) * 1.3]
    ax.xaxis.set_major_locator(FixedLocator(tk))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))
    ax.set_xlabel("Odds ratio (95% CI)"); ax.set_ylim(-n + 0.5, 0.5)
    fs.panel(ax, "a", "Arthritis by UA quartile", T)

    # (b) hyperuricaemia ladder
    ax = fig.add_subplot(gs[0, 1])
    rows = []
    for k, lab, _ in M:
        for r in main["main_models"][k]:
            if r["term"] == "hyperuricemia":
                rows.append({"label": lab, **{x: r[x] for x in NUM}})
    d = num(rows).drop_duplicates("label", keep="last"); n = 0; yt, yl, los, his = [], [], [], []
    for _, r in d.iterrows():
        c = {"Crude": T["blue"], "Age, sex, race": T["amber"], "Fully adjusted": T["magenta"]}[r["label"]]
        o, lo, hi = np.exp(r["estimate"]), np.exp(r["conf_low"]), np.exp(r["conf_high"])
        ax.plot([lo, hi], [-n, -n], color=c, lw=3.0, solid_capstyle="round", zorder=3)
        fs.glow_scatter(ax, [o], [-n], c, s=56)
        ax.text(hi * 1.07, -n, f"{o:.2f}", fontsize=8.0, color=T["muted"], va="center")
        los.append(lo); his.append(hi); yt.append(-n); yl.append(r["label"]); n += 1
    ax.axvline(1.0, color=T["muted"], ls="--", lw=1.1)
    ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8.2)
    ax.set_xscale("log"); ax.set_xlim(min(los) * 0.82, max(his) * 1.35)
    tk = [t for t in [0.8, 0.9, 1.0, 1.1, 1.2, 1.4, 1.6, 1.8] if min(los) * 0.82 < t < max(his) * 1.35]
    ax.xaxis.set_major_locator(FixedLocator(tk))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))
    ax.set_xlabel("Odds ratio (95% CI)"); ax.set_ylim(-n + 0.6, 0.6)
    ax.text(0.03, 0.06, "hyperuricaemia", transform=ax.transAxes, fontsize=7.8, color=T["muted"])
    fs.panel(ax, "b", "Adjustment ladder", T)

    # (c)(d)(e) splines with rug
    for fn, ylab, col, letter, title, nonlin, slot, yticks in [
            ("rcs_arthritis_curve.csv", "Odds ratio for arthritis", T["magenta"], "c",
             "Arthritis dose-response", "P non-linearity = 0.40", gs[0, 2], [0.6, 0.8, 1.0, 1.2, 1.4]),
            ("rcs_bmd_curve.csv", "Δ femoral-neck BMD (g/cm²)", T["lime"], "d",
             "Bone density dose-response", "P non-linearity = 0.23", gs[0, 3],
             [-0.02, -0.01, 0.00, 0.01]),
            ("rcs_fracture_curve.csv", "Odds ratio for fracture", T["amber"], "e",
             "Fracture dose-response", "P non-linearity = 0.65", gs[1, 0], [0.8, 0.9, 1.0])]:
        ax = fig.add_subplot(slot)
        c1 = pd.read_csv(os.path.join(RES, fn))
        ref = 1.0 if "bmd" not in fn else 0.0
        ax.axhline(ref, color=T["muted"], ls="--", lw=1.1)
        ax.fill_between(c1["ua"], c1["lo"], c1["hi"], color=col, alpha=0.18)
        ycol = "diff" if "bmd" in fn else "or"
        fs.glow_line(ax, c1["ua"], c1[ycol], col, lw=2.5)
        rug = df["ua"].sample(600, random_state=5)
        ax.plot(rug, np.full(len(rug), ref - (0.004 if "bmd" in fn else 0.10)), "|",
                color=T["muted"], ms=4, alpha=0.30, zorder=2)
        ax.set_xlabel("Serum uric acid (mg/dL)"); ax.set_ylabel(ylab)
        if yticks:
            ax.set_yticks(yticks)
        lo_, hi_ = ax.get_ylim()
        ax.set_ylim(lo_, hi_ + 0.085 * (hi_ - lo_))
        ax.text(0.035, 0.985, nonlin, transform=ax.transAxes, fontsize=7.6,
                color=T["text"], va="top")
        fs.panel(ax, letter, title, T)

    # (f) WHO T-score categories by quartile
    ax = fig.add_subplot(gs[1, 1])
    wqdf = pd.read_csv(os.path.join(RES, "who_by_quartile.csv"))
    x = np.arange(4); w = 0.36
    ax.bar(x - w / 2, wqdf["osteopenia"], width=w * 0.92, color=T["amber"], alpha=0.95,
           label="Osteopenia (T −1 to −2.5)", zorder=3)
    ax.bar(x + w / 2, wqdf["osteoporosis"], width=w * 0.92, color=T["magenta"], alpha=0.95,
           label="Osteoporosis (T ≤ −2.5)", zorder=3)
    for xi, (a_, b_) in zip(x, zip(wqdf["osteopenia"], wqdf["osteoporosis"])):
        ax.text(xi - w / 2, a_ + 1.2, f"{a_:.1f}", ha="center", fontsize=7.0, color=T["text"])
        ax.text(xi + w / 2, b_ + 1.2, f"{b_:.1f}", ha="center", fontsize=7.0, color=T["text"])
    ax.set_xticks(x); ax.set_xticklabels(["Q1", "Q2", "Q3", "Q4"], fontsize=8.4)
    ax.set_ylabel("Prevalence (%)"); ax.set_ylim(0, 58)
    ax.set_yticks([0, 20, 40])
    ax.legend(fontsize=6.8, loc="upper left", bbox_to_anchor=(0.01, 0.98))
    ax.text(0.99, 0.97, "Q4 vs Q1 osteopenia\nOR 0.77 (P = 0.002)", transform=ax.transAxes,
            fontsize=7.0, color=T["magenta"], fontweight="bold", ha="right", va="top")
    fs.panel(ax, "f", "WHO T-score categories by UA quartile", T)

    # (g) subgroup forest
    ax = fig.add_subplot(gs[1, 2])
    sg = pd.read_csv(os.path.join(RES, "subgroups.csv"))
    y = np.arange(len(sg))[::-1]
    for yi, (_, r) in zip(y, sg.iterrows()):
        c = T["magenta"] if r["p"] < 0.05 else T["muted"]
        ax.plot([r["lo"], r["hi"]], [yi, yi], color=c, lw=2.0, solid_capstyle="round", zorder=3)
        fs.glow_scatter(ax, [r["or"]], [yi], c, s=34)
    ax.axvline(1.0, color=T["blue"], ls="--", lw=1.2)
    ax.set_yticks(y); ax.set_yticklabels(sg["subgroup"], fontsize=7.2)
    ax.set_xscale("log"); ax.set_xlim(0.82, 1.12)
    ax.xaxis.set_major_locator(FixedLocator([0.85, 0.9, 0.95, 1.0, 1.05, 1.1]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))
    ax.set_xlabel("OR per 1 mg/dL (95% CI)"); ax.set_ylim(-0.8, len(sg) - 0.2)
    fs.panel(ax, "g", "Subgroup analyses", T)

    # (h) Sankey mediation
    ax = fig.add_subplot(gs[1, 3]); ax.axis("off"); ax.grid(False)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10)
    med = pd.read_csv(os.path.join(RES, "mediation.csv"))
    prop = {r["mediator"]: r["prop_mediated"] for _, r in med.iterrows()}
    ax.add_patch(FancyBboxPatch((0.15, 3.4), 1.5, 3.2, boxstyle="round,pad=0,rounding_size=0.25",
                 fc=T["cyan"], alpha=0.20, ec=T["cyan"], lw=1.6, zorder=4))
    ax.text(0.9, 5.0, "Serum\nuric acid", ha="center", va="center", fontsize=7.6,
            fontweight="bold", color=T["text"], zorder=6)
    mids = [("BMI / waist\n≈100%", T["amber"], 8.4, "BMI"), ("hs-CRP\n8.6%", T["violet"], 6.9, "hs-CRP"),
            ("SII / NLR\n≈3%", T["blue"], 5.4, "SII"), ("eGFR / albumin\n≈0%", T["teal"], 3.9, "eGFR")]
    for lbl, c, yy, key in mids:
        ax.add_patch(FancyBboxPatch((4.0, yy - 0.60), 2.1, 1.20,
                     boxstyle="round,pad=0,rounding_size=0.18", fc=c, alpha=0.18, ec=c, lw=1.5, zorder=4))
        ax.text(5.05, yy, lbl, ha="center", va="center", fontsize=6.6, color=T["text"], zorder=6)
        w_ = 0.34 + 0.86 * min(abs(prop.get(key, 0)) / 1.05, 1.0)
        ribbon(ax, 1.65, 5.0 - w_ / 2, 5.0 + w_ / 2, 4.0, yy - w_ / 2, yy + w_ / 2, c, alpha=0.32)
    ax.add_patch(FancyBboxPatch((8.2, 3.4), 1.6, 3.2, boxstyle="round,pad=0,rounding_size=0.25",
                 fc=T["magenta"], alpha=0.20, ec=T["magenta"], lw=1.6, zorder=4))
    ax.text(9.0, 5.0, "Arthritis", ha="center", va="center", fontsize=8.0, fontweight="bold",
            color=T["text"], zorder=6)
    for lbl, c, yy, key in mids:
        w_ = 0.34 + 0.86 * min(abs(prop.get(key, 0)) / 1.05, 1.0)
        ribbon(ax, 6.1, yy - w_ / 2, yy + w_ / 2, 8.2, 5.0 - w_ / 2, 5.0 + w_ / 2, c, alpha=0.32)
    ax.plot([0.9, 0.9, 9.0, 9.0], [3.40, 1.55, 1.55, 3.12], color=T["muted"],
            lw=13, alpha=0.32, solid_joinstyle="round", solid_capstyle="butt",
            zorder=2)
    ax.add_patch(Polygon([(9.0, 3.46), (8.83, 3.12), (9.17, 3.12)], closed=True,
                 fc=T["muted"], alpha=0.45, ec="none", zorder=2))
    ax.text(4.95, 1.55, "direct effect ≈ 0", ha="center", va="center", fontsize=6.8,
            color=T["text"], style="italic", zorder=6)
    fs.panel(ax, "h", "Mediation pathways", T, dx=-0.02, dy=1.02)
    fs.save(fig, os.path.join(OUT, "Figure3_associations.png"), T)


fig2(); fig3()
print("Figures 2-3 written")
