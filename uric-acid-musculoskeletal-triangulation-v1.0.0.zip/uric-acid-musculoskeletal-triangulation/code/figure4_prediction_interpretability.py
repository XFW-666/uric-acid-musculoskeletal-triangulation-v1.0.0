"""Figure 4: prediction of arthritis and multi-method interpretability.

Input:  results/oof_preds.csv, results/roc_*.csv, results/calibration.csv,
        results/dca.csv, results/ml_results.json, results/perm_importance.csv,
        results/ebm_shape_*.csv, results/ale_*.csv, results/ice_ua*.csv,
        results/pdp_ua_bmi.npy
Output: figures/Figure4_prediction.png
"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from sklearn.metrics import roc_auc_score
import figstyle as fs

T = fs.VIVID
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results"); OUT = os.path.join(ROOT, "figures")
fs.apply(T)
fig = plt.figure(figsize=(17.4, 13.6))
gs = fig.add_gridspec(3, 3, hspace=0.46, wspace=0.30, top=0.915, bottom=0.05,
                      left=0.055, right=0.98)
fig.suptitle("Prediction of arthritis and multi-method interpretability: uric acid carries "
             "little independent information", fontsize=14.5, fontweight="bold",
             color=T["text"], y=0.972)
oof = pd.read_csv(os.path.join(RES, "oof_preds.csv"))
yv = oof["y"].to_numpy()
models = [c for c in oof.columns if c != "y"]
COL = [T["blue"], T["magenta"], T["amber"], T["violet"], T["teal"]]
ml = json.load(open(os.path.join(RES, "ml_results.json")))

# (a) ROC
ax = fig.add_subplot(gs[0, 0])
for m, c in zip(models, COL):
    d = pd.read_csv(os.path.join(RES, f"roc_{m.replace(' ', '_')}.csv"))
    fs.glow_line(ax, d["fpr"], d["tpr"], c, lw=2.0, label=f"{m} ({roc_auc_score(yv, oof[m]):.3f})")
ax.plot([0, 1], [0, 1], color=T["muted"], ls="--", lw=1.0)
ax.set_xlabel("1 − specificity"); ax.set_ylabel("Sensitivity")
ax.legend(fontsize=6.6, loc="lower right")
fs.panel(ax, "a", "ROC curves (5-fold CV)", T)

# (b) calibration
ax = fig.add_subplot(gs[0, 1])
cal = pd.read_csv(os.path.join(RES, "calibration.csv"))
ax.plot([0, 1], [0, 1], color=T["muted"], ls="--", lw=1.0)
fs.glow_line(ax, cal["pred"], cal["obs"], T["lime"], lw=2.4, marker="o", ms=6)
ax.set_xlabel("Predicted probability"); ax.set_ylabel("Observed probability")
fs.panel(ax, "b", "Calibration", T)

# (c) DCA
ax = fig.add_subplot(gs[0, 2])
dc = pd.read_csv(os.path.join(RES, "dca.csv"))
fs.glow_line(ax, dc["threshold"], dc["model"], T["cyan"], lw=2.4, label="Model")
ax.plot(dc["threshold"], dc["treat_all"], color=T["muted"], ls="--", lw=1.2, label="Treat all")
ax.plot(dc["threshold"], dc["treat_none"], color=T["magenta"], ls=":", lw=1.2, label="Treat none")
ax.set_xlabel("Threshold probability"); ax.set_ylabel("Net benefit")
ax.set_ylim(-0.05, dc["treat_all"].max() * 1.05)
ax.legend(fontsize=7.2, loc="upper right")
fs.panel(ax, "c", "Decision-curve analysis", T)

# (d) radar chart across metrics
ax = fig.add_subplot(gs[1, 0], projection="polar")
metrics = ["auc", "pr_auc", "accuracy", "sensitivity", "specificity", "f1"]
mlab = ["AUC", "PR-AUC", "Accuracy", "Sensitivity", "Specificity", "F1"]
ang = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False)
ang = np.concatenate([ang, ang[:1]])
perf = ml["model_performance"]
for m, c in zip(models, COL):
    vals = [float(perf[m][k]) for k in metrics]
    vals = vals + vals[:1]
    ax.plot(ang, vals, color=c, lw=2.0, label=m, zorder=4)
    ax.fill(ang, vals, color=c, alpha=0.10, zorder=3)
ax.set_xticks(ang[:-1]); ax.set_xticklabels(mlab, fontsize=7.2)
ax.set_ylim(0.35, 0.92); ax.set_yticks([0.5, 0.7, 0.9])
ax.tick_params(axis="y", labelsize=6.2)
ax.set_facecolor(T["panel"]); ax.grid(color=T["grid"], lw=0.8)
ax.legend(fontsize=6.2, loc="upper right", bbox_to_anchor=(1.30, 1.16))
ax.text(0.5, -0.16, f"uric acid alone: AUC {float(ml['ua_only_auc']):.3f}",
        transform=ax.transAxes, ha="center", fontsize=7.6, color=T["magenta"], fontweight="bold")
fs.panel(ax, "d", "Multi-metric model profile", T, dx=-0.16, dy=1.10)

# (e) permutation importance
ax = fig.add_subplot(gs[1, 1])
pi = pd.read_csv(os.path.join(RES, "perm_importance.csv")).head(14).iloc[::-1]
cols = [T["magenta"] if f == "ua" else T["cyan"] for f in pi["feature"]]
ax.barh(np.arange(len(pi)), pi["importance"], color=cols, alpha=0.95, zorder=3)
ax.errorbar(pi["importance"], np.arange(len(pi)),
            xerr=[pi["importance"] - pi["lo"], pi["hi"] - pi["importance"]],
            fmt="none", ecolor=T["text"], elinewidth=1.0, capsize=2, zorder=4)
ax.set_yticks(np.arange(len(pi))); ax.set_yticklabels(pi["label"], fontsize=7.4)
ax.set_xlabel("ΔAUC on permutation")
ax.text(0.42, 0.06, "UA ranks 12th of 24", transform=ax.transAxes, fontsize=8.0,
        color=T["magenta"], fontweight="bold")
fs.panel(ax, "e", "Permutation importance (95% CI)", T)

# (f) EBM shape functions
ax = fig.add_subplot(gs[1, 2])
for feat, c, nm in [("ua", T["magenta"], "Uric acid"), ("age", T["blue"], "Age"),
                    ("bmi", T["amber"], "BMI")]:
    p = os.path.join(RES, f"ebm_shape_{feat}.csv")
    if os.path.exists(p):
        d = pd.read_csv(p)
        d = d[(d["x"] >= d["x"].quantile(0.01)) & (d["x"] <= d["x"].quantile(0.99))]
        z = d["score"] - d["score"].mean()
        xz = (d["x"] - d["x"].min()) / (d["x"].max() - d["x"].min())
        fs.glow_line(ax, xz, z, c, lw=2.2, label=nm)
ax.axhline(0, color=T["muted"], ls="--", lw=1.0)
ax.set_xlabel("Feature value (min–max scaled)"); ax.set_ylabel("Centred EBM score (log-odds)")
ax.legend(fontsize=7.6)
_shp = [pd.read_csv(os.path.join(RES, f"ebm_shape_{f}.csv"))
        for f in ["ua", "age", "bmi"] if os.path.exists(os.path.join(RES, f"ebm_shape_{f}.csv"))]
if _shp:
    ax.set_ylim(min(d["score"].min() for d in _shp) - 0.25,
                max(d["score"].max() for d in _shp) + 0.25)
fs.panel(ax, "f", "EBM shape functions (intrinsic)", T)

# (g) ALE
ax = fig.add_subplot(gs[2, 0])
for feat, c, nm in [("ua", T["magenta"], "Uric acid"), ("bmi", T["amber"], "BMI"),
                    ("crp", T["violet"], "hs-CRP"), ("waist", T["teal"], "Waist")]:
    p = os.path.join(RES, f"ale_{feat}.csv")
    if os.path.exists(p):
        d = pd.read_csv(p)
        fs.glow_line(ax, d["x"], d["ale"], c, lw=2.2, label=nm)
ax.axhline(0, color=T["muted"], ls="--", lw=1.0)
ax.set_xlabel("Feature value"); ax.set_ylabel("ALE (change in predicted probability)")
ax.legend(fontsize=7.4)
fs.panel(ax, "g", "Accumulated local effects", T)

# (h) ICE
ax = fig.add_subplot(gs[2, 1])
ice = pd.read_csv(os.path.join(RES, "ice_ua.csv"))
grid = pd.read_csv(os.path.join(RES, "ice_ua_grid.csv"))["ua"].to_numpy()
for i in range(min(120, len(ice))):
    ax.plot(grid, ice.iloc[i].to_numpy(), color=T["cyan"], lw=0.5, alpha=0.16, zorder=2)
ax.plot(grid, ice.mean(axis=0).to_numpy(), color=T["magenta"], lw=2.8, zorder=4, label="Mean")
ax.set_xlabel("Serum uric acid (mg/dL)"); ax.set_ylabel("Predicted probability of arthritis")
ax.set_ylim(0, 1.06); ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.legend(fontsize=7.6)
fs.panel(ax, "h", "ICE curves for uric acid", T)

# (i) 2D partial dependence surface
ax = fig.add_subplot(gs[2, 2])
Z = np.load(os.path.join(RES, "pdp_ua_bmi.npy"))
ax_ = np.load(os.path.join(RES, "pdp_ua_bmi_axes.npz"))
g_ua, g_bmi = ax_["ua"], ax_["y"]
cs = ax.contourf(g_ua, g_bmi, Z, levels=18, cmap=fs.cmap(T, T["panel"], T["magenta"]))
cl = ax.contour(g_ua, g_bmi, Z, levels=8, colors="white", linewidths=0.7, alpha=0.65)
cb = fig.colorbar(cs, ax=ax, fraction=0.046, pad=0.03); cb.ax.tick_params(labelsize=7)

ax.set_xlabel("Serum uric acid (mg/dL)"); ax.set_ylabel("Body mass index (kg/m²)")
ax.text(0.012, 1.045, "BMI gradient dominates; UA gradient is flat",
        transform=ax.transAxes, fontsize=7.2, color=T["text"], va="bottom",
        fontweight="bold")
fs.panel(ax, "i", "2D partial dependence (UA × BMI; colour = P(arthritis))", T, pad=26)
fs.save(fig, os.path.join(OUT, "Figure4_prediction.png"), T)
print("Figure 4 written")
