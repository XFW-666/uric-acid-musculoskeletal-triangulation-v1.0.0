"""Figure 5 (genetics, drug safety, target evidence) and Figure 6 (cartilage
transcriptome).

Input:  results/mr_results.csv, results/mr_sensitivity.csv,
        results/mr_snp_level.csv, results/mr_loo_*.csv,
        results/opentargets_*.csv, results/faers_*.csv,
        results/geo_de_full.csv, results/geo_panel.csv,
        results/geo_signatures.csv
Output: figures/Figure5_cross_database.png, figures/Figure6_geo.png
"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, Circle
from matplotlib.ticker import FixedLocator, FuncFormatter
from scipy import stats
import matplotlib.patheffects as pe
from scipy.stats import gaussian_kde
import figstyle as fs

T = fs.VIVID
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data"); RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")
mr = pd.read_csv(os.path.join(RES, "mr_results.csv"))
snpl = pd.read_csv(os.path.join(RES, "mr_snp_level.csv"))
ot = pd.read_csv(os.path.join(RES, "opentargets_disease_targets.csv"))
faers = pd.read_csv(os.path.join(RES, "faers_disproportionality.csv"))
fam = pd.read_csv(os.path.join(RES, "faers_matched.csv"))
geo_panel = pd.read_csv(os.path.join(RES, "geo_panel.csv"))
geo_sig = pd.read_csv(os.path.join(RES, "geo_signatures.csv"))


# ============================== FIGURE 5 ==============================
def fig5():
    fs.apply(T)
    fig = plt.figure(figsize=(21.0, 10.6))
    gs = fig.add_gridspec(2, 4, hspace=0.46, wspace=0.34, top=0.885, bottom=0.075,
                          left=0.085, right=0.985)
    fig.suptitle("Cross-database triangulation: genetics, drug safety and target evidence",
                 fontsize=15, fontweight="bold", color=T["text"], y=0.965)
    ms = pd.read_csv(os.path.join(RES, "mr_sensitivity.csv"))
    lab = {"gout": "Gout (positive control)", "osteoarthritis": "Osteoarthritis",
           "knee_OA": "Knee osteoarthritis", "hip_OA": "Hip osteoarthritis",
           "osteoporosis": "Osteoporosis"}
    order = ["gout", "osteoarthritis", "knee_OA", "hip_OA", "osteoporosis"]

    # (a) MR forest (IVW)
    ax = fig.add_subplot(gs[0, 0])
    d = mr.set_index("outcome").loc[[o for o in order if o in mr["outcome"].values]]
    y = np.arange(len(d))[::-1]
    for yi, (nm, r) in zip(y, d.iterrows()):
        sig = r["ivw_p"] < 0.05
        c = T["magenta"] if sig else T["muted"]
        ax.plot([r["ivw_lo"], r["ivw_hi"]], [yi, yi], color=c, lw=2.6, solid_capstyle="round", zorder=3)
        fs.glow_scatter(ax, [r["ivw_or"]], [yi], c, s=52)
        ax.text(r["ivw_hi"] * 1.08, yi, f"{r['ivw_or']:.2f} ({r['ivw_lo']:.2f}–{r['ivw_hi']:.2f})",
                fontsize=6.8, color=T["muted"], va="center", zorder=5,
                bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="none", alpha=0.85))
    ax.axvline(1.0, color=T["blue"], ls="--", lw=1.3)
    ax.set_yticks(y); ax.set_yticklabels([lab[i] for i in d.index], fontsize=7.8)
    ax.set_xscale("log"); ax.set_xlim(0.35, 11.0)
    ax.xaxis.set_major_locator(FixedLocator([0.4, 0.6, 1.0, 2, 4, 6]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))
    ax.set_xlabel("OR per genetically predicted uric acid"); ax.set_ylim(-0.7, len(d) - 0.3)
    fs.panel(ax, "a", "Mendelian randomisation (FinnGen R10)", T)

    # (b) leave-one-out
    ax = fig.add_subplot(gs[0, 1])
    show = ["gout", "osteoarthritis", "osteoporosis"]
    cols = {"gout": T["magenta"], "osteoarthritis": T["cyan"], "osteoporosis": T["lime"]}
    for i, nm in enumerate(show):
        pth = os.path.join(RES, f"mr_loo_{nm}.csv")
        if not os.path.exists(pth):
            continue
        d2 = pd.read_csv(pth)
        yy = np.full(len(d2), i) + np.linspace(-0.26, 0.26, len(d2))
        ax.scatter(d2["or"], yy, s=20, color=cols[nm], alpha=0.85, edgecolors="none", zorder=3)
        full = mr[mr["outcome"] == nm]
        if len(full):
            ax.plot([full["ivw_or"].iloc[0]] * 2, [i - 0.34, i + 0.34], color=T["text"],
                    lw=1.6, zorder=5)
    ax.axvline(1.0, color=T["blue"], ls="--", lw=1.2)
    ax.set_yticks(range(len(show)))
    ax.set_yticklabels(["Gout", "Osteoarthritis", "Osteoporosis"], fontsize=7.8)
    ax.set_xscale("log"); ax.set_xlim(0.35, 8)
    ax.xaxis.set_major_locator(FixedLocator([0.4, 0.6, 1.0, 2, 4, 6]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))
    ax.set_xlabel("Leave-one-out OR (each point = one SNP removed)")
    ax.set_ylim(-0.7, len(show) - 0.3)
    ax.text(0.03, 0.06, "vertical bar = full IVW estimate", transform=ax.transAxes,
            fontsize=6.6, color=T["muted"], style="italic", zorder=5,
            bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.88))
    fs.panel(ax, "b", "Leave-one-out sensitivity", T)

    # (c) Manhattan-style instrument landscape
    ax = fig.add_subplot(gs[0, 2])
    d = snpl.copy()
    d["chr"] = pd.to_numeric(d["chr"], errors="coerce")
    d = d.dropna(subset=["chr"]); d = d[d["chr"].between(1, 22)]
    d["chr"] = d["chr"].astype(int)
    offs = {}; cum = 0
    for c in range(1, 23):
        offs[c] = cum
        cum += 250_000_000 if c < 22 else 60_000_000
    d["gpos"] = d["chr"].map(offs) + d["pos"]
    for nm, c in [("gout", T["magenta"]), ("osteoarthritis", T["cyan"])]:
        s2 = d[d["outcome"] == nm]
        if not len(s2):
            continue
        z = s2["beta_out"] / s2["se_out"]
        yv = -np.log10(np.clip(2 * (1 - stats.norm.cdf(abs(z))), 1e-300, 1))
        ax.scatter(s2["gpos"], yv, s=26, color=c, alpha=0.75, edgecolors="none",
                   label=nm.replace("_", " "), zorder=3)
    ax.axhline(-np.log10(0.05), color=T["muted"], ls="--", lw=1.0)
    ax.set_xticks([offs[c] + 1e8 for c in range(1, 23, 4)])
    ax.set_xticklabels([str(c) for c in range(1, 23, 4)], fontsize=6.2)
    ax.set_xlabel("Chromosome"); ax.set_ylabel("−log₁₀ P (outcome association)")
    ax.legend(fontsize=7.0, loc="upper left")
    fs.panel(ax, "c", "Instrument landscape across the genome", T)

    # (d) estimator comparison (three key outcomes x two estimators)
    ax = fig.add_subplot(gs[0, 3])
    short = {"gout": "Gout", "osteoarthritis": "OA", "osteoporosis": "Bone"}
    rows = []
    for nm in ["gout", "osteoarthritis", "osteoporosis"]:
        r = ms[ms["outcome"] == nm]
        if not len(r):
            continue
        r = r.iloc[0]
        pri = mr[mr["outcome"] == nm]
        if len(pri):
            pri = pri.iloc[0]
            rows.append((nm, "IVW", pri["ivw_or"], pri["ivw_lo"], pri["ivw_hi"], T["blue"]))
        else:
            rows.append((nm, "IVW", r["ivw_or"], r["ivw_lo"], r["ivw_hi"], T["blue"]))
        if np.isfinite(r["wmode_or"]):
            rows.append((nm, "WM", r["wmode_or"], r["wmode_lo"], r["wmode_hi"], T["violet"]))
    yt, yl = [], []
    for i, (nm, est, o, lo, hi, c) in enumerate(rows):
        ax.plot([lo, hi], [-i, -i], color=c, lw=2.2, solid_capstyle="round", zorder=3)
        fs.glow_scatter(ax, [o], [-i], c, s=34)
        yt.append(-i); yl.append(f"{short.get(nm, nm)} · {est}")
    ax.axvline(1.0, color=T["blue"], ls="--", lw=1.2)
    ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=7.6)
    ax.set_xscale("log"); ax.set_xlim(0.25, 16)
    ax.xaxis.set_major_locator(FixedLocator([0.3, 0.5, 1.0, 2, 4, 8]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))
    ax.set_xlabel("OR (95% CI)"); ax.set_ylim(-len(rows) + 0.4, 0.6)
    ax.text(0.03, 0.04, "IVW = inverse-variance weighted; WM = weighted mode",
            transform=ax.transAxes, fontsize=6.2, color=T["muted"], style="italic",
            zorder=5, bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.88))
    fs.panel(ax, "d", "Estimator agreement", T)

    # (e) Open Targets bubble matrix
    ax = fig.add_subplot(gs[1, 0])
    genes = ["SLC22A12", "ABCG2", "XDH", "SLC16A9", "SLC2A9", "GCKR", "PDZK1", "NLRP3", "IL1B"]
    genes = [g for g in genes if g in set(ot["target"])]
    diseases = [c for c in ["gout", "osteoarthritis", "osteoporosis"] if c in set(ot["disease"])]
    piv = ot.pivot_table(index="target", columns="disease", values="overall", aggfunc="max")
    gen = ot.pivot_table(index="target", columns="disease", values="genetic", aggfunc="max")
    for j, dn in enumerate(diseases):
        for i, g in enumerate(genes):
            v = piv.loc[g, dn] if (g in piv.index and dn in piv.columns) else np.nan
            gv = gen.loc[g, dn] if (g in gen.index and dn in gen.columns) else np.nan
            if not np.isfinite(v):
                continue
            size = 26 + 820 * max(0.0, (v - 0.2)) / 0.8
            col = fs.cmap(T, T["panel_edge"], T["magenta"])(0.0 if not np.isfinite(gv) else min(gv, 1.0))
            ax.scatter(j, i, s=size, color=col, alpha=0.90, edgecolors=T["panel_edge"],
                       linewidths=0.8, zorder=3)
            if np.isfinite(gv):
                ax.text(j, i, f"{gv:.2f}", ha="center", va="center", fontsize=5.4,
                        color=T["text"], zorder=5, fontweight="bold",
                        path_effects=[pe.withStroke(linewidth=1.3, foreground="white")])
    ax.set_xticks(range(len(diseases))); ax.set_xticklabels(diseases, fontsize=7.6)
    ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes, fontsize=7.0)
    ax.set_xlim(-0.6, len(diseases) - 0.4); ax.set_ylim(-0.6, len(genes) - 0.4)
    ax.set_xlabel("size = overall score · colour = genetic score")
    ax.grid(True, alpha=0.35)
    fs.panel(ax, "e", "Open Targets target–disease evidence", T)

    # (f) FAERS heatmap
    ax = fig.add_subplot(gs[1, 1])
    ev = ["RIB FRACTURE", "HIP FRACTURE", "SPINAL FRACTURE", "OSTEOPOROSIS",
          "OSTEOARTHRITIS", "BONE PAIN", "FALL", "GOUT"]
    drugs = ["allopurinol", "febuxostat", "colchicine"]
    Mx = np.full((len(drugs), len(ev)), np.nan)
    for i, dr in enumerate(drugs):
        for j, e in enumerate(ev):
            r = faers[(faers["drug"] == dr) & (faers["event"] == e)]
            if len(r):
                Mx[i, j] = np.log2(r["ror"].iloc[0])
    im = ax.imshow(Mx, cmap=fs.cmap(T, T["blue"], T["magenta"]), vmin=-2, vmax=5)
    ax.set_xticks(range(len(ev))); ax.set_xticklabels([e.title() for e in ev], rotation=45,
                                                      ha="right", fontsize=6.2)
    ax.set_yticks(range(len(drugs))); ax.set_yticklabels(drugs, fontsize=7.4)
    ax.grid(False)
    for i in range(len(drugs)):
        for j in range(len(ev)):
            if np.isfinite(Mx[i, j]):
                ax.text(j, i, f"{2**Mx[i, j]:.1f}", ha="center", va="center", fontsize=5.8,
                        color="white" if abs(Mx[i, j]) > 2 else T["text"])
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03); cb.ax.tick_params(labelsize=6.5)
    cb.set_label("log₂ ROR", fontsize=6.8)
    fs.panel(ax, "f", "FAERS reporting odds ratios", T)

    # (g) FAERS indication-matched
    ax = fig.add_subplot(gs[1, 2])
    d = fam.copy()
    y = np.arange(len(d))[::-1]
    for yi, (_, r) in zip(y, d.iterrows()):
        c = T["magenta"] if (r["lo"] > 1 or r["hi"] < 1) else T["muted"]
        ax.plot([r["lo"], r["hi"]], [yi, yi], color=c, lw=2.2, solid_capstyle="round", zorder=3)
        fs.glow_scatter(ax, [r["ror"]], [yi], c, s=36)
    ax.axvline(1.0, color=T["blue"], ls="--", lw=1.2)
    ax.set_yticks(y); ax.set_yticklabels([e.title() for e in d["event"]], fontsize=6.8)
    ax.set_xscale("log"); ax.set_xlim(0.1, 3.2)
    ax.xaxis.set_major_locator(FixedLocator([0.1, 0.2, 0.5, 1, 2, 3]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))
    ax.set_xlabel("ROR: febuxostat vs allopurinol"); ax.set_ylim(-0.7, len(d) - 0.3)
    fs.panel(ax, "g", "Indication-matched comparison", T)

    # (h) evidence matrix
    ax = fig.add_subplot(gs[1, 3]); ax.axis("off"); ax.grid(False)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10)
    ax.text(0.0, 9.9, "h", fontsize=12.5, fontweight="bold", color=T["text"], va="top")
    ax.text(1.0, 9.9, "Convergent evidence matrix", fontsize=9.2, fontweight="bold",
            color=T["text"], va="top")
    rows = [("NHANES", "≈100% mediated\nby adiposity", "+ BMD, + T-score", T["cyan"]),
            ("NHIS", "trend flat to 2024", "—", T["teal"]),
            ("MR (FinnGen)", "OR 1.00 (null)", "OR 0.63 (protective)", T["magenta"]),
            ("Open Targets", "no genetic signal", "no genetic signal", T["blue"]),
            ("FAERS", "signal = indication", "signal = indication", T["orange"]),
            ("GEO cartilage", "matrix degradation", "—", T["lime"])]
    ax.text(4.30, 8.80, "JOINT", ha="center", fontsize=7.0, fontweight="bold", color=T["amber"])
    ax.text(7.45, 8.80, "BONE", ha="center", fontsize=7.0, fontweight="bold", color=T["lime"])
    y = 8.00
    for name, joint, bone, c in rows:
        ax.add_patch(plt.Rectangle((0.0, y - 0.72), 0.20, 1.02, fc=c, ec="none", alpha=0.95))
        ax.text(0.38, y - 0.20, name, fontsize=7.2, fontweight="bold", color=c, va="center")
        ax.add_patch(FancyBboxPatch((3.30, y - 0.68), 2.00, 0.90,
                     boxstyle="round,pad=0,rounding_size=0.10", fc=c, alpha=0.13, ec=c, lw=1.0))
        ax.text(4.30, y - 0.23, joint, ha="center", va="center", fontsize=6.0, color=T["text"])
        ax.add_patch(FancyBboxPatch((6.45, y - 0.68), 2.00, 0.90,
                     boxstyle="round,pad=0,rounding_size=0.10", fc=c, alpha=0.13, ec=c, lw=1.0))
        ax.text(7.45, y - 0.23, bone, ha="center", va="center", fontsize=6.0, color=T["text"])
        y -= 1.22
    fs.save(fig, os.path.join(OUT, "Figure5_cross_database.png"), T)


# ============================== FIGURE 6 ==============================
def fig6():
    fs.apply(T)
    fig = plt.figure(figsize=(17.4, 5.9))
    gs = fig.add_gridspec(1, 3, wspace=0.28, top=0.80, bottom=0.13, left=0.055, right=0.98)
    fig.suptitle("Cartilage transcriptome (GEO GSE114007): matrix degradation without "
                 "urate-transporter or inflammasome activation",
                 fontsize=14, fontweight="bold", color=T["text"], y=0.945)

    # (a) volcano plot
    ax = fig.add_subplot(gs[0, 0])
    de = pd.read_csv(os.path.join(RES, "geo_de_full.csv")).dropna(subset=["log2FC", "fdr"])
    de["nl"] = -np.log10(np.clip(de["fdr"], 1e-300, 1))
    cats = {g: c for c, gl in {
        "Urate pathway": ["SLC22A12", "SLC2A9", "ABCG2", "XDH", "SLC17A1", "SLC16A9", "PDZK1", "GCKR"],
        "Inflammasome": ["NLRP3", "IL1B", "CASP1", "PYCARD", "IL18", "TLR4", "MYD88", "NFKB1"],
        "Cartilage matrix": ["MMP13", "ADAMTS5", "COL2A1", "ACAN", "COL1A1", "COL10A1", "MMP3", "SOX9"],
        "Bone remodelling": ["TNFSF11", "TNFRSF11B", "SPP1", "RUNX2", "BGLAP", "ALPL", "CTSK", "ACP5"],
        "Oxidative stress": ["SOD1", "SOD2", "CAT", "GPX1", "NQO1", "HMOX1", "NFE2L2", "NOX4"],
    }.items() for g in gl}
    cmapc = {"Urate pathway": T["violet"], "Inflammasome": T["blue"],
             "Cartilage matrix": T["magenta"], "Bone remodelling": T["lime"],
             "Oxidative stress": T["amber"]}
    ax.scatter(de["log2FC"], de["nl"], s=4, color=T["panel_edge"], alpha=0.55, edgecolors="none", zorder=2)
    sig = de[(de["fdr"] < 0.05) & (de["log2FC"].abs() > 0.4)]
    for cat, c in cmapc.items():
        s = sig[sig["gene"].map(cats) == cat]
        if len(s):
            ax.scatter(s["log2FC"], s["nl"], s=44, color=c, alpha=0.95, edgecolors="white",
                       linewidths=0.5, zorder=4, label=cat)
    placed = []
    for _, r in sig.reindex(sig["nl"].sort_values(ascending=False).index).iterrows():
        if len(placed) >= 7:
            break
        x, y = r["log2FC"], r["nl"]
        if any(abs(x - px) < 0.22 and abs(y - py) < 2.0 for px, py in placed):
            continue
        side = 1 if x >= 0 else -1
        ax.scatter([x], [y], s=30, color=T["text"], edgecolors="white",
                   linewidths=0.6, zorder=5)
        ax.annotate(r["gene"], (x, y), fontsize=6.2, color=T["text"],
                    xytext=(6 * side, 3), textcoords="offset points",
                    ha="left" if side > 0 else "right", zorder=6)
        placed.append((x, y))
    ax.axhline(-np.log10(0.05), color=T["muted"], ls="--", lw=1.0)
    ax.axvline(0, color=T["muted"], ls=":", lw=1.0)
    ax.set_xlabel("log₂ fold change (OA vs normal)"); ax.set_ylabel("−log₁₀ FDR")
    from matplotlib.lines import Line2D as _L2
    _h, _l = ax.get_legend_handles_labels()
    _h.append(_L2([], [], marker="o", ls="", color=T["text"], label="Top DE genes"))
    ax.legend(handles=_h, fontsize=6.2, loc="upper left", ncol=1)
    fs.panel(ax, "a", "Volcano plot of the cartilage transcriptome", T)

    # (b) raincloud plot of signature scores
    ax = fig.add_subplot(gs[0, 1])
    sig_names = ["Urate pathway", "Inflammasome", "Matrix degradation"]
    catmap = {"Urate pathway": "Urate pathway", "Inflammasome": "Inflammasome / IL-1",
              "Matrix degradation": "Cartilage matrix"}
    oa_m = pd.read_csv(os.path.join(DATA, "geo", "GSE114007_OA_normalized.counts.txt.gz"),
                       sep="\t", index_col=0)
    nm_m = pd.read_csv(os.path.join(DATA, "geo", "GSE114007_normal_normalized.counts.txt.gz"),
                       sep="\t", index_col=0)
    def panel_genes(cat):
        return list({g: c for c, gl in {
            "Urate pathway": ["SLC22A12", "SLC2A9", "ABCG2", "XDH", "SLC17A1", "SLC16A9", "PDZK1", "GCKR"],
            "Inflammasome / IL-1": ["NLRP3", "IL1B", "CASP1", "PYCARD", "IL18", "TLR4", "MYD88", "NFKB1"],
            "Cartilage matrix": ["MMP13", "ADAMTS5", "COL2A1", "ACAN", "COL1A1", "COL10A1", "MMP3", "SOX9"],
        }.items() for g in gl if g in oa_m.index})
    for i, (nm, cat) in enumerate(zip(sig_names, catmap.values())):
        gs_ = [g for g in panel_genes(cat)]
        if not gs_:
            continue
        a = np.log2(oa_m.loc[gs_] + 1).mean(axis=0).to_numpy()
        b = np.log2(nm_m.loc[gs_] + 1).mean(axis=0).to_numpy()
        for arr, off, c in [(b, -0.22, T["blue"]), (a, 0.22, T["magenta"])]:
            k = gaussian_kde(arr) if len(np.unique(arr)) > 1 else None
            if k is not None:
                xs = np.linspace(arr.min() - 0.3, arr.max() + 0.3, 200)
                yv = k(xs); yv = yv / yv.max() * 0.36
                ax.fill_between(xs, i + off, i + off + yv, color=c, alpha=0.55, zorder=3)
                ax.plot(xs, i + off + yv, color=c, lw=1.4, zorder=4)
            ax.scatter(arr, np.full(len(arr), i + off - 0.06) + np.random.RandomState(1).uniform(-0.035, 0.035, len(arr)),
                       s=13, color=c, alpha=0.85, edgecolors="none", zorder=5)
            bp = ax.boxplot([arr], positions=[i + off + 0.10], widths=0.10, vert=False,
                            patch_artist=True, showfliers=False, zorder=6)
            for p in bp["boxes"]:
                p.set_facecolor("white"); p.set_edgecolor(c); p.set_linewidth(1.3)
            for p in bp["medians"]:
                p.set_color(c); p.set_linewidth(1.8)
            for p in bp["whiskers"] + bp["caps"]:
                p.set_color(c); p.set_linewidth(1.0)
    ax.set_yticks(range(len(sig_names))); ax.set_yticklabels(sig_names, fontsize=8.2)
    ax.set_xlabel("Signature score (mean log₂ expression)")
    ax.set_ylim(-0.6, len(sig_names) - 0.35)
    from matplotlib.lines import Line2D
    ax.legend(handles=[Line2D([], [], marker="s", ls="", color=T["blue"], label="Normal"),
                       Line2D([], [], marker="s", ls="", color=T["magenta"], label="OA")],
              fontsize=7.4, loc="lower right")
    ax.text(0.02, 0.03, "*** P < 0.001 for matrix degradation; inflammasome n.s.",
            transform=ax.transAxes, fontsize=7.0, color=T["text"])
    fs.panel(ax, "b", "Raincloud plot of signature scores", T)

    # (c) clustered expression heatmap
    ax = fig.add_subplot(gs[0, 2])
    genes = [g for g in ["COL1A1", "COL10A1", "ADAMTS5", "COL2A1", "CTSK", "NQO1",
                         "GCKR", "SLC16A9", "HMOX1", "SOX9", "MMP3", "ACAN"] if g in oa_m.index]
    combined = pd.concat([nm_m.loc[genes], oa_m.loc[genes]], axis=1)
    lab = ["Normal"] * nm_m.shape[1] + ["OA"] * oa_m.shape[1]
    z = combined.sub(combined.mean(axis=1), axis=0).div(combined.std(axis=1).replace(0, 1), axis=0)
    order = np.argsort([0 if l == "Normal" else 1 for l in lab], kind="stable")
    z = z.iloc[:, order]
    im = ax.imshow(z.to_numpy(), cmap=fs.cmap(T, T["blue"], T["magenta"]), vmin=-2, vmax=2,
                   aspect="auto")
    ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes, fontsize=7.4)
    ax.set_xticks([]); ax.grid(False)
    n_norm = lab.count("Normal")
    ax.axvline(n_norm - 0.5, color=T["text"], lw=1.8)
    ax.text((n_norm - 1) / 2, len(genes) - 0.3, "Normal", ha="center", fontsize=7.6,
            color=T["blue"], fontweight="bold")
    ax.text(n_norm + (len(lab) - n_norm) / 2 - 0.5, len(genes) - 0.3, "OA", ha="center",
            fontsize=7.6, color=T["magenta"], fontweight="bold")
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03); cb.ax.tick_params(labelsize=7)
    
    ax.set_xlabel("Cartilage samples")
    fs.panel(ax, "c", "Clustered expression heatmap (row z-score)", T)
    fs.save(fig, os.path.join(OUT, "Figure6_geo.png"), T)


fig5(); fig6()
print("Figures 5-6 written")
