"""Record which candidate NHANES variable names exist in which file, by cycle.

Scans every downloaded .xpt file so that the era-specific renamings applied in
1999-2004 (biochemistry, haematology) are handled explicitly.

Input:  data/<cycle>/*.xpt
Output: data/variable_inventory.json
"""
import pandas as pd, os, json

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
CYCLES = ["1999-2000","2001-2002","2003-2004","2005-2006","2007-2008","2009-2010",
          "2011-2012","2013-2014","2015-2016","2017-2018","2017-2020","2021-2023"]

CONCEPTS = {
    "sex": ["RIAGENDR"], "age": ["RIDAGEYR"], "race": ["RIDRETH1","RIDRETH3"],
    "edu": ["DMDEDUC2"], "pir": ["INDFMPIR"], "preg": ["RIDEXPRG"],
    "bmi": ["BMXBMI"], "waist": ["BMXWAIST"], "height": ["BMXHT"], "weight": ["BMXWT"],
    "arthritis": ["MCQ160A"], "arthritis_type": ["MCQ195"],
    "gout": ["MCQ160N","MCQ160O","MCQ160M"], "osteo_selfrep": ["OSQ010A"],
    "osq_fx": ["OSQ010B"], "hip_fx": ["OSQ040","OSQ040AA"],
    "ua": ["LBXSUA"], "albumin": ["LBXSAL"], "alp": ["LBXSAPSI","LBXSAP"],
    "calcium": ["LBXSCA"], "phosphorus": ["LBXSPH","LBDSPH"], "creatinine": ["LBXSCR","LBDSCR"],
    "glucose": ["LBXSGL","LBDSGL"], "trigly": ["LBXSTR","LBDSTR"], "chol": ["LBXSCH","LBDSCH"],
    "totprot": ["LBXSTP","LBDSTP"], "bun": ["LBXSBU","LBDSBU"],
    "wbc": ["LBXWBCSI"], "neut_pct": ["LBXNEPCT"], "lymph_pct": ["LBXLYPCT"],
    "neut_no": ["LBDNENO"], "lymph_no": ["LBDLYMNO"], "plt": ["LBXPLTSI"], "hgb": ["LBXHGB"],
    "crp": ["LBXCRP"], "smoke100": ["SMQ020"], "smoke_now": ["SMQ040"],
    "alc_ever": ["ALQ101","ALQ100","ALQ110","ALQ111"], "alc_freq": ["ALQ120Q","ALQ121"],
    "alc_drinks": ["ALQ130"], "diabetes": ["DIQ010"], "hypertension": ["BPQ020"],
    "hbp_med": ["BPQ040A","BPQ050A"], "menopause": ["RHQ060"], "sleep_hours": ["SLD010H"],
    "energy": ["DR1TKCAL"], "diet_ca": ["DR1TCALC"], "diet_prot": ["DR1TPROT"],
    "pa_vig_leisure": ["PAQ605","PAQ650","PAQ500"], "pa_mod_leisure": ["PAQ625","PAQ665","PAQ520"],
    "sedentary": ["PAD680","PAQ710"],
    "fn_bmd": ["DXXFNBMD","DXXOFBMD"], "totfemur_bmd": ["DXXOFBMD"],
    "troch_bmd": ["DXXTRBMD"], "ls_bmd": ["DXXLSBMD","DXXL1BMD"], "totbody_bmd": ["DXDTOBMD"],
    "wtmec2yr": ["WTMEC2YR"], "wtmec4yr": ["WTMEC4YR"], "psu": ["SDMVPSU"], "strata": ["SDMVSTRA"],
}

inv = {}
for cyc in CYCLES:
    d = os.path.join(DATA, cyc)
    if not os.path.isdir(d):
        continue
    colmap = {}
    for f in sorted(os.listdir(d)):
        if not f.endswith(".xpt"):
            continue
        try:
            cols = pd.read_sas(os.path.join(d, f), format="xport").columns
            for c in cols:
                colmap.setdefault(c, f)
        except Exception as e:
            print(f"  read fail {cyc}/{f}: {type(e).__name__}")
    inv[cyc] = {}
    for concept, cands in CONCEPTS.items():
        for c in cands:
            if c in colmap:
                inv[cyc][concept] = {"var": c, "file": colmap[c]}
                break

json.dump(inv, open("variable_inventory.json", "w"), indent=1)

concepts = list(CONCEPTS.keys())
present = [c for c in CYCLES if c in inv]
w = 15
print(f"{'concept':18s}" + "".join(f"{c[:7]:>9s}" for c in present))
for concept in concepts:
    row = f"{concept:18s}"
    for c in present:
        v = inv[c].get(concept)
        row += f"{'ok' if v else '-':>9s}"
    print(row)

print("\n--- variable name used per cycle (for concepts with any variation) ---")
for concept in concepts:
    names = {}
    for c in present:
        v = inv[c].get(concept)
        if v:
            names.setdefault(v["var"], []).append(c)
    if len(names) > 1:
        print(f"{concept}: " + " | ".join(f"{k}->{len(v)}cyc" for k, v in names.items()))
