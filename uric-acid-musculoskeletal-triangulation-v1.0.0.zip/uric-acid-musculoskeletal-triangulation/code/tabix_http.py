"""
Minimal pure-Python tabix reader over HTTP range requests.
Lets us query individual SNPs from large BGZF-indexed GWAS summary-statistics files
(FinnGen) without downloading the full ~800 MB file.
"""
import gzip, io, struct, requests, functools

S = requests.Session()
S.headers.update({"User-Agent": "Mozilla/5.0 (compatible; research-tool)"})


def _reg2bins(beg, end):
    lst = [0]
    if beg >= end:
        return lst
    end -= 1
    end = min(end, (1 << 29) - 1)
    for k in range(1 + (beg >> 26), 1 + (end >> 26) + 1):
        lst.append(k)
    for k in range(9 + (beg >> 23), 9 + (end >> 23) + 1):
        lst.append(k)
    for k in range(73 + (beg >> 20), 73 + (end >> 20) + 1):
        lst.append(k)
    for k in range(585 + (beg >> 17), 585 + (end >> 17) + 1):
        lst.append(k)
    for k in range(4681 + (beg >> 14), 4681 + (end >> 14) + 1):
        lst.append(k)
    return lst


class TabixHTTP:
    def __init__(self, url):
        self.url = url
        r = S.get(url + ".tbi", timeout=120)
        r.raise_for_status()
        raw = gzip.decompress(r.content)
        self._parse(raw)

    def _parse(self, buf):
        f = io.BytesIO(buf)
        magic = f.read(4)
        assert magic == b"TBI\x01", f"bad tabix magic {magic!r}"
        self.n_ref, self.fmt, self.col_seq, self.col_beg, self.col_end, self.col_meta, \
            self.skip, l_nm = struct.unpack("<8i", f.read(32))
        names_blob = f.read(l_nm)
        self.names = [n.decode() for n in names_blob.split(b"\x00") if n]
        self.bins = []
        self.linear = []
        for _ in range(self.n_ref):
            n_bin = struct.unpack("<i", f.read(4))[0]
            bins = {}
            for _ in range(n_bin):
                b, n_chunk = struct.unpack("<Ii", f.read(8))
                chunks = [struct.unpack("<QQ", f.read(16)) for _ in range(n_chunk)]
                bins[b] = chunks
            n_intv = struct.unpack("<i", f.read(4))[0]
            lin = [struct.unpack("<Q", f.read(8))[0] for _ in range(n_intv)]
            self.bins.append(bins)
            self.linear.append(lin)

    def _ref_id(self, chrom):
        cands = [chrom, chrom.replace("chr", ""), "chr" + chrom.replace("chr", "")]
        for c in cands:
            if c in self.names:
                return self.names.index(c)
        return None

    def fetch(self, chrom, start, end):
        """start, end are 1-based inclusive (tabix convention). Returns list of line strings."""
        rid = self._ref_id(str(chrom))
        if rid is None:
            return []
        beg = max(0, start - 1)
        end = end
        chunks = []
        for b in _reg2bins(beg, end):
            if b in self.bins[rid]:
                chunks.extend(self.bins[rid][b])
        if not chunks:
            return []
        lin = self.linear[rid]
        min_off = lin[beg >> 14] if (beg >> 14) < len(lin) else 0
        chunks = [c for c in chunks if c[1] > min_off]
        if not chunks:
            return []
        chunks.sort()
        merged = []
        for c in chunks:
            if merged and c[0] <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], c[1]))
            else:
                merged.append(list(c) if isinstance(c, tuple) else c)
                merged[-1] = tuple(merged[-1]) if isinstance(merged[-1], list) else merged[-1]
        out = []
        for cb, ce in merged:
            b0, b1 = cb >> 16, (ce >> 16) - 1
            if b1 < b0:
                continue
            r = S.get(self.url, headers={"Range": f"bytes={b0}-{b1}"}, timeout=180)
            if r.status_code not in (200, 206):
                continue
            try:
                txt = gzip.decompress(r.content).decode("utf-8", "replace")
            except Exception:
                continue
            for line in txt.split("\n"):
                if not line or line.startswith("#"):
                    continue
                p = line.split("\t")
                if len(p) < 3:
                    continue
                if p[0] not in (str(chrom), str(chrom).replace("chr", ""), "chr" + str(chrom).replace("chr", "")):
                    continue
                try:
                    pos = int(p[1])
                except ValueError:
                    continue
                if start <= pos <= end:
                    out.append(line)
        return out
